// Native PS3 video / pad / XMB-exit support for ccleste (PSL1GHT only, no SDL video).
//
// Video: RSX double buffering with a vsync-synchronised flip (same scheme as the official
// PSL1GHT samples: rsxInit, videoConfigure, gcmSetDisplayBuffer, gcmSetFlip/gcmSetWaitFlip).
// Pad: ioPad (DualShock 3). XMB: sysutil callback, so the PS button can close the game.
#ifndef PS3VIDEO_H_
#define PS3VIDEO_H_

#include <stdint.h>

// pad buttons, bit mask returned in ps3v_pad_state().buttons
enum {
	PS3V_UP = 1<<0, PS3V_DOWN = 1<<1, PS3V_LEFT = 1<<2, PS3V_RIGHT = 1<<3,
	PS3V_CROSS = 1<<4, PS3V_CIRCLE = 1<<5, PS3V_SQUARE = 1<<6, PS3V_TRIANGLE = 1<<7,
	PS3V_START = 1<<8, PS3V_SELECT = 1<<9,
	PS3V_L1 = 1<<10, PS3V_R1 = 1<<11, PS3V_L2 = 1<<12, PS3V_R2 = 1<<13,
	PS3V_L3 = 1<<14, PS3V_R3 = 1<<15,
};

typedef struct {
	unsigned buttons;   // PS3V_* bits (d-pad and face buttons)
	int lx, ly;         // left stick, -128..127 (up/left is negative)
} ps3v_pad_t;

// Returns 0 on success. Logs through the callback (may be NULL).
int  ps3v_init(void (*logfn)(const char* fmt, ...));
void ps3v_shutdown(void);

int  ps3v_width(void);
int  ps3v_height(void);

// Waits (at most ~0.3 s) until the previous flip has happened, then returns the back
// buffer: width*height 32-bit XRGB pixels, `*pitch_words` 32-bit words per row.
// If the wait times out, flip_timeouts is incremented and the game goes on.
uint32_t* ps3v_begin_frame(int* pitch_words);
// Which of the two buffers ps3v_begin_frame() returned (0 or 1)
int  ps3v_back_index(void);
// Queues the flip of the buffer returned by ps3v_begin_frame()
void ps3v_end_frame(void);

// Flips the buffer that is on screen again (no drawing): keeps the loop locked to the vsync
void ps3v_repeat_frame(void);

// Copies a whole w*h XRGB image (top-left aligned) into the back buffer and flips it
void ps3v_show_image(const uint32_t* pixels, int pitch_words, int w, int h);

// Must be called every frame: runs the sysutil callbacks. Returns 1 once the XMB / PS
// button asked the game to exit.
int  ps3v_poll(void);
int  ps3v_exit_requested(void);

#define PS3V_MAX_PADS 2
// Reads the first connected pad. Returns 1 if a pad is connected.
int  ps3v_pad_state(ps3v_pad_t* out);
// Reads the idx-th connected pad (0 = first, 1 = second: player 2 in co-op)
int  ps3v_pad_state_n(int idx, ps3v_pad_t* out);
// How many pads are connected
int  ps3v_pad_count(void);

unsigned ps3v_flip_timeouts(void);
unsigned ps3v_flip_count(void);

#endif
