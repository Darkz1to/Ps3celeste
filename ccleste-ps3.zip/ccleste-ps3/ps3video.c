// Native PS3 video / pad / XMB-exit support for ccleste, see ps3video.h.
// Uses only PSL1GHT (no SDL): the video code follows the official PSL1GHT samples.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <malloc.h>

#include <ppu-lv2.h>
#include <sysutil/video.h>
#include <sysutil/sysutil.h>
#include <rsx/gcm_sys.h>
#include <rsx/rsx.h>
#include <io/pad.h>

#include "ps3video.h"

// event ids of sysUtilRegisterCallback (older PSL1GHT headers may lack some of them)
#ifndef SYSUTIL_MENU_OPEN
#define SYSUTIL_MENU_OPEN  0x0131
#endif
#ifndef SYSUTIL_MENU_CLOSE
#define SYSUTIL_MENU_CLOSE 0x0132
#endif
#ifndef SYSUTIL_DRAW_BEGIN
#define SYSUTIL_DRAW_BEGIN 0x0121
#endif
#ifndef SYSUTIL_DRAW_END
#define SYSUTIL_DRAW_END   0x0122
#endif

#define CB_SIZE        0x100000               // RSX command buffer
#define HOST_SIZE      (32*1024*1024)         // IO memory shared with the RSX (multiple of 1 MB)
#define FLIP_WAIT_LOOPS 1500                  // x usleep(200) = about 0.3 s

typedef struct {
	int width, height;
	uint32_t* ptr;
	uint32_t offset;
} fbuf_t;

static gcmContextData* ctx = NULL;
static void* host_addr = NULL;
static fbuf_t bufs[2];
static int back = 1;                  // buffer we draw into next
static int disp_w = 0, disp_h = 0;
static int pad_ready = 0;
static volatile int exit_req = 0;
static volatile int overlay_dirty = 0;   // the XMB drew over our frame buffers: they must be repainted
static volatile int overlay_open = 0;    // the XMB (PS button menu) is on screen
static volatile int overlay_draw = 0;    // between SYSUTIL_DRAW_BEGIN and SYSUTIL_DRAW_END
// The XMB keeps drawing into our buffers after the "menu closed" event (fade-out animation),
// so after it closes we keep repainting everything for this many poll() calls (~1.5 s).
#define OVERLAY_HOLD_POLLS 100
static volatile int overlay_hold = 0;
static unsigned flip_timeouts = 0, flip_count = 0;
static void (*logf_)(const char*, ...) = NULL;

#define LOG(...) do { if (logf_) logf_(__VA_ARGS__); } while (0)

static void sysutil_cb(u64 status, u64 param, void* usrdata) {
	(void)param; (void)usrdata;
	switch (status) {
		case SYSUTIL_EXIT_GAME: exit_req = 1; break;   // PS button -> "quit game" in the XMB
		// The in-game XMB overlay draws on top of (and leaves garbage in) our frame buffers.
		case SYSUTIL_MENU_OPEN:  overlay_open = 1; overlay_hold = OVERLAY_HOLD_POLLS; overlay_dirty = 1; break;
		case SYSUTIL_MENU_CLOSE: overlay_open = 0; overlay_hold = OVERLAY_HOLD_POLLS; overlay_dirty = 1; break;
		case SYSUTIL_DRAW_BEGIN: overlay_draw = 1; overlay_hold = OVERLAY_HOLD_POLLS; overlay_dirty = 1; break;
		case SYSUTIL_DRAW_END:   overlay_draw = 0; overlay_hold = OVERLAY_HOLD_POLLS; overlay_dirty = 1; break;
		default: break;
	}
}

static int do_flip(int id) {
	if (gcmSetFlip(ctx, (uint8_t)id) == 0) {
		rsxFlushBuffer(ctx);
		gcmSetWaitFlip(ctx);          // the RSX waits for the vsync before going on
		return 1;
	}
	return 0;
}

static int make_buffer(fbuf_t* b, int w, int h, int id) {
	const int pitch = w * (int)sizeof(uint32_t);
	const int size  = pitch * h;
	b->width = w; b->height = h;
	b->ptr = (uint32_t*)rsxMemalign(64, size);
	if (!b->ptr) return -1;
	if (gcmAddressToOffset(b->ptr, &b->offset) != 0) return -1;
	if (gcmSetDisplayBuffer(id, b->offset, pitch, w, h) != 0) return -1;
	memset(b->ptr, 0, size);
	return 0;
}

int ps3v_init(void (*logfn)(const char* fmt, ...)) {
	logf_ = logfn;

	host_addr = memalign(1024*1024, HOST_SIZE);
	if (!host_addr) { LOG("ps3v: memalign(host) failed\n"); return -1; }
	if (rsxInit(&ctx, CB_SIZE, HOST_SIZE, host_addr) != 0 || !ctx) { LOG("ps3v: rsxInit failed\n"); return -1; }

	videoState state;
	if (videoGetState(0, 0, &state) != 0) { LOG("ps3v: videoGetState failed\n"); return -1; }
	videoResolution res;
	if (videoGetResolution(state.displayMode.resolution, &res) != 0) { LOG("ps3v: videoGetResolution failed\n"); return -1; }
	LOG("ps3v: display %dx%d (resolution id %d)\n", (int)res.width, (int)res.height, (int)state.displayMode.resolution);

	videoConfiguration vconfig;
	memset(&vconfig, 0, sizeof vconfig);
	vconfig.resolution = state.displayMode.resolution;
	vconfig.format = VIDEO_BUFFER_FORMAT_XRGB;
	vconfig.pitch = res.width * sizeof(uint32_t);
	if (videoConfigure(0, &vconfig, NULL, 0) != 0) { LOG("ps3v: videoConfigure failed\n"); return -1; }
	if (videoGetState(0, 0, &state) != 0) { LOG("ps3v: videoGetState(2) failed\n"); return -1; }

	gcmSetFlipMode(GCM_FLIP_VSYNC);   // flips happen on the vertical sync
	disp_w = res.width; disp_h = res.height;

	if (make_buffer(&bufs[0], disp_w, disp_h, 0) != 0 || make_buffer(&bufs[1], disp_w, disp_h, 1) != 0) {
		LOG("ps3v: cannot create the frame buffers\n");
		return -1;
	}

	sysUtilRegisterCallback(0, sysutil_cb, NULL);

	pad_ready = (ioPadInit(7) == 0);
	LOG("ps3v: pad init %s\n", pad_ready ? "ok" : "FAILED");

	// show buffer 0 (black) so the flip status is in a known state, then draw into buffer 1
	gcmResetFlipStatus();
	do_flip(0);
	back = 1;
	LOG("ps3v: video ok, vsync flip, 2 buffers\n");
	return 0;
}

void ps3v_shutdown(void) {
	if (ctx) {
		// let the last flip finish, then leave the buffers to the system
		for (int i = 0; i < FLIP_WAIT_LOOPS && gcmGetFlipStatus() != 0; i++) usleep(200);
		gcmResetFlipStatus();
	}
	if (pad_ready) { ioPadEnd(); pad_ready = 0; }
}

int ps3v_width(void)  { return disp_w; }
int ps3v_height(void) { return disp_h; }

uint32_t* ps3v_begin_frame(int* pitch_words) {
	int loops = 0;
	while (gcmGetFlipStatus() != 0) {
		if (++loops > FLIP_WAIT_LOOPS) { flip_timeouts++; break; }   // never freeze here
		usleep(200);
	}
	gcmResetFlipStatus();
	if (pitch_words) *pitch_words = bufs[back].width;
	return bufs[back].ptr;
}

int ps3v_back_index(void) { return back; }

void ps3v_end_frame(void) {
	if (do_flip(back)) flip_count++;
	back ^= 1;
}

void ps3v_repeat_frame(void) {
	int loops = 0;
	while (gcmGetFlipStatus() != 0) {
		if (++loops > FLIP_WAIT_LOOPS) { flip_timeouts++; break; }
		usleep(200);
	}
	gcmResetFlipStatus();
	if (do_flip(back ^ 1)) flip_count++;   // back^1 is the buffer on screen
}

void ps3v_show_image(const uint32_t* pixels, int pitch_words, int w, int h) {
	int pw;
	uint32_t* fb = ps3v_begin_frame(&pw);
	if (w > disp_w) w = disp_w;
	if (h > disp_h) h = disp_h;
	for (int y = 0; y < h; y++) {
		memcpy(fb + (size_t)y*pw, pixels + (size_t)y*pitch_words, (size_t)w*4);
		if (w < pw) memset(fb + (size_t)y*pw + w, 0, (size_t)(pw - w)*4);
	}
	for (int y = h; y < disp_h; y++) memset(fb + (size_t)y*pw, 0, (size_t)pw*4);
	ps3v_end_frame();
}

int ps3v_poll(void) {
	sysUtilCheckCallback();
	// Keep repainting everything while the menu is up / drawing, and for a while after it
	// closes: the game only redraws changed pixels, so anything the XMB leaves in the
	// buffers would otherwise stay there forever.
	if (overlay_open || overlay_draw) { overlay_hold = OVERLAY_HOLD_POLLS; overlay_dirty = 1; }
	else if (overlay_hold > 0) { overlay_hold--; overlay_dirty = 1; }
	return exit_req;
}
int ps3v_take_overlay_dirty(void) {
	int d = overlay_dirty;
	overlay_dirty = 0;
	return d;
}
int ps3v_exit_requested(void) { return exit_req; }
int ps3v_overlay_active(void) { return overlay_open || overlay_draw; }

// ioPadGetData() reports len == 0 when the pad has not produced a new sample since the last
// call (the loop can run faster than the pad updates). That does NOT mean "all released":
// keep the last real sample, otherwise a held stick/button flickers off for a frame and the
// character takes one step and stops.
// idx 0 = the first connected pad, idx 1 = the second connected pad (co-op player 2).
int ps3v_pad_state_n(int idx, ps3v_pad_t* out) {
	static ps3v_pad_t last[PS3V_MAX_PADS];
	static int last_valid[PS3V_MAX_PADS];
	memset(out, 0, sizeof *out);
	if (!pad_ready || idx < 0 || idx >= PS3V_MAX_PADS) return 0;
	padInfo pi;
	if (ioPadGetInfo(&pi) != 0) return 0;
	int seen = 0;
	for (int i = 0; i < 7; i++) {
		if (!pi.status[i]) continue;
		if (seen++ != idx) continue;
		padData pd;
		if (ioPadGetData(i, &pd) != 0) continue;
		if (pd.len <= 0) {
			if (last_valid[idx]) { *out = last[idx]; return 1; }   // no new sample: same as before
			continue;
		}
		unsigned b = 0;
		if (pd.BTN_UP) b |= PS3V_UP;
		if (pd.BTN_DOWN) b |= PS3V_DOWN;
		if (pd.BTN_LEFT) b |= PS3V_LEFT;
		if (pd.BTN_RIGHT) b |= PS3V_RIGHT;
		if (pd.BTN_CROSS) b |= PS3V_CROSS;
		if (pd.BTN_CIRCLE) b |= PS3V_CIRCLE;
		if (pd.BTN_SQUARE) b |= PS3V_SQUARE;
		if (pd.BTN_TRIANGLE) b |= PS3V_TRIANGLE;
		if (pd.BTN_START) b |= PS3V_START;
		if (pd.BTN_SELECT) b |= PS3V_SELECT;
		if (pd.BTN_L1) b |= PS3V_L1;
		if (pd.BTN_R1) b |= PS3V_R1;
		if (pd.BTN_L2) b |= PS3V_L2;
		if (pd.BTN_R2) b |= PS3V_R2;
		if (pd.BTN_L3) b |= PS3V_L3;
		if (pd.BTN_R3) b |= PS3V_R3;
		out->buttons = b;
		out->lx = (int)pd.ANA_L_H - 128;
		out->ly = (int)pd.ANA_L_V - 128;
		last[idx] = *out; last_valid[idx] = 1;
		return 1;
	}
	last_valid[idx] = 0;   // pad unplugged
	return 0;
}

int ps3v_pad_state(ps3v_pad_t* out) { return ps3v_pad_state_n(0, out); }

// number of connected pads
int ps3v_pad_count(void) {
	padInfo pi;
	if (!pad_ready || ioPadGetInfo(&pi) != 0) return 0;
	int n = 0;
	for (int i = 0; i < 7; i++) if (pi.status[i]) n++;
	return n;
}

unsigned ps3v_flip_timeouts(void) { return flip_timeouts; }
unsigned ps3v_flip_count(void)    { return flip_count; }
