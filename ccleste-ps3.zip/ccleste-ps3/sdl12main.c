#include <SDL.h>
#include <SDL_mixer.h>
#if SDL_MAJOR_VERSION >= 2
#include "sdl20compat.inc.c"
#endif
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <time.h>
#ifdef _3DS
#include <3ds.h>
#endif
#include "celeste.h"

#if defined(PLATFORM_PS3) && SDL_MAJOR_VERSION < 2
// SDL 1.2 without the video subsystem: the palette of the 8-bit surfaces is not used (the
// blitter works on the raw color indices), so skip the call
#define SDL_SetPalette(s, f, c, b, n) ((void)(s), (void)(f), (void)(c), (void)(b), (void)(n))
#endif

#if defined(_3DS) || defined(PLATFORM_PS3)
#define CONSOLE_KEYS 1
#endif

#ifdef PLATFORM_PS3
static void ps3_logv(const char* fmt, va_list ap);
#endif
static void ErrLog(char* fmt, ...) {
#ifdef _3DS
	/*FILE* f = fopen("sdmc:/ccleste.txt", "a");
	if (!f) return;
	fprintf(f, "%li \t", (long int)time(NULL));*/
	FILE* f = stdout; //bottom screen console
#else
	FILE* f = stderr;
#endif

	va_list ap;
	va_start(ap, fmt);
#ifdef PLATFORM_PS3
	{ va_list ap2; va_copy(ap2, ap); ps3_logv(fmt, ap2); va_end(ap2); }
#endif
	vfprintf(f, fmt, ap);
	va_end(ap);

	if (f != stderr && f != stdout) fclose(f);
}

SDL_Surface* screen = NULL;
#ifdef PLATFORM_PS3
static char ps3_data_dir[512] = PS3_DATA_DIR;
static SDL_Surface* ps3_display = NULL; // the real framebuffer; `screen` is the 128x128 game surface
static int ps3_mult = 1;                // integer upscale factor used by ps3_present()
static void ps3_boot(int col, const char* fmt, ...);
static void ps3_fatal(const char* fmt, ...);
#endif
SDL_Surface* gfx = NULL;
SDL_Surface* font = NULL;
Mix_Chunk* snd[64] = {NULL};
Mix_Music* mus[6] = {NULL};
#ifdef PLATFORM_PS3
static char ps3_mus_avail[6] = {0}; // PS3: music is played as WAV chunks, see music_play()
#endif

#define PICO8_W 128
#define PICO8_H 128

#ifdef _3DS
static const int scale = 2;
#elif defined(PLATFORM_PS3)
static const int scale = 1; // render at 128x128, upscaled in ps3_present()
#else
static int scale = 4;
#endif

static const SDL_Color base_palette[16] = {
	{0x00, 0x00, 0x00},
	{0x1d, 0x2b, 0x53},
	{0x7e, 0x25, 0x53},
	{0x00, 0x87, 0x51},
	{0xab, 0x52, 0x36},
	{0x5f, 0x57, 0x4f},
	{0xc2, 0xc3, 0xc7},
	{0xff, 0xf1, 0xe8},
	{0xff, 0x00, 0x4d},
	{0xff, 0xa3, 0x00},
	{0xff, 0xec, 0x27},
	{0x00, 0xe4, 0x36},
	{0x29, 0xad, 0xff},
	{0x83, 0x76, 0x9c},
	{0xff, 0x77, 0xa8},
	{0xff, 0xcc, 0xaa}
};
static SDL_Color palette[16];

static inline Uint32 getcolor(char idx) {
	SDL_Color c = palette[idx%16];
	return SDL_MapRGB(screen->format, c.r,c.g,c.b);
}

static void ResetPalette(void) {
	//SDL_SetPalette(surf, SDL_PHYSPAL|SDL_LOGPAL, (SDL_Color*)base_palette, 0, 16);
	//memcpy(screen->format->palette->colors, base_palette, 16*sizeof(SDL_Color));
	memcpy(palette, base_palette, sizeof palette);
}

static char* GetDataPath(char* path, int n, const char* fname) {
#ifdef _3DS
	snprintf(path, n, "romfs:/%s", fname);
#elif defined(PLATFORM_PS3)
	snprintf(path, n, "%s/%s", ps3_data_dir, fname);
#else
#ifdef _WIN32
	char pathsep = '\\';
#else
	char pathsep = '/';
#endif //_WIN32
	snprintf(path, n, "data%c%s", pathsep, fname);
#endif //_3DS

	return path;
}

static Uint32 getpixel(SDL_Surface *surface, int x, int y) {
	int bpp = surface->format->BytesPerPixel;
	/* Here p is the address to the pixel we want to retrieve */
	Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

	switch(bpp) {
		case 1:
			return *p;

		case 2:
			return *(Uint16 *)p;

		case 3:
			if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
				return p[0] << 16 | p[1] << 8 | p[2];
			else
				return p[0] | p[1] << 8 | p[2] << 16;

		case 4:
			return *(Uint32 *)p;
	}
	return 0;
}

static void loadbmpscale(char* filename, SDL_Surface** s) {
	SDL_Surface* surf = *s;
	if (surf) SDL_FreeSurface(surf), surf = *s = NULL;

	char tmpath[4096];
	SDL_Surface* bmp = SDL_LoadBMP(GetDataPath(tmpath, sizeof tmpath, filename));
	if (!bmp) {
		ErrLog("error loading bmp '%s': %s\n", filename, SDL_GetError());
		return;
	}

	int w = bmp->w, h = bmp->h;

	surf = SDL_CreateRGBSurface(SDL_SWSURFACE, w*scale, h*scale, 8, 0,0,0,0);
	assert(surf != NULL);
	unsigned char* data = surf->pixels;
	/*memcpy((_S)->format->palette->colors, base_palette, 16*sizeof(SDL_Color));*/
	for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
		unsigned char pix = getpixel(bmp, x, y);
		for (int i = 0; i < scale; i++) for (int j = 0; j < scale; j++) {
			data[x*scale+i + (y*scale+j)*w*scale] = pix;
		}
	}
	SDL_FreeSurface(bmp);
	SDL_SetPalette(surf, SDL_PHYSPAL | SDL_LOGPAL, (SDL_Color*)base_palette, 0, 16);
	SDL_SetColorKey(surf, SDL_SRCCOLORKEY, 0);

	*s = surf;
}

#define LOGLOAD(w) printf("loading %s...", w)
#define LOGDONE() printf("done\n")

static void LoadData(void) {
#ifdef PLATFORM_PS3
	ps3_boot(0, "LOADING GRAPHICS...");
#endif
	LOGLOAD("gfx.bmp");
	loadbmpscale("gfx.bmp", &gfx);
	LOGDONE();
	
	LOGLOAD("font.bmp");
	loadbmpscale("font.bmp", &font);
	LOGDONE();
#ifdef PLATFORM_PS3
	if (!gfx || !font) ps3_fatal("CANNOT LOAD GFX/FONT FROM %s", ps3_data_dir);
	ps3_boot(1, "GRAPHICS OK");
	ps3_boot(0, "LOADING SOUNDS...");
	int ps3_snd_ok = 0, ps3_mus_ok = 0;
#endif

	static const char sndids[] = {0,1,2,3,4,5,6,7,8,9,13,14,15,16,23,35,37,38,40,50,51,54,55};
	for (int iid = 0; iid < sizeof sndids; iid++) {
		int id = sndids[iid];
		char fname[20];
		sprintf(fname, "snd%i.wav", id);
		char path[4096];
		LOGLOAD(fname);
		GetDataPath(path, sizeof path, fname);
		snd[id] = Mix_LoadWAV(path);
		if (!snd[id]) {
			ErrLog("snd%i: Mix_LoadWAV: %s\n", id, Mix_GetError());
		}
#ifdef PLATFORM_PS3
		else ps3_snd_ok++;
#endif
		LOGDONE();
	}
	static const char musids[] = {0,10,20,30,40};
	for (int iid = 0; iid < sizeof musids; iid++) {
		int id = musids[iid];
		char fname[20];
#ifdef PLATFORM_PS3
		// PS3: music is played from WAV files through the same mixer path as the sound
		// effects (the OGG music streamer froze the game), loaded when a track starts
		sprintf(fname, "mus%i.wav", id);
		LOGLOAD(fname);
		char path[4096];
		GetDataPath(path, sizeof path, fname);
		FILE* mf = fopen(path, "rb");
		if (mf) { fclose(mf); ps3_mus_avail[id/10] = 1; ps3_mus_ok++; }
		else ErrLog("mus%i: %s not found\n", id, path);
		LOGDONE();
#else
		sprintf(fname, "mus%i.ogg", id);
		LOGLOAD(fname);
		char path[4096];
		GetDataPath(path, sizeof path, fname);
		mus[id/10] = Mix_LoadMUS(path);
		if (!mus[id/10]) {
			ErrLog("mus%i: Mix_LoadMUS: %s\n", id, Mix_GetError());
		}
		LOGDONE();
#endif
	}
#ifdef PLATFORM_PS3
	ps3_boot(ps3_snd_ok > 0 ? 1 : 2, "SOUNDS %d/%d  MUSIC %d/%d", ps3_snd_ok, (int)sizeof sndids, ps3_mus_ok, (int)sizeof musids);
#endif
}
#include "tilemap.h"

static Uint16 buttons_state = 0;


#ifdef PLATFORM_PS3
// ===========================================================================
// PS3: log file, boot screen, native video (RSX, vsync flip) and native pad.
// SDL is only used here for software surfaces and audio (SDL_mixer): the SDL video,
// event and joystick subsystems are NOT initialised. Every earlier log froze inside the SDL
// renderer's SDL_RenderPresent (after ~256 frames), so the frame goes to the screen
// through ps3video.c (PSL1GHT) instead.
// ===========================================================================
#include "ps3video.h"

static FILE* ps3_logfile = NULL;
static char ps3_log_path[600] = "(no log file)";
static char ps3_base_dir[512] = "/dev_hdd0/game/CCLE00001/USRDIR";

static void ps3_logv(const char* fmt, va_list ap) {
	if (!ps3_logfile) return;
	fprintf(ps3_logfile, "[%u] ", (unsigned)SDL_GetTicks());
	vfprintf(ps3_logfile, fmt, ap);
	fflush(ps3_logfile);
}
static void ps3_log(const char* fmt, ...) {
	va_list ap; va_start(ap, fmt); ps3_logv(fmt, ap); va_end(ap);
}

// tiny built-in 3x5 font so the boot screen works even if data files are missing
static const char ps3_font_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.:-/!?()_,= ";
static const unsigned char ps3_font[][5] = {
	{2,5,7,5,5},{6,5,6,5,6},{3,4,4,4,3},{6,5,5,5,6},{7,4,6,4,7},{7,4,6,4,4},{3,4,5,5,3},
	{5,5,7,5,5},{7,2,2,2,7},{1,1,1,5,2},{5,5,6,5,5},{4,4,4,4,7},{5,7,7,5,5},{6,5,5,5,5},
	{2,5,5,5,2},{6,5,6,4,4},{2,5,5,6,3},{6,5,6,5,5},{3,4,2,1,6},{7,2,2,2,2},{5,5,5,5,7},
	{5,5,5,5,2},{5,5,7,7,5},{5,5,2,5,5},{5,5,2,2,2},{7,1,2,4,7},
	{7,5,5,5,7},{2,6,2,2,7},{6,1,2,4,7},{6,1,2,1,6},{5,5,7,1,1},{7,4,6,1,6},{3,4,7,5,7},{7,1,2,2,2},{7,5,7,5,7},{7,5,7,1,6},
	{0,0,0,0,2},{0,2,0,2,0},{0,0,7,0,0},{1,1,2,4,4},{2,2,2,0,2},{6,1,2,0,2},{1,2,2,2,1},{4,2,2,2,4},{0,0,0,0,7},{0,0,0,2,4},{0,7,0,7,0},{0,0,0,0,0}
};

#define PS3_MAX_LINES 24
#define PS3_LINE_LEN 220
static char ps3_lines[PS3_MAX_LINES][PS3_LINE_LEN];
static Uint8 ps3_line_col[PS3_MAX_LINES]; // 0 white, 1 green, 2 red
static int ps3_nlines = 0;

static int ps3_px(void) { // size of one font pixel, scaled to the display height
	int px = ps3_display ? ps3_display->h / 270 : 2;
	return px < 1 ? 1 : px;
}

// draws text with wrapping; returns the y below the last line
static int ps3_text(int x, int y, int px, Uint32 col, const char* str, int maxx) {
	const int cw = 4*px, lh = 7*px;
	int cx = x;
	for (; *str; str++) {
		if (cx + cw > maxx) { cx = x; y += lh; }
		char c = *str;
		if (c >= 'a' && c <= 'z') c -= 32;
		const char* f = strchr(ps3_font_chars, c);
		if (!f || !*f) f = ps3_font_chars + sizeof ps3_font_chars - 2; // space
		const unsigned char* g = ps3_font[f - ps3_font_chars];
		for (int r = 0; r < 5; r++) for (int b = 0; b < 3; b++) {
			if (g[r] & (4 >> b)) {
				SDL_Rect rc = { cx + b*px, y + r*px, px, px };
				SDL_FillRect(ps3_display, &rc, col);
			}
		}
		cx += cw;
	}
	return y + lh;
}

// The boot screen is drawn on a software surface the size of the display, then sent to the
// native frame buffer.
static void ps3_redraw(void) {
	if (!ps3_display) return;
	SDL_FillRect(ps3_display, NULL, SDL_MapRGB(ps3_display->format, 0, 0, 0));
	const int px = ps3_px(), margin = 6*px, maxx = ps3_display->w - margin;
	int y = margin;
	y = ps3_text(margin, y, px*2, SDL_MapRGB(ps3_display->format, 255, 120, 160), "CELESTE CLASSIC", maxx);
	y = ps3_text(margin, y, px, SDL_MapRGB(ps3_display->format, 160, 160, 160), "PS3 PORT - BOOT", maxx);
	y += 3*px;
	for (int i = 0; i < ps3_nlines; i++) {
		Uint32 c = ps3_line_col[i] == 1 ? SDL_MapRGB(ps3_display->format, 90, 230, 90)
		         : ps3_line_col[i] == 2 ? SDL_MapRGB(ps3_display->format, 255, 70, 70)
		         :                        SDL_MapRGB(ps3_display->format, 230, 230, 230);
		y = ps3_text(margin, y, px, c, ps3_lines[i], maxx);
	}
	ps3v_show_image((const uint32_t*)ps3_display->pixels, ps3_display->pitch/4, ps3_display->w, ps3_display->h);
}

// col: 0 normal, 1 ok (green), 2 error (red)
static void ps3_boot(int col, const char* fmt, ...) {
	char buf[PS3_LINE_LEN];
	va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
	ps3_log("%s\n", buf);
	if (ps3_nlines == PS3_MAX_LINES) {
		memmove(ps3_lines[0], ps3_lines[1], sizeof ps3_lines[0] * (PS3_MAX_LINES-1));
		memmove(ps3_line_col, ps3_line_col+1, PS3_MAX_LINES-1);
		ps3_nlines--;
	}
	memcpy(ps3_lines[ps3_nlines], buf, sizeof buf);
	ps3_line_col[ps3_nlines++] = col;
	ps3_redraw();
}

static int ps3_any_button(void) {
	ps3v_pad_t p;
	return ps3v_pad_state(&p) && p.buttons != 0;
}

static void ps3_fatal(const char* fmt, ...) {
	char buf[PS3_LINE_LEN];
	va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
	ps3_log("FATAL: %s\n", buf);
	if (ps3_display) {
		ps3_boot(2, "FATAL ERROR:");
		ps3_boot(2, "%s", buf);
		ps3_boot(0, "LOG FILE: %s", ps3_log_path);
		ps3_boot(0, "CLOSING IN 30 SECONDS (OR PRESS ANY BUTTON)");
		Uint32 t0 = SDL_GetTicks();
		while (SDL_GetTicks() - t0 < 30000) {
			if (ps3v_poll()) break; // PS button
			if (SDL_GetTicks() - t0 > 1000 && ps3_any_button()) break;
			SDL_Delay(50);
		}
	}
	if (ps3_logfile) fclose(ps3_logfile);
	exit(2);
}

// ---- debug breadcrumbs (enabled with -DCCLESTE_DEBUG_LOG): written to ccleste.log ----
#ifdef CCLESTE_DEBUG_LOG
static unsigned long dbg_frame = 0;
#define DBG(...) ps3_log(__VA_ARGS__)
#define DBG_TICK() (dbg_frame++)
// every phase of the first ~30 seconds, then once per second
#define DBG_FRAME(...) do { if (dbg_frame < 3600 || dbg_frame % 120 == 0) ps3_log(__VA_ARGS__); } while (0)
#else
#define DBG(...) ((void)0)
#define DBG_TICK() ((void)0)
#define DBG_FRAME(...) ((void)0)
#endif

// ---- statistics: one line per second in ccleste.log ----
static unsigned ps3_st_loops = 0, ps3_st_presents = 0, ps3_st_flips0 = 0, ps3_st_to0 = 0, ps3_st_t0 = 0;
static void ps3_stats_tick(void) {
	ps3_st_loops++;
	unsigned t = (unsigned)SDL_GetTicks();
	if (!ps3_st_t0) ps3_st_t0 = t;
	if (t - ps3_st_t0 >= 1000) {
		ps3_log("fps=%u game_fps=%u flips=%u flip_timeouts=%u (total %u)\n", ps3_st_loops, ps3_st_presents,
		        ps3v_flip_count() - ps3_st_flips0, ps3v_flip_timeouts() - ps3_st_to0, ps3v_flip_timeouts());
		ps3_st_loops = ps3_st_presents = 0;
		ps3_st_flips0 = ps3v_flip_count(); ps3_st_to0 = ps3v_flip_timeouts();
		ps3_st_t0 = t;
	}
}

// ---- presenting the game ----
// What each of the two frame buffers currently shows (the 128x128 game image), so only the
// pixels that changed are upscaled and written to the screen.
static Uint32 ps3_prev[2][PICO8_W*PICO8_H];
static int ps3_prev_ok[2] = {0, 0};

// the frame buffers hold something else now (boot screen): next presents redraw everything
static void ps3_game_video_reset(void) { ps3_prev_ok[0] = ps3_prev_ok[1] = 0; }

// presents the 128x128 game surface, integer-upscaled and centered on the display
static void ps3_present(void) {
	DBG_FRAME("f%lu present: enter\n", dbg_frame);
	int pw;
	uint32_t* fb = ps3v_begin_frame(&pw);
	const int bi = ps3v_back_index();
	const int W = ps3v_width(), H = ps3v_height(), m = ps3_mult;
	const int ox = (W - 128*m)/2, oy = (H - 128*m)/2;
	int full = !ps3_prev_ok[bi];
	if (full) for (int y = 0; y < H; y++) memset(fb + (size_t)y*pw, 0, (size_t)W*4);
	const Uint32* src = (const Uint32*)screen->pixels;
	const int sp = screen->pitch/4;
	static Uint32 run[PICO8_W*16];
	for (int y = 0; y < PICO8_H; y++) {
		const Uint32* s = src + (size_t)y*sp;
		Uint32* p = ps3_prev[bi] + y*PICO8_W;
		int x0 = 0, x1 = PICO8_W - 1;
		if (!full) {
			while (x0 < PICO8_W && s[x0] == p[x0]) x0++;
			if (x0 == PICO8_W) continue;          // row unchanged
			while (s[x1] == p[x1]) x1--;
		}
		memcpy(p + x0, s + x0, (size_t)(x1 - x0 + 1)*4);
		int n = 0;
		for (int x = x0; x <= x1; x++) { Uint32 px = s[x]; for (int k = 0; k < m; k++) run[n++] = px; }
		for (int k = 0; k < m; k++)
			memcpy(fb + (size_t)(oy + y*m + k)*pw + ox + x0*m, run, (size_t)n*4);
	}
	ps3_prev_ok[bi] = 1;
	ps3v_end_frame();
	ps3_st_presents++;
	DBG_FRAME("f%lu present: flipped\n", dbg_frame);
}

// the game did not change (between two game ticks): show the same image again, which only
// keeps the loop locked to the screen refresh
static void ps3_present_repeat(void) {
	ps3v_repeat_frame();
}

static void ps3_init(int argc, char** argv) {
	// where are we? (argv[0] is normally .../USRDIR/EBOOT.BIN)
	if (argc > 0 && argv && argv[0] && strncmp(argv[0], "/dev_", 5) == 0) {
		snprintf(ps3_base_dir, sizeof ps3_base_dir, "%s", argv[0]);
		char* slash = strrchr(ps3_base_dir, '/');
		if (slash) *slash = 0;
	}
	// log file: next to the game, or in /dev_hdd0/tmp as a fallback
	char path[600];
	snprintf(path, sizeof path, "%s/ccleste.log", ps3_base_dir);
	ps3_logfile = fopen(path, "w");
	if (!ps3_logfile) {
		snprintf(path, sizeof path, "/dev_hdd0/tmp/ccleste.log");
		ps3_logfile = fopen(path, "w");
	}
	if (ps3_logfile) snprintf(ps3_log_path, sizeof ps3_log_path, "%s", path);
	ps3_log("ccleste ps3 start (native video). argc=%d argv0=%s base=%s\n", argc, argc > 0 && argv ? argv[0] : "(none)", ps3_base_dir);

	// SDL: audio only (non-fatal: the game runs silent without it)
	if (SDL_Init(SDL_INIT_AUDIO) != 0) ps3_log("SDL_Init(audio) failed: %s\n", SDL_GetError());
	else ps3_log("SDL_Init(audio) ok\n");

	// native video + pad
	if (ps3v_init(ps3_log) != 0) {
		ps3_log("native video init failed\n");
		if (ps3_logfile) fclose(ps3_logfile);
		exit(2);
	}
	const int W = ps3v_width(), H = ps3v_height();
	// ARGB8888 surfaces (same integer layout as the XRGB frame buffer)
	const Uint32 rm = 0x00ff0000, gm = 0x0000ff00, bm = 0x000000ff, am = 0xff000000;
	ps3_display = SDL_CreateRGBSurface(SDL_SWSURFACE, W, H, 32, rm, gm, bm, am);
	if (!ps3_display) { ps3_log("cannot create the boot surface: %s\n", SDL_GetError()); if (ps3_logfile) fclose(ps3_logfile); exit(2); }
	{
		int minside = W < H ? W : H;
		ps3_mult = minside / 128;
		if (ps3_mult < 1) ps3_mult = 1;
		if (ps3_mult > 16) ps3_mult = 16;
	}
	screen = SDL_CreateRGBSurface(SDL_SWSURFACE, PICO8_W*scale, PICO8_H*scale, 32, rm, gm, bm, am);
	if (!screen) ps3_fatal("CANNOT CREATE GAME SURFACE: %s", SDL_GetError());
	if (screen->format->BytesPerPixel != 4) ps3_fatal("GAME SURFACE IS %d BPP, NEED 32", screen->format->BitsPerPixel);

	// the first things on screen
	ps3_boot(1, "VIDEO OK: %dX%d, GAME SCALE X%d (%dX%d)", W, H, ps3_mult, 128*ps3_mult, 128*ps3_mult);
	ps3_boot(0, "LOG FILE: %s", ps3_log_path);
	ps3_boot(0, "RUNNING FROM: %s", ps3_base_dir);

	// controller
	{
		ps3v_pad_t p;
		int have = ps3v_pad_state(&p);
		ps3_boot(have ? 1 : 0, have ? "CONTROLLER OK" : "NO CONTROLLER YET - PLUG ONE IN");
	}

	// data directory: next to the EBOOT, or the default install path
	{
		const char* cands[] = { NULL, PS3_DATA_DIR };
		char c0[600];
		snprintf(c0, sizeof c0, "%s/data", ps3_base_dir);
		cands[0] = c0;
		int found = 0;
		for (int i = 0; i < 2 && !found; i++) {
			char f[700];
			snprintf(f, sizeof f, "%s/gfx.bmp", cands[i]);
			FILE* t = fopen(f, "rb");
			ps3_log("data check %s -> %s\n", f, t ? "found" : "missing");
			if (t) { fclose(t); snprintf(ps3_data_dir, sizeof ps3_data_dir, "%s", cands[i]); found = 1; }
		}
		if (!found) ps3_fatal("DATA FILES NOT FOUND. LOOKED IN %s AND %s", cands[0], cands[1]);
		ps3_boot(1, "DATA OK: %s", ps3_data_dir);
	}

	// audio (non-fatal: the game runs silent if it fails)
	{
		int mixflag = MIX_INIT_OGG;
		int got = Mix_Init(mixflag);
		if ((got & mixflag) != mixflag) ps3_log("Mix_Init: ogg support missing (%s)\n", Mix_GetError());
		static const int rates[][2] = { {48000,2}, {44100,2}, {22050,1} };
		int opened = 0;
		for (int i = 0; i < 3 && !opened; i++) {
			if (Mix_OpenAudio(rates[i][0], AUDIO_S16SYS, rates[i][1], 2048) == 0) {
				opened = 1;
				Mix_ReserveChannels(1); // channel 0 = music, sound effects use the others
				ps3_boot(1, "AUDIO OK: %d HZ, %d CH", rates[i][0], rates[i][1]);
			} else ps3_log("Mix_OpenAudio(%d,%d): %s\n", rates[i][0], rates[i][1], Mix_GetError());
		}
		if (!opened) ps3_boot(2, "AUDIO FAILED - GAME WILL BE SILENT");
	}
}
#endif // PLATFORM_PS3

#ifdef PLATFORM_PS3
#define SDL_CHECK(r) do { if (!(r)) ps3_fatal("%s:%i `%s` -> %s", __FILE__, __LINE__, #r, SDL_GetError()); } while(0)
#else
#define SDL_CHECK(r) do {                               \
	if (!(r)) {                                           \
		ErrLog("%s:%i, fatal error: `%s` -> %s\n", \
		        __FILE__, __LINE__, #r, SDL_GetError());    \
		exit(2);                                            \
	}                                                     \
} while(0)
#endif

static void p8_rectfill(int x0, int y0, int x1, int y1, int col);
static void p8_print(const char* str, int x, int y, int col);

//on-screen display (for info, such as loading a state, toggling screenshake, toggling fullscreen, etc)
static char osd_text[200] = "";
static int osd_timer = 0;
static void OSDset(const char* fmt, ...) {
	va_list ap;
	va_start(ap, fmt);
	vsnprintf(osd_text, sizeof osd_text, fmt, ap);
	osd_text[sizeof osd_text - 1] = '\0'; //make sure to add NUL terminator in case of truncation
	printf("%s\n", osd_text);
	osd_timer = 30;
	va_end(ap);
}
static void OSDdraw(void) {
	if (osd_timer > 0) {
		--osd_timer;
		const int x = 4;
		const int y = 120 + (osd_timer < 10 ? 10-osd_timer : 0); //disappear by going below the screen
		p8_rectfill(x-2, y-2, x+4*strlen(osd_text), y+6, 6); //outline
		p8_rectfill(x-1, y-1, x+4*strlen(osd_text)-1, y+5, 0);
		p8_print(osd_text, x, y, 7);
	}
}
	
static int current_music = -1; // index into the music list (mus0, mus10, ...), -1 = none
static _Bool enable_screenshake = 1;
static _Bool paused = 0;
static _Bool running = 1;
static void* initial_game_state = NULL;
static void* game_state = NULL;
static int game_state_music = -1;
static void mainLoop(void);
static FILE* TAS = NULL;

// ---- volume ----
// The menu levels 0..10 go through a squared curve: with a plain linear scale 5/10 is only
// -6 dB, which sounds like "nothing happened"; squared, every step is clearly audible.
static int audio_vol(int level) {
	if (level < 0) level = 0;
	if (level > 10) level = 10;
	return MIX_MAX_VOLUME * level * level / 100;
}
static int music_vol = MIX_MAX_VOLUME; // current music volume (0..MIX_MAX_VOLUME)

// ---- music ----
#ifdef PLATFORM_PS3
#define MUSIC_CH 0
static Mix_Chunk* ps3_music_chunk = NULL;
static int ps3_music_loaded = -1;
static int ps3_music_want = 0; // 1 while a track should be playing (looped by music_update)
static int music_available(int i) { return i >= 0 && i < 6 && ps3_mus_avail[i]; }
static void music_play(int i, int fade) {
	if (ps3_music_loaded != i) {
		ps3_music_want = 0;
		Mix_HaltChannel(MUSIC_CH);
		if (ps3_music_chunk) { Mix_FreeChunk(ps3_music_chunk); ps3_music_chunk = NULL; }
		ps3_music_loaded = -1;
		char fname[20], path[4096];
		sprintf(fname, "mus%i.wav", i*10);
		GetDataPath(path, sizeof path, fname);
		ps3_music_chunk = Mix_LoadWAV(path);
		if (!ps3_music_chunk) { ErrLog("mus%i: Mix_LoadWAV: %s\n", i*10, Mix_GetError()); return; }
		ps3_music_loaded = i;
	}
	// the volume lives in the chunk (read by the mixer on every mix), so a freshly loaded
	// track starts at the volume chosen in the menu
	Mix_VolumeChunk(ps3_music_chunk, music_vol);
	// NOT looped by the mixer (loops=0): the loop wrap inside SDL_mixer's audio thread is
	// where the game froze. The loop is done by music_update(), called from the main loop.
	DBG("music_play %d fade=%d\n", i, fade);
	ps3_music_want = 1;
	Mix_FadeInChannel(MUSIC_CH, ps3_music_chunk, 0, fade);
}
// call once per main-loop iteration: restarts the music when the track has ended
static void music_update(void) {
	if (!ps3_music_want || !ps3_music_chunk || ps3_music_loaded < 0) return;
	if (Mix_Playing(MUSIC_CH)) return;
	DBG("music_update: track ended, restarting %d\n", ps3_music_loaded);
	Mix_PlayChannel(MUSIC_CH, ps3_music_chunk, 0);
}
static void music_stop(int fade) { ps3_music_want = 0; if (fade > 0) Mix_FadeOutChannel(MUSIC_CH, fade); else Mix_HaltChannel(MUSIC_CH); }
static void music_halt(void) { ps3_music_want = 0; Mix_HaltChannel(MUSIC_CH); }
static void music_pause(void) {}   // Mix_Pause(-1) already pauses the music channel
static void music_resume(void) {}
static void music_set_volume(int v) {
	music_vol = v;
	Mix_Volume(MUSIC_CH, MIX_MAX_VOLUME); // channel stays at max, the chunk carries the level
	if (ps3_music_chunk) Mix_VolumeChunk(ps3_music_chunk, v);
}
static void music_free(void) { ps3_music_want = 0; Mix_HaltChannel(-1); if (ps3_music_chunk) Mix_FreeChunk(ps3_music_chunk); ps3_music_chunk = NULL; }
#else
static void music_update(void) {}
static int music_available(int i) { return i >= 0 && i < 6 && mus[i]; }
static void music_play(int i, int fade) { Mix_FadeInMusic(mus[i], -1, fade); }
static void music_stop(int fade) { Mix_FadeOutMusic(fade); }
static void music_halt(void) { Mix_HaltMusic(); }
static void music_pause(void) { Mix_PauseMusic(); }
static void music_resume(void) { Mix_ResumeMusic(); }
static void music_set_volume(int v) { music_vol = v; Mix_VolumeMusic(v); }
static void music_free(void) {
	for (int i = 0; i < (sizeof mus)/(sizeof *mus); i++) if (mus[i]) Mix_FreeMusic(mus[i]);
}
#endif

#ifndef PLATFORM_PS3
#define DBG(...) ((void)0)
#define DBG_TICK() ((void)0)
#define DBG_FRAME(...) ((void)0)
#endif

// ---- title menu (play / config / credits), see menu.inc.c ----
int pico8emu(CELESTE_P8_CALLBACK_TYPE call, ...);
static void menu_apply_audio(void);
static void menu_play_sfx(int id);
static int menu_cfg_path(char* out, int n);
static void autosave_sync(void);
#include "savedata.inc.c"
#include "menu.inc.c"

static void menu_apply_audio(void) {
	DBG("menu_apply_audio music=%d sound=%d\n", cfg_music, cfg_sound);
	// always applied (also at 10/10: going back up to the maximum must restore the volume)
	for (int i = 0; i < (int)(sizeof snd / sizeof *snd); i++)
		if (snd[i]) Mix_VolumeChunk(snd[i], audio_vol(cfg_sound));
	music_set_volume(audio_vol(cfg_music));
}
static void menu_play_sfx(int id) {
	DBG("menu_play_sfx %d\n", id);
	if (id >= 0 && id < (int)(sizeof snd / sizeof *snd) && snd[id]) {
		Mix_VolumeChunk(snd[id], audio_vol(cfg_sound));
		Mix_PlayChannel(-1, snd[id], 0);
	}
}

// ---- autosave: write the progress when entering a room / collecting a strawberry ----
static int autosave_last_idx = -1, autosave_last_berries = -1;
static void autosave_sync(void) { // call after loading a save: do not rewrite what was just read
	Celeste_P8_progress_t p;
	Celeste_P8_get_progress(&p);
	autosave_last_idx = p.room_x + p.room_y*8;
	autosave_last_berries = savedata_berries(&p);
}
static void autosave_check(void) {
	if (TAS) return;
	Celeste_P8_progress_t p;
	Celeste_P8_get_progress(&p);
	const int idx = p.room_x + p.room_y*8, berries = savedata_berries(&p);
	if (idx > 30) { autosave_last_idx = autosave_last_berries = -1; return; } // title room
	if (idx == autosave_last_idx && berries == autosave_last_berries) return;
	const int first_room = idx == 0 && berries == 0;   // a new game does not overwrite the old save
	autosave_last_idx = idx; autosave_last_berries = berries;
	if (!first_room) savedata_request_save(&p, cfg_lang == LANG_PT);
}
// where the menu settings are stored; returns 0 if this platform doesn't save them
static int menu_cfg_path(char* out, int n) {
#if defined(PLATFORM_PS3)
	snprintf(out, n, "%s/ccleste.cfg", ps3_base_dir);
	return 1;
#elif defined(_3DS) || defined(EMSCRIPTEN)
	(void)out; (void)n;
	return 0;
#else
	snprintf(out, n, "ccleste-menu.cfg");
	return 1;
#endif
}

#ifdef PLATFORM_PS3
// Emulates the keyboard from the DualShock 3 through the native pad (ps3video.c): no SDL
// events or joystick are used. Button presses become synthetic SDL_KEYDOWN events that the
// main loop reads with SDL_PollEvent (redirected below).
static const struct { unsigned btn; int key; } ps3_map[] = {
	{PS3V_CROSS,    SDLK_z},      // jump
	{PS3V_SQUARE,   SDLK_x},      // dash
	{PS3V_CIRCLE,   SDLK_x},      // dash
	{PS3V_UP,       SDLK_UP},
	{PS3V_DOWN,     SDLK_DOWN},
	{PS3V_LEFT,     SDLK_LEFT},
	{PS3V_RIGHT,    SDLK_RIGHT},
	{PS3V_START,    SDLK_ESCAPE}, // pause
	{PS3V_SELECT,   SDLK_F11},
	{PS3V_L2,       SDLK_LSHIFT}, // hold: reset / load/save state
	{PS3V_L1,       SDLK_d},      // load state
	{PS3V_R1,       SDLK_s},      // save state
};
// size of the fake keyboard state array (SDL 1.2 keysyms and SDL2 scancodes are both < 512)
#define PS3_NKEYS 512
#define PS3_EVQ 64
static int ps3_evq[PS3_EVQ];
static unsigned ps3_evq_head = 0, ps3_evq_tail = 0;
static int ps3_quit_pending = 0, ps3_quit_sent = 0;

static void ps3_ev_push(int key) {
	if (ps3_evq_head - ps3_evq_tail >= PS3_EVQ) return; // full: drop
	ps3_evq[ps3_evq_head++ % PS3_EVQ] = key;
}
static int ps3_poll_event(SDL_Event* ev) {
	memset(ev, 0, sizeof *ev);
	if (ps3_quit_pending) { ps3_quit_pending = 0; ev->type = SDL_QUIT; return 1; }
	if (ps3_evq_head == ps3_evq_tail) return 0;
	ev->type = SDL_KEYDOWN;
	ev->key.keysym.sym = ps3_evq[ps3_evq_tail++ % PS3_EVQ];
	return 1;
}
#undef SDL_PollEvent
#define SDL_PollEvent ps3_poll_event
#undef SDL_PumpEvents
#define SDL_PumpEvents() ((void)0)

#undef SDL_GetKeyState
#define SDL_GetKeyState ps3_get_fake_key_state
static Uint8 *ps3_get_fake_key_state(int *numkeys) {
	static Uint8 st[PS3_NKEYS];
	static Uint8 prev[PS3_NKEYS];
	if (numkeys) *numkeys = PS3_NKEYS;
	memcpy(prev, st, sizeof st);
	memset(st, 0, sizeof st);
	// XMB / PS button: ask the game to quit (once)
	if (ps3v_poll() && !ps3_quit_sent) { ps3_quit_sent = 1; ps3_quit_pending = 1; }
	ps3v_pad_t pad;
	if (ps3v_pad_state(&pad)) {
		for (unsigned i = 0; i < sizeof ps3_map/sizeof *ps3_map; i++)
			if (pad.buttons & ps3_map[i].btn) st[ps3_map[i].key] = 1;
		// left stick as d-pad
		if (pad.lx < -48) st[SDLK_LEFT] = 1;
		if (pad.lx >  48) st[SDLK_RIGHT] = 1;
		if (pad.ly < -48) st[SDLK_UP] = 1;
		if (pad.ly >  48) st[SDLK_DOWN] = 1;
	}
	for (int k = 0; k < PS3_NKEYS; k++)
		if (st[k] && !prev[k]) ps3_ev_push(k);
	return st;
}
#endif

#ifdef _3DS
// hack: newer SDL versions remove SDL_N3DSKeyBind, but I'm too lazy to change the
// code to properly use SDL_Joystick inputs on 3DS so work around it ...
static short n3ds_key_map[32];

static void SDL_N3DSKeyBind(int n3dskey, int kbkey) {
	for (int i = 0; i < 32; i++)
		if (n3dskey & (1u << i))
			n3ds_key_map[i] = kbkey;
}
#define SDL_GetKeyState n3ds_get_fake_key_state
static Uint8 *n3ds_get_fake_key_state(int *numkeys) {
	static Uint8 st[SDLK_LAST];
	if (numkeys) *numkeys = SDLK_LAST;

	memset(st, 0, sizeof st);
	hidScanInput();
	Uint32 down = hidKeysDown();
	Uint32 held = hidKeysHeld();
	for (int i = 0; i < 32; i++) {
		st[n3ds_key_map[i]] |= (held & (1u << i)) != 0;
		if (down & (1u << i)) {
			SDL_Event ev;
			ev.type = SDL_KEYDOWN;
			ev.key.keysym.sym = n3ds_key_map[i];
			SDL_PushEvent(&ev);
		}
	}

	return st;
}
#endif

int main(int argc, char** argv) {
#ifdef PLATFORM_PS3
	ps3_init(argc, argv);
#else
	SDL_CHECK(SDL_Init(SDL_INIT_AUDIO | SDL_INIT_VIDEO) == 0);
#endif
#if SDL_MAJOR_VERSION >= 2 && !defined(PLATFORM_PS3)
	SDL_InitSubSystem(SDL_INIT_GAMECONTROLLER);
	SDL_GameControllerAddMappingsFromRW(SDL_RWFromFile("gamecontrollerdb.txt", "rb"), 1);
#endif
	int videoflag = SDL_SWSURFACE | SDL_HWPALETTE;
#ifdef _3DS
	fsInit();
	romfsInit();
	videoflag = SDL_DOUBLEBUF | SDL_HWSURFACE | SDL_CONSOLEBOTTOM | SDL_TOPSCR;
	SDL_N3DSKeyBind(KEY_A, SDLK_z);
	SDL_N3DSKeyBind(KEY_X|KEY_B, SDLK_x);
	SDL_N3DSKeyBind(KEY_CPAD_UP|KEY_CSTICK_UP|KEY_DUP, SDLK_UP);
	SDL_N3DSKeyBind(KEY_CPAD_DOWN|KEY_CSTICK_DOWN|KEY_DDOWN, SDLK_DOWN);
	SDL_N3DSKeyBind(KEY_CPAD_LEFT|KEY_CSTICK_LEFT|KEY_DLEFT, SDLK_LEFT);
	SDL_N3DSKeyBind(KEY_CPAD_RIGHT|KEY_CSTICK_RIGHT|KEY_DRIGHT, SDLK_RIGHT);
	SDL_N3DSKeyBind(KEY_SELECT, SDLK_F11); //to switch full screen
	SDL_N3DSKeyBind(KEY_START, SDLK_ESCAPE); //to pause
	
	SDL_N3DSKeyBind(KEY_Y, SDLK_LSHIFT); //hold to reset / load/save state
	SDL_N3DSKeyBind(KEY_L, SDLK_d); //load state
	SDL_N3DSKeyBind(KEY_R, SDLK_s); //save state
#endif
#ifndef PLATFORM_PS3
	SDL_CHECK(screen = SDL_SetVideoMode(PICO8_W*scale, PICO8_H*scale, 32, videoflag));
	SDL_WM_SetCaption("Celeste", NULL);
	int mixflag = MIX_INIT_OGG;
	if (Mix_Init(mixflag) != mixflag) {
		ErrLog("Mix_Init: %s\n", Mix_GetError());
	}
	if (Mix_OpenAudio(22050, AUDIO_S16SYS, 1, 1024) < 0) {
		ErrLog("Mix_Init: %s\n", Mix_GetError());
	}
#endif
	ResetPalette();
#ifndef PLATFORM_PS3
	SDL_ShowCursor(0);
#endif

	if (argc > 1) {
		TAS = fopen(argv[1], "r");
		if (!TAS) {
			printf("couldn't open TAS file '%s': %s\n", argv[1], strerror(errno));
		}
	}

	printf("game state size %gkb\n", Celeste_P8_get_state_size()/1024.);

	printf("now loading...\n");

#ifndef PLATFORM_PS3
	{
		const unsigned char loading_bmp[] = {
			0x42,0x4d,0xca,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x82,0x00,
			0x00,0x00,0x6c,0x00,0x00,0x00,0x24,0x00,0x00,0x00,0x09,0x00,
			0x00,0x00,0x01,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x48,0x00,
			0x00,0x00,0x23,0x2e,0x00,0x00,0x23,0x2e,0x00,0x00,0x02,0x00,
			0x00,0x00,0x02,0x00,0x00,0x00,0x42,0x47,0x52,0x73,0x00,0x00,
			0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
			0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
			0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
			0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x00,
			0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
			0x00,0x00,0x00,0x00,0x00,0x00,0xff,0xff,0xff,0x00,0x00,0x00,
			0x00,0x00,0xe0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x10,0x00,
			0x00,0x00,0x66,0x3e,0xf1,0x24,0xf0,0x00,0x00,0x00,0x49,0x44,
			0x92,0x24,0x90,0x00,0x00,0x00,0x49,0x3c,0x92,0x24,0x90,0x00,
			0x00,0x00,0x49,0x04,0x92,0x24,0x90,0x00,0x00,0x00,0x46,0x38,
			0xf0,0x3c,0xf0,0x00,0x00,0x00,0x40,0x00,0x12,0x00,0x00,0x00,
			0x00,0x00,0xc0,0x00,0x10,0x00,0x00,0x00,0x00,0x00
		};
		SDL_RWops* rw = SDL_RWFromConstMem(loading_bmp, sizeof loading_bmp);
		SDL_Surface* loading = SDL_LoadBMP_RW(rw, 1);
		if (!loading) goto skip_load;

		SDL_Rect rc = {60, 60};
		SDL_BlitSurface(loading,NULL,screen,&rc);
		
		SDL_Flip(screen);
		SDL_FreeSurface(loading);
	} skip_load:
#endif

	LoadData();

	int pico8emu(CELESTE_P8_CALLBACK_TYPE call, ...);
	Celeste_P8_set_call_func(pico8emu);

	//for reset
	initial_game_state = SDL_malloc(Celeste_P8_get_state_size());
	if (initial_game_state) Celeste_P8_save_state(initial_game_state);

	if (TAS) {
		// a consistent seed for tas playback
		Celeste_P8_set_rndseed(8);
	} else {
		Celeste_P8_set_rndseed((unsigned)(time(NULL) + SDL_GetTicks()));
	}

	Celeste_P8_init();
#ifdef CCLESTE_NO_MENU
	menu_init(1); // built with MENU=0: original behaviour, no menu
#else
	menu_init(TAS != NULL); // TAS playback skips the menu
	if (!TAS) savedata_start_load(); // "continue" shows up in the menu when a save is found
#endif

	printf("ready\n");
#ifdef PLATFORM_PS3
	ps3_boot(1, "READY - STARTING GAME");
	SDL_Delay(2500); // let the boot screen be readable
#endif
#ifndef PLATFORM_PS3
	{
		FILE* start_fullscreen_f = fopen("ccleste-start-fullscreen.txt", "r");
		const char* start_fullscreen_v = getenv("CCLESTE_START_FULLSCREEN");
		if (start_fullscreen_f || (start_fullscreen_v && *start_fullscreen_v)) {
			SDL_WM_ToggleFullScreen(screen);
		}
		if (start_fullscreen_f) fclose(start_fullscreen_f);
	}
#endif

#ifdef PLATFORM_PS3
	ps3_game_video_reset(); // the boot screen is still in the frame buffers
	ps3_log("entering the main loop (native video, vsync flip)\n");
#endif
#ifdef _3DS
	while (aptMainLoop()) mainLoop();
#elif !defined(EMSCRIPTEN)
	while (running) mainLoop();
#else
#include <emscripten.h>
	//FIXME: this assumes that the display refreshes at 60Hz
	emscripten_set_main_loop(mainLoop, 0, 0);
	emscripten_set_main_loop_timing(EM_TIMING_RAF, 2);
	return 0;
#endif

	if (game_state) SDL_free(game_state);
	if (initial_game_state) SDL_free(initial_game_state);

	SDL_FreeSurface(gfx);
	SDL_FreeSurface(font);
	for (int i = 0; i < (sizeof snd)/(sizeof *snd); i++) {
		if (snd[i]) Mix_FreeChunk(snd[i]);
	}
	music_free();

	Mix_CloseAudio();
	Mix_Quit();
	SDL_Quit();
#ifdef PLATFORM_PS3
	ps3_log("exit: flips=%u flip_timeouts=%u\n", ps3v_flip_count(), ps3v_flip_timeouts());
	ps3v_shutdown();
	if (ps3_logfile) fclose(ps3_logfile);
#endif
	return 0;
}

#if SDL_MAJOR_VERSION >= 2
/* These inputs aren't sent to the game. */
enum {
	PSEUDO_BTN_SAVE_STATE = 6,
	PSEUDO_BTN_LOAD_STATE = 7,
	PSEUDO_BTN_EXIT = 8,
	PSEUDO_BTN_PAUSE = 9,
};
static void ReadGamepadInput(Uint16* out_buttons);
#endif

// ---- timing ----
// The loop runs at TARGET_FPS (input is sampled that often), while the game itself
// (update + draw) still runs at LOGIC_HZ. The game's physics are frame-based, so the
// gameplay speed only stays right at 30 ticks per second; raise LOGIC_HZ if you want the
// game itself faster (TARGET_FPS must be a multiple of it).
#if defined(EMSCRIPTEN) || defined(_3DS)
#define TARGET_FPS 30
#elif defined(PLATFORM_PS3)
#define TARGET_FPS 60 // one loop iteration per screen refresh (the flip waits for the vsync)
#else
#define TARGET_FPS 120
#endif
#define LOGIC_HZ 30
#define LOGIC_DIV (TARGET_FPS / LOGIC_HZ)

#if !defined(EMSCRIPTEN) && !defined(_3DS)
static void frame_wait(void) {
	static unsigned n = 0, frame_start = 0;
	unsigned frame_end = SDL_GetTicks();
	unsigned frame_time = frame_end - frame_start;
	// integer milliseconds only, so spread the remainder: 120fps -> 8,8,9,8,8,9,...
	unsigned target_millis = ((n + 1) * 1000) / TARGET_FPS - (n * 1000) / TARGET_FPS;
	if (++n == TARGET_FPS) n = 0;
#ifdef PLATFORM_PS3
	target_millis = 15; // the vsync flip sets the pace; this only caps it if the vsync is not working
#endif
	if (frame_time < target_millis) SDL_Delay(target_millis - frame_time);
	frame_start = SDL_GetTicks();
}
#endif

static void mainLoop(void) {
	DBG_TICK();
#ifdef PLATFORM_PS3
	ps3_stats_tick();
#endif
	DBG_FRAME("f%lu start state=%d\n", dbg_frame, menu_state);
	music_update();
	savedata_poll();
#if LOGIC_DIV > 1
	// iterations between two game ticks: just remember the buttons that were pressed,
	// so a quick tap between ticks is not lost
	static int sub = 0;
	static Uint16 latched = 0;
	if (sub != 0) {
		SDL_PumpEvents();
		const Uint8* ks = SDL_GetKeyState(NULL);
		if (ks[SDLK_LEFT])  latched |= (1<<0);
		if (ks[SDLK_RIGHT]) latched |= (1<<1);
		if (ks[SDLK_UP])    latched |= (1<<2);
		if (ks[SDLK_DOWN])  latched |= (1<<3);
		if (ks[SDLK_z] || ks[SDLK_c] || ks[SDLK_n]) latched |= (1<<4);
		if (ks[SDLK_x] || ks[SDLK_v] || ks[SDLK_m]) latched |= (1<<5);
		sub = (sub + 1) % LOGIC_DIV;
#ifdef PLATFORM_PS3
		ps3_present_repeat();
#endif
		frame_wait();
		return;
	}
	sub = 1;
#endif
	const Uint8* kbstate = SDL_GetKeyState(NULL);
	DBG_FRAME("f%lu input read\n", dbg_frame);
		
	static int reset_input_timer = 0;
	//hold F9 (select+start+y) to reset
	if (initial_game_state != NULL
#ifdef CONSOLE_KEYS
			&& kbstate[SDLK_LSHIFT] && kbstate[SDLK_ESCAPE] && kbstate[SDLK_F11]
#else
			&& kbstate[SDLK_F9]
#endif
	) {
		reset_input_timer++;
		if (reset_input_timer >= 30) {
			reset_input_timer=0;
			//reset
			OSDset("reset");
			paused = 0;
			Celeste_P8_load_state(initial_game_state);
			Celeste_P8_set_rndseed((unsigned)(time(NULL) + SDL_GetTicks()));
			Mix_HaltChannel(-1);
			music_halt();
			Celeste_P8_init();
			if (!TAS) menu_enter_main(); // reset goes back to the title menu
		}
	} else reset_input_timer = 0;

	Uint16 prev_buttons_state = buttons_state;
	buttons_state = 0;

#if SDL_MAJOR_VERSION >= 2 && !defined(PLATFORM_PS3)
	SDL_GameControllerUpdate();
	ReadGamepadInput(&buttons_state);

	if (!((prev_buttons_state >> PSEUDO_BTN_PAUSE) & 1)
	 && (buttons_state >> PSEUDO_BTN_PAUSE) & 1) {
		goto toggle_pause;
	}

	if (!((prev_buttons_state >> PSEUDO_BTN_EXIT) & 1)
	 && (buttons_state >> PSEUDO_BTN_EXIT) & 1) {
		goto press_exit;
	}

	if (!((prev_buttons_state >> PSEUDO_BTN_SAVE_STATE) & 1)
	 && (buttons_state >> PSEUDO_BTN_SAVE_STATE) & 1) {
		goto save_state;
	}

	if (!((prev_buttons_state >> PSEUDO_BTN_LOAD_STATE) & 1)
	 && (buttons_state >> PSEUDO_BTN_LOAD_STATE) & 1) {
		goto load_state;
	}
#endif

	SDL_Event ev;
	while (SDL_PollEvent(&ev)) switch (ev.type) {
		case SDL_QUIT: running = 0; break;
		case SDL_KEYDOWN: {
#if SDL_MAJOR_VERSION >= 2
			if (ev.key.repeat) break; //no key repeat
#endif
			if (ev.key.keysym.sym == SDLK_ESCAPE) { //do pause
				toggle_pause:
				if (menu_active()) break; // no pause in the menu
				if (paused) Mix_Resume(-1), music_resume(); else Mix_Pause(-1), music_pause();
				paused = !paused;
				break;
			} else if (ev.key.keysym.sym == SDLK_DELETE) { //exit
				press_exit:
				running = 0;
				break;
			} else if (ev.key.keysym.sym == SDLK_F11 && !(kbstate[SDLK_LSHIFT] || kbstate[SDLK_ESCAPE])) {
#ifndef PLATFORM_PS3
				if (SDL_WM_ToggleFullScreen(screen)) { //this doesn't work on windows..
					OSDset("toggle fullscreen");
				}
				screen = SDL_GetVideoSurface();
#endif
				break;
			} else if (0 && ev.key.keysym.sym == SDLK_5) {
				Celeste_P8__DEBUG();
				break;
			} else if (ev.key.keysym.sym == SDLK_s && kbstate[SDLK_LSHIFT]) { //save state
				save_state:
				if (menu_active()) break;
				game_state = game_state ? game_state : SDL_malloc(Celeste_P8_get_state_size());
				if (game_state) {
					OSDset("save state");
					Celeste_P8_save_state(game_state);
					game_state_music = current_music;
				}
				break;
			} else if (ev.key.keysym.sym == SDLK_d && kbstate[SDLK_LSHIFT]) { //load state
				load_state:
				if (menu_active()) break;
				if (game_state) {
					OSDset("load state");
					if (paused) paused = 0, Mix_Resume(-1), music_resume();
					Celeste_P8_load_state(game_state);
					if (current_music != game_state_music) {
						music_halt();
						current_music = game_state_music;
						if (game_state_music >= 0) music_play(game_state_music, 0);
					}
				}
				break;
			} else if ( //toggle screenshake (e / L+R)
#ifdef CONSOLE_KEYS
					(ev.key.keysym.sym == SDLK_d && kbstate[SDLK_s]) || (ev.key.keysym.sym == SDLK_s && kbstate[SDLK_d])
#else
					ev.key.keysym.sym == SDLK_e
#endif
					) {
				enable_screenshake = !enable_screenshake;
				OSDset("screenshake: %s", enable_screenshake ? "on" : "off");
			} break;
		}
	}

	if (!TAS) {
		if (kbstate[SDLK_LEFT])  buttons_state |= (1<<0);
		if (kbstate[SDLK_RIGHT]) buttons_state |= (1<<1);
		if (kbstate[SDLK_UP])    buttons_state |= (1<<2);
		if (kbstate[SDLK_DOWN])  buttons_state |= (1<<3);
		if (kbstate[SDLK_z] || kbstate[SDLK_c] || kbstate[SDLK_n]) buttons_state |= (1<<4);
		if (kbstate[SDLK_x] || kbstate[SDLK_v] || kbstate[SDLK_m]) buttons_state |= (1<<5);
#if LOGIC_DIV > 1
		buttons_state |= latched;
		latched = 0;
#endif
	} else if (TAS && !paused) {
		static int t = 0;
		t++;
		if (t==1) buttons_state = 1<<4;
		else if (t > 80) {
			int btn;
			fscanf(TAS, "%d,", &btn);
			buttons_state = btn;
		} else buttons_state = 0;
	}

	DBG_FRAME("f%lu events done btn=%x\n", dbg_frame, (unsigned)buttons_state);
	if (menu_active()) menu_frame(buttons_state & ~prev_buttons_state, buttons_state);

	if (menu_active()) {
		// the menu already drew this frame
	} else if (paused) {
		const int x0 = PICO8_W/2-3*4, y0 = 8;

		p8_rectfill(x0-1,y0-1, 6*4+x0+1,6+y0+1, 6);
		p8_rectfill(x0,y0, 6*4+x0,6+y0, 0);
		p8_print("paused", x0+1, y0+1, 7);
	} else {
		// "play" was chosen: press jump once so the game runs its own start sequence
		if (menu_take_start()) buttons_state |= (1<<4);
		Celeste_P8_update();
		Celeste_P8_draw();
		autosave_check();
	}
	OSDdraw();
	DBG_FRAME("f%lu drawn\n", dbg_frame);

#ifdef PLATFORM_PS3
	ps3_present();
	DBG_FRAME("f%lu presented\n", dbg_frame);
#else
	SDL_Flip(screen);
#endif

#ifdef EMSCRIPTEN //emscripten_set_main_loop already sets the fps
	SDL_Delay(1);
#elif defined(_3DS)
	gspWaitForVBlank(), gspWaitForVBlank();
#else
	frame_wait();
#endif
}

static int gettileflag(int, int);
static void p8_line(int,int,int,int,unsigned char);

//lots of code from https://github.com/SDL-mirror/SDL/blob/bc59d0d4a2c814900a506d097a381077b9310509/src/video/SDL_surface.c#L625
//coordinates should be scaled already
static inline void Xblit(SDL_Surface* src, SDL_Rect* srcrect, SDL_Surface* dst, SDL_Rect* dstrect, int color, int flipx, int flipy) {
	assert(src && dst && !src->locked && !dst->locked);
	assert(dst->format->BitsPerPixel == 32 && src->format->BitsPerPixel == 8);
	SDL_Rect fulldst;
	/* If the destination rectangle is NULL, use the entire dest surface */
	if (!dstrect)
		dstrect = (fulldst = (SDL_Rect){0,0,dst->w,dst->h}, &fulldst);

	int srcx, srcy, w, h;
	
	/* clip the source rectangle to the source surface */
	if (srcrect) {
		int maxw, maxh;

		srcx = srcrect->x;
		w = srcrect->w;
		if (srcx < 0) {
			w += srcx;
			dstrect->x -= srcx;
			srcx = 0;
		}
		maxw = src->w - srcx;
		if (maxw < w)
			w = maxw;

		srcy = srcrect->y;
		h = srcrect->h;
		if (srcy < 0) {
			h += srcy;
			dstrect->y -= srcy;
			srcy = 0;
		}
		maxh = src->h - srcy;
		if (maxh < h)
			h = maxh;

	} else {
		srcx = srcy = 0;
		w = src->w;
		h = src->h;
	}

	/* clip the destination rectangle against the clip rectangle */
	{
		SDL_Rect *clip = &dst->clip_rect;
		int dx, dy;

		dx = clip->x - dstrect->x;
		if (dx > 0) {
			w -= dx;
			dstrect->x += dx;
			srcx += dx;
		}
		dx = dstrect->x + w - clip->x - clip->w;
		if (dx > 0)
			w -= dx;

		dy = clip->y - dstrect->y;
		if (dy > 0) {
			h -= dy;
			dstrect->y += dy;
			srcy += dy;
		}
		dy = dstrect->y + h - clip->y - clip->h;
		if (dy > 0)
			h -= dy;
	}

	if (w && h) {
		unsigned char* srcpix = src->pixels;
		int srcpitch = src->pitch;
		Uint32* dstpix = dst->pixels;
    #define _blitter(dp, xflip) do                                                                  \
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {                                       \
      unsigned char p = srcpix[!xflip ? srcx+x+(srcy+y)*srcpitch : srcx+(w-x-1)+(srcy+y)*srcpitch]; \
      if (p) dstpix[dstrect->x+x + (dstrect->y+y)*dst->w] = getcolor(dp);                           \
    } while(0)
		if (color && flipx) _blitter(color, 1);
		else if (!color && flipx) _blitter(p, 1);
		else if (color && !flipx) _blitter(color, 0);
		else if (!color && !flipx) _blitter(p, 0);
		#undef _blitter
	}
}

static void p8_rectfill(int x0, int y0, int x1, int y1, int col) {
	int w = (x1 - x0 + 1)*scale;
	int h = (y1 - y0 + 1)*scale;
	if (w > 0 && h > 0) {
		SDL_Rect rc = {x0*scale,y0*scale, w,h};
		SDL_FillRect(screen, &rc, getcolor(col));
	}
}

static void p8_print(const char* str, int x, int y, int col) {
	for (char c = *str; c; c = *(++str)) {
		c &= 0x7F;
		SDL_Rect srcrc = {8*(c%16), 8*(c/16)};
		srcrc.x *= scale;
		srcrc.y *= scale;
		srcrc.w = srcrc.h = 8*scale;
		
		SDL_Rect dstrc = {x*scale, y*scale, scale, scale};
		Xblit(font, &srcrc, screen, &dstrc, col, 0,0);
		x += 4;
	}
}

int pico8emu(CELESTE_P8_CALLBACK_TYPE call, ...) {
	static int camera_x = 0, camera_y = 0;
	if (!enable_screenshake) {
		camera_x = camera_y = 0;
	}

	va_list args;
	int ret = 0;
	va_start(args, call);
	
	#define   INT_ARG() va_arg(args, int)
	#define  BOOL_ARG() (Celeste_P8_bool_t)va_arg(args, int)
	#define RET_INT(_i)   do {ret = (_i); goto end;} while (0)
	#define RET_BOOL(_b) RET_INT(!!(_b))

	switch (call) {
		case CELESTE_P8_MUSIC: { //music(idx,fade,mask)
			int index = INT_ARG();
			int fade = INT_ARG();
			int mask = INT_ARG();

			(void)mask; //we do not care about this since sdl mixer keeps sounds and music separate
			
			if (index == -1) { //stop playing
				music_stop(fade);
				current_music = -1;
			} else if (music_available(index/10)) {
				current_music = index/10;
				music_play(index/10, fade);
			}
		} break;
		case CELESTE_P8_SPR: { //spr(sprite,x,y,cols,rows,flipx,flipy)
			int sprite = INT_ARG();
			int x = INT_ARG();
			int y = INT_ARG();
			int cols = INT_ARG();
			int rows = INT_ARG();
			int flipx = BOOL_ARG();
			int flipy = BOOL_ARG();

			(void)cols;
			(void)rows;

			assert(rows == 1 && cols == 1);

			if (sprite >= 0) {
				SDL_Rect srcrc = {
					8*(sprite % 16),
					8*(sprite / 16)
				};
				srcrc.x *= scale;
				srcrc.y *= scale;
				srcrc.w = srcrc.h = scale*8;
				SDL_Rect dstrc = {
					(x - camera_x)*scale, (y - camera_y)*scale,
					scale, scale
				};
				Xblit(gfx, &srcrc, screen, &dstrc, 0,flipx,flipy);
			}
		} break;
		case CELESTE_P8_BTN: { //btn(b)
			int b = INT_ARG();
			assert(b >= 0 && b <= 5); 
			RET_BOOL(buttons_state & (1 << b));
		} break;
		case CELESTE_P8_SFX: { //sfx(id)
			int id = INT_ARG();
		
			if (id < (sizeof snd) / (sizeof*snd) && snd[id]) {
				Mix_VolumeChunk(snd[id], audio_vol(cfg_sound));
				Mix_PlayChannel(-1, snd[id], 0);
			}
		} break;
		case CELESTE_P8_PAL: { //pal(a,b)
			int a = INT_ARG();
			int b = INT_ARG();
			if (a >= 0 && a < 16 && b >= 0 && b < 16) {
				//swap palette colors
				palette[a] = base_palette[b];
			}
		} break;
		case CELESTE_P8_PAL_RESET: { //pal()
			ResetPalette();
		} break;
		case CELESTE_P8_CIRCFILL: { //circfill(x,y,r,col)
			int cx = INT_ARG() - camera_x;
			int cy = INT_ARG() - camera_y;
			int r = INT_ARG();
			int col = INT_ARG();

			int realcolor = getcolor(col);

			if (r <= 1) {
				SDL_FillRect(screen, &(SDL_Rect){scale*(cx-1), scale*cy, scale*3, scale}, realcolor);
				SDL_FillRect(screen, &(SDL_Rect){scale*cx, scale*(cy-1), scale, scale*3}, realcolor);
			} else if (r <= 2) {
				SDL_FillRect(screen, &(SDL_Rect){scale*(cx-2), scale*(cy-1), scale*5, scale*3}, realcolor);
				SDL_FillRect(screen, &(SDL_Rect){scale*(cx-1), scale*(cy-2), scale*3, scale*5}, realcolor);
			} else if (r <= 3) {
				SDL_FillRect(screen, &(SDL_Rect){scale*(cx-3), scale*(cy-1), scale*7, scale*3}, realcolor);
				SDL_FillRect(screen, &(SDL_Rect){scale*(cx-1), scale*(cy-3), scale*3, scale*7}, realcolor);
				SDL_FillRect(screen, &(SDL_Rect){scale*(cx-2), scale*(cy-2), scale*5, scale*5}, realcolor);
			} else { //i dont think the game uses this
				int f = 1 - r; //used to track the progress of the drawn circle (since its semi-recursive)
				int ddFx = 1; //step x
				int ddFy = -2 * r; //step y
				int x = 0;
				int y = r;

				//this algorithm doesn't account for the diameters
				//so we have to set them manually
				p8_line(cx,cy-y, cx,cy+r, col);
				p8_line(cx+r,cy, cx-r,cy, col);

				while (x < y) {
					if (f >= 0) {
						y--;
						ddFy += 2;
						f += ddFy;
					}
					x++;
					ddFx += 2;
					f += ddFx;

					//build our current arc
					p8_line(cx+x,cy+y, cx-x,cy+y, col);
					p8_line(cx+x,cy-y, cx-x,cy-y, col);
					p8_line(cx+y,cy+x, cx-y,cy+x, col);
					p8_line(cx+y,cy-x, cx-y,cy-x, col);
				}
			}
		} break;
		case CELESTE_P8_PRINT: { //print(str,x,y,col)
			const char* str = va_arg(args, const char*);
			int x = INT_ARG() - camera_x;
			int y = INT_ARG() - camera_y;
			int col = INT_ARG() % 16;

#ifdef _3DS
			if (!strcmp(str, "x+c")) {
				//this is confusing, as 3DS uses a+b button, so use this hack to make it more appropiate
				str = "a+b";
			}
#endif

			p8_print(str,x,y,col);
		} break;
		case CELESTE_P8_RECTFILL: { //rectfill(x0,y0,x1,y1,col)
			int x0 = INT_ARG() - camera_x;
			int y0 = INT_ARG() - camera_y;
			int x1 = INT_ARG() - camera_x;
			int y1 = INT_ARG() - camera_y;
			int col = INT_ARG();

			p8_rectfill(x0,y0,x1,y1,col);
		} break;
		case CELESTE_P8_LINE: { //line(x0,y0,x1,y1,col)
			int x0 = INT_ARG() - camera_x;
			int y0 = INT_ARG() - camera_y;
			int x1 = INT_ARG() - camera_x;
			int y1 = INT_ARG() - camera_y;
			int col = INT_ARG();

			p8_line(x0,y0,x1,y1,col);
		} break;
		case CELESTE_P8_MGET: { //mget(tx,ty)
			int tx = INT_ARG();
			int ty = INT_ARG();

			RET_INT(tilemap_data[tx+ty*128]);
		} break;
		case CELESTE_P8_CAMERA: { //camera(x,y)
			if (enable_screenshake) {
				camera_x = INT_ARG();
				camera_y = INT_ARG();
			}
		} break;
		case CELESTE_P8_FGET: { //fget(tile,flag)
			int tile = INT_ARG();
			int flag = INT_ARG();

			RET_INT(gettileflag(tile, flag));
		} break;
		case CELESTE_P8_MAP: { //map(mx,my,tx,ty,mw,mh,mask)
			int mx = INT_ARG(), my = INT_ARG();
			int tx = INT_ARG(), ty = INT_ARG();
			int mw = INT_ARG(), mh = INT_ARG();
			int mask = INT_ARG();
			
			for (int x = 0; x < mw; x++) {
				for (int y = 0; y < mh; y++) {
					int tile = tilemap_data[x + mx + (y + my)*128];
					//hack
					if (mask == 0 || (mask == 4 && tile_flags[tile] == 4) || gettileflag(tile, mask != 4 ? mask-1 : mask)) {
						SDL_Rect srcrc = {
							8*(tile % 16),
							8*(tile / 16)
						};
						srcrc.x *= scale;
						srcrc.y *= scale;
						srcrc.w = srcrc.h = scale*8;
						SDL_Rect dstrc = {
							(tx+x*8 - camera_x)*scale, (ty+y*8 - camera_y)*scale,
							scale*8, scale*8
						};

						if (0) {
							srcrc.x = srcrc.y = 0;
							srcrc.w = srcrc.h = 8;
							dstrc.x = x*8, dstrc.y = y*8;
							dstrc.w = dstrc.h = 8;
						}

						Xblit(gfx, &srcrc, screen, &dstrc, 0, 0, 0);
					}
				}
			}
		} break;
	}

	end:
	va_end(args);
	return ret;
}

static int gettileflag(int tile, int flag) {
	return tile < sizeof(tile_flags)/sizeof(*tile_flags) && (tile_flags[tile] & (1 << flag)) != 0;
}

//coordinates should NOT be scaled before calling this
static void p8_line(int x0, int y0, int x1, int y1, unsigned char color) {
	#define CLAMP(v,min,max) v = v < min ? min : v >= max ? max-1 : v;
	CLAMP(x0,0,screen->w);
	CLAMP(y0,0,screen->h);
	CLAMP(x1,0,screen->w);
	CLAMP(y1,0,screen->h);

	Uint32 realcolor = getcolor(color);

	#undef CLAMP
  #define PLOT(x,y) do {                                                        \
     SDL_FillRect(screen, &(SDL_Rect){x*scale,y*scale,scale,scale}, realcolor); \
	} while (0)
	int sx, sy, dx, dy, err, e2;
	dx = abs(x1 - x0);
	dy = abs(y1 - y0);
	if (!dx && !dy) return;

	if (x0 < x1) sx = 1; else sx = -1;
	if (y0 < y1) sy = 1; else sy = -1;
	err = dx - dy;
	if (!dy && !dx) return;
	else if (!dx) { //vertical line
		for (int y = y0; y != y1; y += sy) PLOT(x0,y);
	} else if (!dy) { //horizontal line
		for (int x = x0; x != x1; x += sx) PLOT(x,y0);
	} while (x0 != x1 || y0 != y1) {
		PLOT(x0, y0);
		e2 = 2 * err;
		if (e2 > -dy) {
			err -= dy;
			x0 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y0 += sy;
		}
	}
	#undef PLOT
}

#if SDL_MAJOR_VERSION >= 2
//SDL2: read input from connected gamepad

struct mapping {
	SDL_GameControllerButton sdl_btn;
	Uint16 pico8_btn;
};
static const char* pico8_btn_names[] = {
	"left", "right", "up", "down", "jump", "dash", "save", "load", "exit", "pause"
};

// initialized with default mapping
static struct mapping controller_mappings[30] = {
	{SDL_CONTROLLER_BUTTON_DPAD_LEFT,  0}, //left
	{SDL_CONTROLLER_BUTTON_DPAD_RIGHT, 1}, //right
	{SDL_CONTROLLER_BUTTON_DPAD_UP,    2}, //up
	{SDL_CONTROLLER_BUTTON_DPAD_DOWN,  3}, //down
	{SDL_CONTROLLER_BUTTON_A,          4}, //jump
	{SDL_CONTROLLER_BUTTON_B,          5}, //dash

	{SDL_CONTROLLER_BUTTON_LEFTSHOULDER,  PSEUDO_BTN_SAVE_STATE}, //save
	{SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, PSEUDO_BTN_LOAD_STATE}, //load
	{SDL_CONTROLLER_BUTTON_GUIDE,         PSEUDO_BTN_EXIT}, //exit
	{SDL_CONTROLLER_BUTTON_START,         PSEUDO_BTN_PAUSE}, //pause
	{0xff, 0xff}
};
static const Uint16 stick_deadzone = 32767 / 2; //about half

static void ReadGamepadInput(Uint16* out_buttons) {
	static _Bool read_config = 0;
	if (!read_config) {
		read_config = 1;
		const char* cfg_file_path = getenv("CCLESTE_INPUT_CFG_PATH");
		if (!cfg_file_path) {
			cfg_file_path  = "ccleste-input-cfg.txt";
		}
		FILE* cfg = fopen(cfg_file_path, "r");
		if (cfg) {
			int i;
			for (i = 0; i < sizeof controller_mappings / sizeof *controller_mappings - 1;) {
				char line[150], p8btn[31], sdlbtn[31];
				fgets(line, sizeof line - 1, cfg);
				if (feof(cfg) || ferror(cfg)) break;
				line[sizeof line - 1] = 0;
				if (*line == '#') {
					//comment
				} else if (sscanf(line, "%30s %30s", p8btn, sdlbtn) == 2) {
					p8btn[sizeof p8btn - 1] = sdlbtn[sizeof sdlbtn - 1] = 0;
					for (int btn = 0; btn < sizeof pico8_btn_names / sizeof *pico8_btn_names; btn++) {
						if (!SDL_strcasecmp(pico8_btn_names[btn], p8btn)) {
							printf("input cfg: %s -> %s\n", p8btn, sdlbtn);
							controller_mappings[i].sdl_btn = SDL_GameControllerGetButtonFromString(sdlbtn);
							controller_mappings[i].pico8_btn = btn;
							i++;
						}
					}
				}
			}
			controller_mappings[i].pico8_btn = 0xFF;
			fclose(cfg);
		} else {
			cfg = fopen(cfg_file_path, "w");
			if (cfg) {
				printf("creating ccleste-input-cfg.txt with default button mappings\n");
				fprintf(cfg, "# in-game \tcontroller\n");
				for (struct mapping* mapping = controller_mappings; mapping->pico8_btn != 0xFF; mapping++) {
					fprintf(cfg, "%s \t%s\n", pico8_btn_names[mapping->pico8_btn], SDL_GameControllerGetStringForButton(mapping->sdl_btn));
				}
				fclose(cfg);
			}
		}
	}

	static SDL_GameController* controller = NULL;
	if (!controller) {
		static int tries_left = 30;
		if (!tries_left) return;
		tries_left--;

		//use first available controller
		int count = SDL_NumJoysticks();
		printf("sdl reports %i controllers\n", count);
		for (int i = 0; i < count; i++) {
			if (SDL_IsGameController(i)) {
				controller = SDL_GameControllerOpen(i);
				if (!controller) {
					fprintf(stderr, "error opening controller: %s\n", SDL_GetError());
					return;
				}
				printf("picked controller: '%s'\n", SDL_GameControllerName(controller));
				break;
			}
		}
	}

	//pico 8 buttons and pseudo buttons
	for (int i = 0; i < sizeof controller_mappings / sizeof *controller_mappings; i++) {
		struct mapping mapping = controller_mappings[i];
		if (mapping.pico8_btn == 0xFF) break;
		_Bool pressed = SDL_GameControllerGetButton(controller, mapping.sdl_btn);
		Uint16 mask = ~(1 << mapping.pico8_btn);
		*out_buttons = (*out_buttons & mask) | (pressed << mapping.pico8_btn);
	}

	//joystick -> dpad input
	Sint16 x_axis = SDL_GameControllerGetAxis(controller, SDL_CONTROLLER_AXIS_LEFTX);
	Sint16 y_axis = SDL_GameControllerGetAxis(controller, SDL_CONTROLLER_AXIS_LEFTY);
	if (x_axis < -stick_deadzone) *out_buttons |= (1 << 0); //left
	if (x_axis >  stick_deadzone) *out_buttons |= (1 << 1); //right
	if (y_axis < -stick_deadzone) *out_buttons |= (1 << 2); //up
	if (y_axis >  stick_deadzone) *out_buttons |= (1 << 3); //down
}
#endif


// vim: ts=2 sw=2 noexpandtab
