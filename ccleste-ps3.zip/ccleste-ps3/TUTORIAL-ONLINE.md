# Coop online no PS3 com relay no Termux

## Como funciona

1. O **host** digita no jogo o IP do celular onde roda o relay (Termux).
2. O relay cria uma sala e devolve um **código de 16 caracteres** (`XXXX-XXXX-XXXX-XXXX`).
   Ele aparece na tela do host e no Termux.
3. O **convidado** digita esse código. O jogo decodifica o endereço público do relay e a sala e conecta.
4. O relay junta os dois e a partida começa. Quem criou é o jogador 1.

O código guarda o **endereço público do relay + a sala + um checksum**. Um erro de digitação é
detectado na hora. Ele **não é criptografia forte**: só esconde o endereço e evita typos. Trate como senha.
Cada código vale **uma partida**: depois que o convidado entra, ele deixa de funcionar.

Ninguém precisa abrir porta no roteador. Só uma pessoa roda o Termux.

> **Cloudflare não funciona aqui.** O túnel rápido só expõe HTTP, e o TCP exige o `cloudflared`
> no cliente, que o PS3 não roda. Use bore ou playit.gg (abaixo).

## 1. Instalar o relay no Termux

```bash
pkg update && pkg install python
termux-setup-storage
cp ~/storage/downloads/relay.py ~/relay.py     # depois de baixar o relay.py pro celular
termux-wake-lock                               # evita o Android dormir o Termux
```

Opcional: `pkg install termux-api` (e o app Termux:API) pra o código aparecer também como notificação.

## 2. Rodar o relay (escolha um modo)

### Modo A: mesma rede Wi-Fi (sem túnel)

```bash
python relay.py
```

O código aponta pro IP do celular na rede local. Só funciona com os dois PS3 na mesma rede.

### Modo B: internet com bore (automático)

```bash
pkg install rust
cargo install bore-cli          # demora uns 10 min na primeira vez
python relay.py --bore
```

O relay abre o túnel sozinho, lê o endereço público (`bore.pub:porta`) e já coloca no código.
A porta do bore muda a cada execução, mas como o código é gerado na hora, **você não precisa
configurar nada nos PS3**.

### Modo C: internet com um túnel que você já tem (playit.gg etc.)

Crie um túnel **TCP** apontando pra porta local `7777` e rode:

```bash
python relay.py --public algo.ply.gg:12345
```

Não testei o playit no Termux. Se o agente não rodar direto, use `proot-distro` com Ubuntu.

Quando o relay estiver pronto, aparece `relay listening on port 7777`. Deixe a sessão aberta.

## 3. Jogar

**Host (quem tem o celular com o relay):**
1. **jogar > coop > online > criar host**
2. Digite o **IP do celular** (cima/baixo muda o número, esquerda/direita troca o campo, L1/R1 pula de 10 em 10).
   No Termux: `ip addr show wlan0 | grep inet`. O jogo lembra o último IP digitado.
3. Aperte **X**. A tela mostra o código. Passe pro outro jogador (aparece também no Termux).

**Convidado:**
1. **jogar > coop > online > entrar no host**
2. Digite o código (cima/baixo muda a letra, esquerda/direita troca a posição, X avança e conecta na última).

Quando o convidado entra, a partida começa sozinha. Cada um usa o **controle 1 do próprio PS3**.

## Problemas comuns

| Mensagem / sintoma | O que fazer |
|:--|:--|
| "nao consegui falar com o relay" | Relay fechado, IP do celular errado, ou os dois fora da mesma rede (no host) |
| "codigo invalido" | Erro de digitação em algum caractere |
| "codigo nao vale mais" | O host saiu, ou o código já foi usado. O host cria outro |
| Convidado não conecta no modo A | Modo A só funciona na mesma rede. Use `--bore` |
| "waiting for the other player..." | Lag ou queda. Se passar de ~20 s, volta pro título |
| "out of sync!" | Os dois mundos divergiram. Confira se têm **o mesmo build** e saia pro título |
| Tela congela ao conectar | O PS3 espera até ~8 s pelo relay. Se estiver fora do ar, espere |

## Limitações

- Online não tem pausa, save state, load state nem autosave (pra não bagunçar o seu save).
- Os dois PS3 precisam do mesmo build do jogo.
- A customização de visual é local: cada um vê os personagens com o próprio visual.
- O relay aceita qualquer um que tenha o endereço, mas só entra quem tem um código válido de uma sala aberta.
- Porta do relay diferente de 7777: use `python relay.py 9000` e coloque `port=9000` no `ccleste-net.cfg`
  (o jogo cria esse arquivo ao lado do EBOOT.BIN com o último IP).

## Compilar e testar

```bash
export PS3DEV=/usr/local/ps3dev PSL1GHT=$PS3DEV PORTLIBS=$PS3DEV/portlibs/ppu
make -f Makefile.ps3 ccleste.pkg
```

Se der erro de header ou de link na parte de rede (`net/net.h`, `netInitialize`...), pode faltar
`-lsysmodule` no `LDLIBS` do `Makefile.ps3` ou o nome de alguma função diferir na sua versão do SDK.
Me mande a saída do make que eu ajusto.

Teste do lockstep e dos códigos no PC, sem console nenhum:

```bash
python3 tools/relay.py 17777 --public 127.0.0.1:17777 &
gcc -O1 -I. tools/net_test.c celeste.c -lm -o net_test && ./net_test 17777
```

Deve terminar com `PASS: both consoles ended in the same state`.
