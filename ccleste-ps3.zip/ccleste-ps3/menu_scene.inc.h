// Animated title scenery for the menu (sky, twinkling stars, shooting stars, swaying pines, mountain, cliff, drifting
// snow / fireflies, floating logo). No SDL in here: it draws into a 32-bit 0x00RRGGBB buffer (the 456x256 HD game
// surface), so the same code runs in the game (menu.inc.c) and in tools/menu_preview.c.
//
//   int  mscene_load(const char* path);                    // data/menu_art.bin ; 0 = ok
//   void mscene_draw(uint32_t* px, int pitch_words, int w, int h, float t, int flags);
//        t = seconds since the menu opened (the whole animation is a function of t, so it does not depend on the frame rate)
//        flags: MSCENE_TITLE draws the logo + sparkles (the sub menus only get the scenery)
//
// Atlas (data/menu_art.bin, little endian, made by tools/gen_menu_art.py):
//   "MNA1", u16 count, count * { char name[24]; i16 x, y; u16 w, h; i16 px, py; u32 offset }, then RGBA8 (straight alpha)
//   sprites: sky (opaque, no stars), mountain, cliff, title, treeN (swaying; pivot = trunk base), spark
// menu_art.inc.h (same script) holds the star list and the sparkle positions of the logo.
#ifndef MENU_SCENE_INC_H_
#define MENU_SCENE_INC_H_

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "menu_art.inc.h"

#define MSCENE_TITLE 1
#define MSCENE_DIM   2      // darkened scenery (sub menus)

#define MS_W 456
#define MS_H 256
#define MS_MAX_SPR 16

typedef struct {
	char name[24];
	int x, y, w, h, px, py;
	uint32_t* pm;               // premultiplied ARGB (A in the top byte)
	uint32_t* pmd;              // the same, darkened (sub menus: MSCENE_DIM)
	int16_t* lo; int16_t* hi;   // first / last non-transparent column of every row (lo > hi: empty row)
	uint8_t* rp;                // trees: (height above the pivot / height)^1.4 * 256 per row
	float amp, phase;           // trees: sway amplitude (px at the tip) and phase
} ms_spr_t;

static ms_spr_t ms_spr[MS_MAX_SPR];
static int ms_nspr = 0, ms_loaded = 0;
static ms_spr_t *ms_sky, *ms_mountain, *ms_cliff, *ms_title;
static ms_spr_t* ms_trees[8]; static int ms_ntrees = 0;
static uint8_t* ms_tglow = NULL; static int ms_tglow_w, ms_tglow_h;   // blurred logo alpha (+ms_TG margin)
static int32_t* ms_hl_off = NULL; static uint8_t* ms_hl_a = NULL; static int ms_hl_n = 0;   // halo pixels that matter (logo alpha < 255)
#define MS_TG 9
static uint8_t* ms_kern = NULL;                                       // radial falloff 0..255, radius MS_KR
#define MS_KR 48
static uint8_t ms_sin[256];                                           // 0..255 (one full period)

// ---------------------------------------------------------------- small helpers
static inline uint32_t ms_hash(uint32_t x) {
	x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x;
}
static inline float ms_rnd(uint32_t seed) { return (ms_hash(seed) & 0xffffff) / 16777216.0f; }
static inline int ms_clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

// premultiplied pixel over an opaque pixel
static inline uint32_t ms_over(uint32_t d, uint32_t s) {
	const uint32_t a = s >> 24;
	if (a == 255) return s & 0xffffff;
	if (a == 0) return d;
	const uint32_t ia = 256 - a;
	const uint32_t rb = (((d & 0xff00ff) * ia) >> 8) & 0xff00ff;
	const uint32_t g  = (((d & 0x00ff00) * ia) >> 8) & 0x00ff00;
	return (s & 0xffffff) + (rb | g);
}
// d + c*a (a = 0..256), saturating
static inline uint32_t ms_add(uint32_t d, uint32_t c, int a) {
	int r = ((d >> 16) & 255) + ((((c >> 16) & 255) * a) >> 8);
	int g = ((d >> 8) & 255)  + ((((c >> 8) & 255) * a) >> 8);
	int b = (d & 255)         + (((c & 255) * a) >> 8);
	if (r > 255) r = 255;
	if (g > 255) g = 255;
	if (b > 255) b = 255;
	return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}
// d moved towards c by a/256
static inline uint32_t ms_mix(uint32_t d, uint32_t c, int a) {
	const uint32_t rb = ((d & 0xff00ff) * (256 - a) + (c & 0xff00ff) * a) >> 8;
	const uint32_t g  = ((d & 0x00ff00) * (256 - a) + (c & 0x00ff00) * a) >> 8;
	return (rb & 0xff00ff) | (g & 0x00ff00);
}
static inline void ms_plot_add(uint32_t* px, int pitch, int w, int h, int x, int y, uint32_t c, int a) {
	if ((unsigned)x < (unsigned)w && (unsigned)y < (unsigned)h) { uint32_t* p = px + (size_t)y * pitch + x; *p = ms_add(*p, c, a); }
}
static inline void ms_plot_mix(uint32_t* px, int pitch, int w, int h, int x, int y, uint32_t c, int a) {
	if ((unsigned)x < (unsigned)w && (unsigned)y < (unsigned)h) { uint32_t* p = px + (size_t)y * pitch + x; *p = ms_mix(*p, c, a); }
}

// ---------------------------------------------------------------- loading
static ms_spr_t* ms_find(const char* name) {
	for (int i = 0; i < ms_nspr; i++) if (strcmp(ms_spr[i].name, name) == 0) return &ms_spr[i];
	return NULL;
}

static int mscene_load(const char* path) {
	ms_loaded = 0; ms_nspr = 0; ms_ntrees = 0;
	FILE* f = fopen(path, "rb");
	if (!f) return -1;
	fseek(f, 0, SEEK_END); long len = ftell(f); fseek(f, 0, SEEK_SET);
	if (len < 6) { fclose(f); return -2; }
	uint8_t* buf = (uint8_t*)malloc((size_t)len);
	if (!buf) { fclose(f); return -3; }
	if (fread(buf, 1, (size_t)len, f) != (size_t)len) { free(buf); fclose(f); return -4; }
	fclose(f);
	if (memcmp(buf, "MNA1", 4) != 0) { free(buf); return -5; }
	int count = buf[4] | (buf[5] << 8);
	if (count > MS_MAX_SPR) count = MS_MAX_SPR;
	for (int i = 0; i < count; i++) {
		const uint8_t* e = buf + 6 + 40 * i;
		if (6 + 40 * (i + 1) > len) break;
		ms_spr_t* s = &ms_spr[ms_nspr];
		memset(s, 0, sizeof *s);
		memcpy(s->name, e, 23);
		s->x = (int16_t)(e[24] | (e[25] << 8)); s->y = (int16_t)(e[26] | (e[27] << 8));
		s->w = e[28] | (e[29] << 8);            s->h = e[30] | (e[31] << 8);
		s->px = (int16_t)(e[32] | (e[33] << 8)); s->py = (int16_t)(e[34] | (e[35] << 8));
		const uint32_t off = e[36] | (e[37] << 8) | (e[38] << 16) | ((uint32_t)e[39] << 24);
		if (s->w <= 0 || s->h <= 0 || (long)off + (long)s->w * s->h * 4 > len) continue;
		s->pm = (uint32_t*)malloc((size_t)s->w * s->h * 4);
		s->pmd = (uint32_t*)malloc((size_t)s->w * s->h * 4);
		s->lo = (int16_t*)malloc(s->h * sizeof(int16_t)); s->hi = (int16_t*)malloc(s->h * sizeof(int16_t));
		if (!s->pm || !s->pmd || !s->lo || !s->hi) continue;
		const uint8_t* src = buf + off;
		for (int y = 0; y < s->h; y++) {
			int lo = s->w, hi = -1;
			for (int x = 0; x < s->w; x++) {
				const uint8_t* q = src + ((size_t)y * s->w + x) * 4;
				const uint32_t a = q[3];
				s->pm[(size_t)y * s->w + x] = (a << 24) | ((uint32_t)(q[0] * a / 255) << 16) | ((uint32_t)(q[1] * a / 255) << 8) | (uint32_t)(q[2] * a / 255);
				{   // darkened copy: colour * 0.53 + a bit of deep blue (premultiplied)
					const uint32_t c = s->pm[(size_t)y * s->w + x];
					const uint32_t rb = ((((c & 0xff00ff) * 136) >> 8) & 0xff00ff) + (((0x05 * a / 255 * 120 / 256) << 16) | (0x1a * a / 255 * 120 / 256));
					const uint32_t g = ((((c & 0x00ff00) * 136) >> 8) & 0x00ff00) + ((0x03 * a / 255 * 120 / 256) << 8);
					s->pmd[(size_t)y * s->w + x] = (a << 24) | rb | g;
				}
				if (a > 0) { if (x < lo) lo = x; hi = x; }
			}
			s->lo[y] = (int16_t)lo; s->hi[y] = (int16_t)hi;
		}
		ms_nspr++;
	}
	free(buf);

	ms_sky = ms_find("sky"); ms_mountain = ms_find("mountain"); ms_cliff = ms_find("cliff"); ms_title = ms_find("title");
	// swaying trees: every sprite called treeN, drawn from the shortest to the tallest
	for (int i = 0; i < ms_nspr && ms_ntrees < 8; i++)
		if (strncmp(ms_spr[i].name, "tree", 4) == 0) ms_trees[ms_ntrees++] = &ms_spr[i];
	for (int i = 1; i < ms_ntrees; i++) for (int j = i; j > 0 && ms_trees[j]->h < ms_trees[j - 1]->h; j--) {
		ms_spr_t* t = ms_trees[j]; ms_trees[j] = ms_trees[j - 1]; ms_trees[j - 1] = t;
	}
	for (int i = 0; i < ms_ntrees; i++) {
		ms_spr_t* s = ms_trees[i];
		s->amp = s->h * 0.011f; if (s->amp < 0.3f) s->amp = 0.3f; if (s->amp > 1.9f) s->amp = 1.9f;
		s->phase = 1.7f * i + 0.6f;
		s->rp = (uint8_t*)malloc(s->h);
		const float ph = (float)(s->py > 1 ? s->py : 1);
		for (int y = 0; y < s->h; y++) {
			float r = (ph - y) / ph; if (r < 0) r = 0; if (r > 1) r = 1;
			s->rp[y] = (uint8_t)(powf(r, 1.4f) * 255.0f + 0.5f);
		}
	}

	for (int i = 0; i < 256; i++) ms_sin[i] = (uint8_t)(127.5f + 127.5f * sinf(i * 6.2831853f / 256.0f));

	// radial falloff for the soft glows
	if (!ms_kern) {
		ms_kern = (uint8_t*)malloc((2 * MS_KR + 1) * (2 * MS_KR + 1));
		for (int y = -MS_KR; y <= MS_KR; y++) for (int x = -MS_KR; x <= MS_KR; x++) {
			float d = sqrtf((float)(x * x + y * y)) / MS_KR; float v = d >= 1 ? 0 : (1 - d); v = v * v * (3 - 2 * v);
			ms_kern[(y + MS_KR) * (2 * MS_KR + 1) + x + MS_KR] = (uint8_t)(v * 255);
		}
	}

	// halo of the logo: its alpha blurred (box x2)
	if (ms_title && !ms_tglow) {
		const int gw = ms_title->w + 2 * MS_TG, gh = ms_title->h + 2 * MS_TG;
		uint8_t* a = (uint8_t*)calloc((size_t)gw * gh, 1); uint8_t* b = (uint8_t*)calloc((size_t)gw * gh, 1);
		for (int y = 0; y < ms_title->h; y++) for (int x = 0; x < ms_title->w; x++)
			a[(y + MS_TG) * gw + x + MS_TG] = (uint8_t)(ms_title->pm[y * ms_title->w + x] >> 24);
		for (int pass = 0; pass < 3; pass++) {
			const int R = 3;
			for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {          // horizontal
				int sum = 0, n = 0;
				for (int k = -R; k <= R; k++) { int xx = x + k; if (xx >= 0 && xx < gw) { sum += a[y * gw + xx]; n++; } }
				b[y * gw + x] = (uint8_t)(sum / (2 * R + 1));
			}
			for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {          // vertical
				int sum = 0;
				for (int k = -R; k <= R; k++) { int yy = y + k; if (yy >= 0 && yy < gh) sum += b[yy * gw + x]; }
				a[y * gw + x] = (uint8_t)(sum / (2 * R + 1));
			}
		}
		free(b); ms_tglow = a; ms_tglow_w = gw; ms_tglow_h = gh;
		ms_hl_off = (int32_t*)malloc((size_t)gw * gh * 4); ms_hl_a = (uint8_t*)malloc((size_t)gw * gh);
		ms_hl_n = 0;
		for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
			const int ty = y - MS_TG, tx = x - MS_TG;
			const int covered = ty >= 0 && tx >= 0 && ty < ms_title->h && tx < ms_title->w && (ms_title->pm[ty * ms_title->w + tx] >> 24) == 255;
			if (a[y * gw + x] > 2 && !covered) { ms_hl_off[ms_hl_n] = y * gw + x; ms_hl_a[ms_hl_n++] = a[y * gw + x]; }
		}
	}
	ms_loaded = ms_sky != NULL;
	return ms_loaded ? 0 : -6;
}

// ---------------------------------------------------------------- sprite blits
static void ms_blit(uint32_t* px, int pitch, int W, int H, const ms_spr_t* s, int dx, int dy, int ga /*0..256 global alpha*/, int dim) {
	for (int y = 0; y < s->h; y++) {
		const int Y = dy + y;
		if ((unsigned)Y >= (unsigned)H) continue;
		int lo = s->lo[y], hi = s->hi[y];
		if (lo > hi) continue;
		if (dx + lo < 0) lo = -dx;
		if (dx + hi >= W) hi = W - 1 - dx;
		const uint32_t* sp = (dim ? s->pmd : s->pm) + (size_t)y * s->w;
		uint32_t* dp = px + (size_t)Y * pitch + dx;
		if (ga >= 256) {
			for (int x = lo; x <= hi; x++) {
				const uint32_t c = sp[x];
				if (c >= 0xff000000u) dp[x] = c & 0xffffff;          // opaque: plain copy (most pixels)
				else if (c) dp[x] = ms_over(dp[x], c);
			}
		}
		else for (int x = lo; x <= hi; x++) {
			uint32_t c = sp[x];
			const uint32_t a = ((c >> 24) * ga) >> 8;
			const uint32_t rb = (((c & 0xff00ff) * ga) >> 8) & 0xff00ff, g = (((c & 0x00ff00) * ga) >> 8) & 0x00ff00;
			dp[x] = ms_over(dp[x], (a << 24) | rb | g);
		}
	}
}

// pine swaying: every row is shifted sideways by a sub-pixel amount that grows towards the tip
static void ms_blit_sway(uint32_t* px, int pitch, int W, int H, const ms_spr_t* s, int dx, int dy, float tip /* px, signed */, int dim) {
	const int tip16 = (int)floorf(tip * 16.0f + 0.5f);
	for (int y = 0; y < s->h; y++) {
		const int Y = dy + y;
		if ((unsigned)Y >= (unsigned)H) continue;
		const int lo = s->lo[y], hi = s->hi[y];
		if (lo > hi) continue;
		const int sh = (tip16 * s->rp[y]) / 255;           // 1/16 px
		const int ix = sh >> 4, fx = sh & 15;              // floor division: fx is always 0..15
		const uint32_t* sp = (dim ? s->pmd : s->pm) + (size_t)y * s->w;
		uint32_t* dp = px + (size_t)Y * pitch;
		// output column o (in sprite space, before the shift) covers source pixels o and o-1
		int o0 = lo, o1 = hi + (fx ? 1 : 0);
		if (dx + ix + o0 < 0) o0 = -dx - ix;
		if (dx + ix + o1 >= W) o1 = W - 1 - dx - ix;
		for (int o = o0; o <= o1; o++) {
			const uint32_t c1 = (o <= hi) ? sp[o] : 0, c0 = (o - 1 >= lo && o - 1 >= 0) ? sp[o - 1] : 0;
			uint32_t c = c1;
			if (fx) {
				const uint32_t rb = (((c1 & 0xff00ff) * (16 - fx) + (c0 & 0xff00ff) * fx) >> 4) & 0xff00ff;
				const uint32_t ag = ((((c1 >> 8) & 0xff00ff) * (16 - fx) + ((c0 >> 8) & 0xff00ff) * fx) >> 4) & 0xff00ff;
				c = rb | (ag << 8);
			}
			uint32_t* d = dp + dx + ix + o;
			*d = ms_over(*d, c);
		}
	}
}

// ---------------------------------------------------------------- effects
// soft round glow with the shared kernel (radius <= MS_KR, strength 0..256)
static void ms_glow(uint32_t* px, int pitch, int W, int H, int cx, int cy, int radius, uint32_t rgb, int strength) {
	if (radius > MS_KR) radius = MS_KR;
	if (radius < 1 || strength <= 0) return;
	const int step = (MS_KR * 256) / radius;   // kernel coordinate per pixel, 8.8
	for (int y = -radius; y <= radius; y++) {
		const int Y = cy + y; if ((unsigned)Y >= (unsigned)H) continue;
		const int ky = ((y * step) >> 8) + MS_KR;
		for (int x = -radius; x <= radius; x++) {
			const int X = cx + x; if ((unsigned)X >= (unsigned)W) continue;
			const int kx = ((x * step) >> 8) + MS_KR;
			const int a = (ms_kern[ky * (2 * MS_KR + 1) + kx] * strength) >> 8;
			if (a) { uint32_t* p = px + (size_t)Y * pitch + X; *p = ms_add(*p, rgb, a); }
		}
	}
}

static void ms_stars(uint32_t* px, int pitch, int W, int H, float t) {
	const int tt = (int)(t * 40.74f);                      // 256 steps = 2*pi
	for (int i = 0; i < MENU_STAR_COUNT; i++) {
		const menu_star_t* s = &menu_stars[i];
		const uint32_t h = ms_hash((uint32_t)i * 2654435761u + 17u);
		const int speed = 28 + (h & 63);                    // 0.7 .. 2.3 rad/s
		const int idx = (int)(((uint32_t)tt * speed) >> 5) + (int)((h >> 8) & 255);
		int tw = ms_sin[idx & 255];                         // 0..255
		tw = 70 + ((tw * tw) >> 9) * 2 / 1;                 // 70 .. 325 -> clamp below
		if (tw > 256) tw = 256;
		if (s->sz == 0 && (h & 0x300) == 0) tw = 120 + (tw >> 1);   // some of the small ones are steady
		const uint32_t c = ((uint32_t)s->r << 16) | ((uint32_t)s->g << 8) | s->b;
		ms_plot_mix(px, pitch, W, H, s->x, s->y, c, tw);
		if (s->sz >= 1) {
			const int a2 = (tw * (s->sz == 1 ? 70 : 110)) >> 8;
			ms_plot_add(px, pitch, W, H, s->x - 1, s->y, c, a2); ms_plot_add(px, pitch, W, H, s->x + 1, s->y, c, a2);
			ms_plot_add(px, pitch, W, H, s->x, s->y - 1, c, a2); ms_plot_add(px, pitch, W, H, s->x, s->y + 1, c, a2);
		}
		if (s->sz >= 2) ms_glow(px, pitch, W, H, s->x, s->y, 6, c, (tw * 40) >> 8);
	}
}

// shooting stars: event k starts at k*3.3s + jitter, life 0.85 s, from the upper right to the lower left
#define MS_SHOOT_PERIOD 3.3f
#define MS_SHOOT_LIFE   0.85f
static void ms_shooting(uint32_t* px, int pitch, int W, int H, float t) {
	const int k1 = (int)floorf(t / MS_SHOOT_PERIOD);
	for (int k = k1 - 1; k <= k1; k++) {
		if (k < 0) continue;
		for (int twin = 0; twin < 2; twin++) {                // sometimes a second one follows right after
			if (twin && ms_rnd(k * 7919u + 5) > 0.28f) break;
			const float start = k * MS_SHOOT_PERIOD + ms_rnd(k * 31u + 1) * 1.8f + twin * (0.35f + 0.2f * ms_rnd(k + 9));
			const float age = t - start;
			if (age < 0 || age > MS_SHOOT_LIFE) continue;
			const float u = age / MS_SHOOT_LIFE;
			const float ang = (24.0f + 14.0f * ms_rnd(k * 13u + twin + 3)) * 0.0174533f;
			const float dirx = -cosf(ang), diry = sinf(ang);
			const float x0 = 200.0f + ms_rnd(k * 17u + twin * 5 + 2) * 330.0f, y0 = -10.0f + ms_rnd(k * 23u + twin * 3 + 4) * 55.0f;
			const float speed = 190.0f + 60.0f * ms_rnd(k * 5u + twin);
			const float hx = x0 + dirx * speed * age, hy = y0 + diry * speed * age;
			const float env = u < 0.15f ? u / 0.15f : (u > 0.7f ? (1 - u) / 0.3f : 1.0f);
			const int TAIL = 64;
			for (int i = 0; i < TAIL; i++) {
				const float f = 1.0f - (float)i / TAIL;      // 1 at the head
				const int a = (int)(256 * f * f * env);
				if (a < 4) continue;
				const float fx = hx - dirx * i, fy = hy - diry * i;
				const uint32_t col = ms_mix(0x9a7cff, 0xfff4ff, (int)(f * f * 256));
				const int ix = (int)floorf(fx), iy = (int)floorf(fy);
				ms_plot_add(px, pitch, W, H, ix, iy, col, a);
				if (i < 26) { ms_plot_add(px, pitch, W, H, ix, iy + 1, col, a >> 1); ms_plot_add(px, pitch, W, H, ix + 1, iy, col, a >> 2); }
			}
			ms_glow(px, pitch, W, H, (int)hx, (int)hy, 7, 0xb8a8ff, (int)(110 * env));
			ms_plot_add(px, pitch, W, H, (int)hx, (int)hy, 0xffffff, (int)(256 * env));
		}
	}
}

// snow motes, fireflies and wind streaks (drawn over the scenery)
#define MS_MOTES 56
#define MS_FLIES 11
#define MS_WIND 5
static void ms_particles(uint32_t* px, int pitch, int W, int H, float t) {
	for (int i = 0; i < MS_MOTES; i++) {
		const float r1 = ms_rnd(i * 4u + 101), r2 = ms_rnd(i * 4u + 102), r3 = ms_rnd(i * 4u + 103), r4 = ms_rnd(i * 4u + 104);
		const float depth = 0.5f + r3;                                       // 0.5 .. 1.5 (bigger = closer = faster)
		const float vx = 3.0f + 7.0f * depth, vy = 7.0f + 12.0f * depth;
		float x = r1 * (W + 24) + vx * t + (4.0f + 6.0f * r4) * sinf(t * (0.5f + r4) + r2 * 6.28f);
		float y = r2 * (H + 24) + vy * t;
		x = fmodf(x, (float)(W + 24)); y = fmodf(y, (float)(H + 24));
		const int X = (int)x - 12, Y = (int)y - 12;
		const int tw = 150 + (ms_sin[((int)(t * 30.0f * (0.6f + r4) + r1 * 255)) & 255] >> 1);   // 150..277
		const int a = tw > 256 ? 256 : tw;
		const uint32_t col = r2 > 0.8f ? 0xffd8f0 : 0xdce8ff;
		if (depth > 1.2f) {
			ms_plot_add(px, pitch, W, H, X, Y, col, a); ms_plot_add(px, pitch, W, H, X + 1, Y, col, a >> 1);
			ms_plot_add(px, pitch, W, H, X, Y + 1, col, a >> 1); ms_plot_add(px, pitch, W, H, X + 1, Y + 1, col, a >> 2);
			ms_glow(px, pitch, W, H, X, Y, 4, 0x6a80c0, 60);
		} else ms_plot_add(px, pitch, W, H, X, Y, col, a * (depth > 0.9f ? 200 : 130) / 256);
	}
	for (int i = 0; i < MS_FLIES; i++) {
		const float r1 = ms_rnd(i * 3u + 301), r2 = ms_rnd(i * 3u + 302), r3 = ms_rnd(i * 3u + 303);
		const float cx = 20 + r1 * 230, cy = 150 + r2 * 95;
		const float x = cx + 14 * sinf(t * (0.25f + 0.2f * r3) + r1 * 9) + 6 * sinf(t * 0.9f + r2 * 5);
		const float y = cy + 9 * sinf(t * (0.3f + 0.2f * r1) + r3 * 7) + 3 * cosf(t * 1.3f + r2 * 3);
		const int pulse = 60 + (ms_sin[((int)(t * 20.0f * (0.7f + r3) + r2 * 255)) & 255] * 150 >> 8);   // 60..210
		const uint32_t col = (i & 1) ? 0xff7fd0 : 0xffc890;
		ms_glow(px, pitch, W, H, (int)x, (int)y, 6, col, pulse * 2 / 3);
		ms_plot_add(px, pitch, W, H, (int)x, (int)y, 0xffffff, pulse);
	}
	for (int i = 0; i < MS_WIND; i++) {                                      // thin streaks blowing across the mountain
		const float r1 = ms_rnd(i * 5u + 501), r2 = ms_rnd(i * 5u + 502), r3 = ms_rnd(i * 5u + 503);
		const float speed = 55.0f + 40.0f * r1, len = 10.0f + 16.0f * r2;
		const float period = (W + 60 + len) / speed;
		const float ph = fmodf(t + r3 * period * 3.0f, period * (1.5f + r2));   // idle gaps between passes
		if (ph > period) continue;
		const float x = -30.0f + speed * ph, y = 110.0f + r3 * 80.0f + 3.0f * sinf(ph * 2.0f + i);
		const int fade = ph < 0.4f ? (int)(ph / 0.4f * 256) : ph > period - 0.4f ? (int)((period - ph) / 0.4f * 256) : 256;
		for (int k = 0; k < (int)len; k++) {
			const int a = ((int)len - k) * 80 / (int)len * fade / 256;
			ms_plot_add(px, pitch, W, H, (int)x - k, (int)(y + k * 0.06f), 0xaec4ff, a);
		}
	}
}

// ---------------------------------------------------------------- the logo
static void ms_spark(uint32_t* px, int pitch, int W, int H, int cx, int cy, int size, int amt /*0..256*/) {
	if (amt <= 0) return;
	const int L = (size * amt / 256) / 2;
	if (L < 1) { ms_plot_add(px, pitch, W, H, cx, cy, 0xffffff, amt); return; }
	for (int d = 1; d <= L; d++) {
		const int a = 256 - d * 256 / (L + 1);
		const int aa = (a * a >> 8) * 230 >> 8;
		ms_plot_add(px, pitch, W, H, cx + d, cy, 0xe8f0ff, aa); ms_plot_add(px, pitch, W, H, cx - d, cy, 0xe8f0ff, aa);
		ms_plot_add(px, pitch, W, H, cx, cy + d, 0xe8f0ff, aa); ms_plot_add(px, pitch, W, H, cx, cy - d, 0xe8f0ff, aa);
		if (size >= 11 && d <= L / 2) {                                        // thicker arms near the middle of big ones
			ms_plot_add(px, pitch, W, H, cx + d, cy + 1, 0xc8d8ff, aa >> 1); ms_plot_add(px, pitch, W, H, cx - d, cy + 1, 0xc8d8ff, aa >> 1);
			ms_plot_add(px, pitch, W, H, cx + 1, cy + d, 0xc8d8ff, aa >> 1); ms_plot_add(px, pitch, W, H, cx + 1, cy - d, 0xc8d8ff, aa >> 1);
		}
	}
	ms_plot_add(px, pitch, W, H, cx, cy, 0xffffff, 256);
	ms_plot_add(px, pitch, W, H, cx + 1, cy, 0xe0e8ff, 150); ms_plot_add(px, pitch, W, H, cx - 1, cy, 0xe0e8ff, 150);
	ms_plot_add(px, pitch, W, H, cx, cy + 1, 0xe0e8ff, 150); ms_plot_add(px, pitch, W, H, cx, cy - 1, 0xe0e8ff, 150);
	ms_glow(px, pitch, W, H, cx, cy, 2 + size / 3, 0x8090ff, amt / 4);
}

static void ms_title_draw(uint32_t* px, int pitch, int W, int H, float t) {
	if (!ms_title) return;
	const float u = t / 0.9f > 1 ? 1.0f : t / 0.9f;
	const float e = 1 - (1 - u) * (1 - u) * (1 - u);                         // ease-out
	const int bob = (int)floorf(1.5f * sinf(t * 1.25f) + 0.5f);
	const int off = bob + (int)((1 - e) * -16.0f);
	const int ga = (int)(e * 256);
	const int x = ms_title->x, y = ms_title->y + off;
	// halo (breathing)
	const int breathe = 46 + (int)(18.0f * sinf(t * 1.6f));
	if (ms_hl_n) {
		const int hs = breathe * ga >> 8;
		int ladd[3][256];                                               // additive colour per halo alpha (colour 0xff5cc8)
		for (int i = 0; i < 256; i++) { const int a = (i * hs) >> 8; ladd[0][i] = (255 * a) >> 8; ladd[1][i] = (0x5c * a) >> 8; ladd[2][i] = (0xc8 * a) >> 8; }
		for (int i = 0; i < ms_hl_n; i++) {
			const int o = ms_hl_off[i], a = ms_hl_a[i];
			const int X = x - MS_TG + o % ms_tglow_w, Y = y - MS_TG + o / ms_tglow_w;
			if ((unsigned)X >= (unsigned)W || (unsigned)Y >= (unsigned)H) continue;
			uint32_t* p = px + (size_t)Y * pitch + X; const uint32_t d = *p;
			int r = (int)((d >> 16) & 255) + ladd[0][a], g = (int)((d >> 8) & 255) + ladd[1][a], b = (int)(d & 255) + ladd[2][a];
			if (r > 255) r = 255;
			if (g > 255) g = 255;
			if (b > 255) b = 255;
			*p = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
		}
	}
	ms_blit(px, pitch, W, H, ms_title, x, y, ga, 0);
	// diagonal light sweep every 6.5 s
	const float cyc = fmodf(t - 1.2f, 6.5f);
	if (t > 1.2f && cyc < 1.0f) {
		const float k = cyc / 1.0f;
		const int pos = (int)(-24 + k * (ms_title->w + ms_title->h * 0.6f + 48));
		const int band = 14, amp = (int)(150 * sinf(k * 3.14159f));
		for (int yy = 0; yy < ms_title->h; yy++) {
			const int Y = y + yy; if ((unsigned)Y >= (unsigned)H) continue;
			for (int xx = 0; xx < ms_title->w; xx++) {
				const uint32_t c = ms_title->pm[yy * ms_title->w + xx]; const int a = c >> 24; if (a < 60) continue;
				const int d = abs(xx + (ms_title->h - yy) * 6 / 10 - pos); if (d >= band) continue;
				const int X = x + xx; if ((unsigned)X >= (unsigned)W) continue;
				uint32_t* p = px + (size_t)Y * pitch + X; *p = ms_add(*p, 0xffe8f8, (band - d) * amp / band * a >> 8);
			}
		}
	}
	// sparkles
	if (t > 0.7f) for (int i = 0; i < MENU_TITLE_SPARK_COUNT; i++) {
		float ph = sinf(t * (1.5f + 0.17f * i) + i * 1.9f);
		if (ph < 0) ph = 0;
		const int amt = (int)(ph * ph * 256) * (t < 1.2f ? (int)((t - 0.7f) * 512) : 256) >> 8;
		ms_spark(px, pitch, W, H, menu_title_sparks[i][0], menu_title_sparks[i][1] + off, menu_title_sparks[i][2] + 4, amt);
	}
}

// ---------------------------------------------------------------- whole scene
// sky + breathing glows only change slowly: they are rebuilt 12 times a second (per dim mode) and copied every frame
static uint32_t* ms_skyc[2] = { NULL, NULL };
static int ms_skyc_step[2] = { -1, -1 };

static void mscene_draw(uint32_t* px, int pitch, int W, int H, float t, int flags) {
	if (!ms_loaded || W < MS_W || H < MS_H) return;
	const int dim = (flags & MSCENE_DIM) ? 1 : 0;
	if (!ms_skyc[dim]) ms_skyc[dim] = (uint32_t*)malloc((size_t)MS_W * MS_H * 4);
	if (!ms_skyc[dim]) return;
	const int step = (int)(t * 12.0f);
	if (step != ms_skyc_step[dim]) {
		ms_skyc_step[dim] = step;
		const float ts = step / 12.0f;
		const uint32_t* src = dim ? ms_sky->pmd : ms_sky->pm;
		for (int i = 0; i < MS_W * MS_H; i++) ms_skyc[dim][i] = src[i] & 0xffffff;
		// breathing glows (the magenta horizon, the blue behind the mountain, a violet haze behind the logo)
		const int k = dim ? 140 : 256;
		ms_glow(ms_skyc[dim], MS_W, MS_W, MS_H, 120, 200, 48, 0xff40b0, (int)(26 + 10 * sinf(ts * 0.7f)) * k >> 8);
		ms_glow(ms_skyc[dim], MS_W, MS_W, MS_H, 300, 190, 48, 0x3070ff, (int)(22 + 9 * sinf(ts * 0.55f + 1.3f)) * k >> 8);
		ms_glow(ms_skyc[dim], MS_W, MS_W, MS_H, 262, 70, 48, 0x7040ff, (int)(14 + 7 * sinf(ts * 0.9f + 2.4f)) * k >> 8);
	}
	for (int y = 0; y < MS_H; y++) memcpy(px + (size_t)y * pitch, ms_skyc[dim] + (size_t)y * MS_W, MS_W * 4);
	ms_stars(px, pitch, W, H, t);
	ms_shooting(px, pitch, W, H, t);
	// pines, small to tall, each with its own sway
	const float gust = 1.0f + 0.35f * sinf(t * 0.37f);
	for (int i = 0; i < ms_ntrees; i++) {
		ms_spr_t* s = ms_trees[i];
		const float wave = sinf(t * 0.9f + s->phase) + 0.35f * sinf(t * 2.1f + s->phase * 1.7f);
		ms_blit_sway(px, pitch, W, H, s, s->x, s->y, s->amp * wave * gust, dim);
	}
	if (ms_mountain) ms_blit(px, pitch, W, H, ms_mountain, ms_mountain->x, ms_mountain->y, 256, dim);
	if (ms_cliff) ms_blit(px, pitch, W, H, ms_cliff, ms_cliff->x, ms_cliff->y, 256, dim);
	ms_particles(px, pitch, W, H, t);
	if (flags & MSCENE_TITLE) ms_title_draw(px, pitch, W, H, t);
}

#endif
