#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "hdgfx.h"
#include "hdramp.h"

static int S = 5, T = 40;
static uint32_t (*maprgb)(int,int,int);
static uint8_t* atlas = NULL; static int acols = 16, arows = 8, aw = 0;
static uint32_t* tp; static int tw, th, tpitch;
static int pal_map[16]; static int dim_on = 0, lut_dirty = 1;
static uint32_t lut[16][8];

void hd_init(int scale, uint32_t (*m)(int,int,int)) { S = scale; T = 8*scale; maprgb = m; hd_pal_reset(); }
int hd_ready(void) { return atlas != NULL; }
void hd_target(uint32_t* px, int w, int h, int pitch) { tp = px; tw = w; th = h; tpitch = pitch; }
void hd_pal_reset(void) { for (int i = 0; i < 16; i++) pal_map[i] = i; lut_dirty = 1; }
void hd_pal(int a, int b) { if (a >= 0 && a < 16 && b >= 0 && b < 16) { pal_map[a] = b; lut_dirty = 1; } }
void hd_dim(int on) { dim_on = on; lut_dirty = 1; }

static void shade_rgb(int idx, int s, int* r, int* g, int* b) {
	const unsigned char* c = HD_RAMP[idx][s];
	*r = c[0]; *g = c[1]; *b = c[2];
	if (dim_on) { // night-time dim for the neighbour rooms
		int l = (*r*3 + *g*4 + *b*2)/9;
		*r = (*r*2/5 + l/6); *g = (*g*2/5 + l/6); *b = (*b*2/5 + l/4 + 6);
	}
}
static void build_lut(void) {
	for (int i = 0; i < 16; i++) for (int s = 0; s < 8; s++) {
		int r, g, b; shade_rgb(pal_map[i], s, &r, &g, &b);
		lut[i][s] = maprgb(r, g, b);
	}
	lut_dirty = 0;
}
uint32_t hd_color(int idx) { if (lut_dirty) build_lut(); return lut[idx & 15][4]; }
void hd_base_rgb(int idx, int* r, int* g, int* b) { const unsigned char* c = HD_RAMP[idx & 15][4]; *r = c[0]; *g = c[1]; *b = c[2]; }

int hd_load_atlas(const char* path) {
	FILE* f = fopen(path, "rb"); if (!f) return -1;
	unsigned char h[20];
	if (fread(h, 1, 20, f) != 20 || memcmp(h, "HDA1", 4)) { fclose(f); return -2; }
	int t = (h[4]<<24)|(h[5]<<16)|(h[6]<<8)|h[7];
	acols = (h[8]<<24)|(h[9]<<16)|(h[10]<<8)|h[11]; arows = (h[12]<<24)|(h[13]<<16)|(h[14]<<8)|h[15];
	if (t != T) { fclose(f); return -3; }           // atlas made for another scale
	aw = acols*T; size_t n = (size_t)aw*arows*T;
	atlas = (uint8_t*)malloc(n);
	if (!atlas || fread(atlas, 1, n, f) != n) { free(atlas); atlas = NULL; fclose(f); return -4; }
	fclose(f); return 0;
}

void hd_tile(int tile, int dx, int dy, int flipx, int flipy) {
	if (!atlas || tile < 0 || tile >= acols*arows) return;
	if (lut_dirty) build_lut();
	const int sx0 = (tile % acols)*T, sy0 = (tile / acols)*T;
	int x0 = 0, x1 = T, y0 = 0, y1 = T;
	if (dx < 0) x0 = -dx; if (dx + T > tw) x1 = tw - dx;
	if (dy < 0) y0 = -dy; if (dy + T > th) y1 = th - dy;
	for (int y = y0; y < y1; y++) {
		const uint8_t* src = atlas + (size_t)(sy0 + (flipy ? T-1-y : y))*aw + sx0;
		uint32_t* dst = tp + (size_t)(dy + y)*tpitch + dx;
		if (!flipx) { for (int x = x0; x < x1; x++) { uint8_t v = src[x]; if (v & 15) dst[x] = lut[v & 15][v >> 4]; } }
		else        { for (int x = x0; x < x1; x++) { uint8_t v = src[T-1-x]; if (v & 15) dst[x] = lut[v & 15][v >> 4]; } }
	}
}

void hd_rect(int x0, int y0, int x1, int y1, int idx) {
	if (lut_dirty) build_lut();
	uint32_t c = lut[idx & 15][4];
	if (x0 < 0) x0 = 0; if (y0 < 0) y0 = 0; if (x1 >= tw) x1 = tw-1; if (y1 >= th) y1 = th-1;
	for (int y = y0; y <= y1; y++) { uint32_t* d = tp + (size_t)y*tpitch; for (int x = x0; x <= x1; x++) d[x] = c; }
}

// shaded ball (hair, etc): light from the top-left, dark rim, 2px "art cells"
void hd_circle(int cx, int cy, int rg, int idx) {
	if (lut_dirty) build_lut();
	const int R = rg*S + S/2 + 1;
	const int cell = 2;
	for (int y = -R; y <= R; y += cell) for (int x = -R; x <= R; x += cell) {
		int d2 = x*x + y*y; if (d2 > R*R) continue;
		int shade = 4;
		float d = sqrtf((float)d2)/R;
		float lit = (-x - y)/(1.414f*R);                 // -1 .. 1
		shade += (int)floorf(lit*2.0f + 0.5f);
		if (d > 0.82f) shade -= 2;                       // rim
		if (d > 0.82f && lit < -0.2f) shade -= 1;
		if (shade < 0) shade = 0; if (shade > 7) shade = 7;
		uint32_t c = lut[idx & 15][shade];
		for (int j = 0; j < cell; j++) for (int i = 0; i < cell; i++) {
			int px = cx + x + i, py = cy + y + j;
			if (px >= 0 && py >= 0 && px < tw && py < th) tp[(size_t)py*tpitch + px] = c;
		}
	}
}

// ---------------------------------------------------------------- background
typedef struct { int r, g, b; } RGB;
static uint32_t* bgc = NULL; static int bgc_w, bgc_h, bgc_rx = -999, bgc_ry = -999;
static uint32_t hash32(uint32_t n) { n *= 2654435761u; n ^= n >> 15; n *= 2246822519u; n ^= n >> 13; n *= 3266489917u; n ^= n >> 16; return n; }
static const int bayer[4][4] = {{0,8,2,10},{12,4,14,6},{3,11,1,9},{15,7,13,5}};
static RGB mix(RGB a, RGB b, float t) { RGB c = {(int)(a.r+(b.r-a.r)*t), (int)(a.g+(b.g-a.g)*t), (int)(a.b+(b.b-a.b)*t)}; return c; }
#define CELL 2

static void put(uint32_t* buf, int gw, int gh, int x, int y, RGB c) {
	if (x < 0 || y < 0 || x >= gw || y >= gh) return;
	if (c.r < 0) c.r = 0; if (c.g < 0) c.g = 0; if (c.b < 0) c.b = 0; if (c.r > 255) c.r = 255; if (c.g > 255) c.g = 255; if (c.b > 255) c.b = 255;
	buf[(size_t)y*gw + x] = maprgb(c.r, c.g, c.b);
}
// ridge height (in cells, from the top) for a layer
static float ridge(int layer, float x, float base) {
	switch (layer) {
	case 0: return base - 34*fabsf(sinf(x*0.021f + 1.1f))*0.9f - 14*fabsf(sinf(x*0.053f + 0.4f)) - 4*sinf(x*0.17f);
	case 1: return base - 26*fabsf(sinf(x*0.030f + 2.3f)) - 9*fabsf(sinf(x*0.081f)) - 3*sinf(x*0.21f + 1);
	}
	return base;
}

static void bg_render(int rx, int ry, int vw, int vh) {
	const int gw = vw/CELL, gh = vh/CELL;
	uint32_t* g = (uint32_t*)malloc((size_t)gw*gh*4);
	const float sc = gh/128.0f;                 // cells per game px
	const float px = rx*128*sc, py = ry*128*sc;
	// --- sky: dithered vertical gradient
	const RGB top = {5,7,22}, mid = {14,24,62}, low = {44,58,112}, hor = {70,84,136};
	for (int y = 0; y < gh; y++) {
		float t = (float)y/gh + (ry ? -0.0f : 0);
		RGB a, b; float u;
		if (t < 0.55f) { a = top; b = mid; u = t/0.55f; }
		else if (t < 0.85f) { a = mid; b = low; u = (t-0.55f)/0.30f; }
		else { a = low; b = hor; u = (t-0.85f)/0.15f; }
		for (int x = 0; x < gw; x++) {
			// quantise to 10 levels with a bayer dither
			float v = u*10.0f; int lv = (int)v; float fr = v - lv;
			if (fr*16 > bayer[y&3][x&3] + 0.5f) lv++;
			put(g, gw, gh, x, y, mix(a, b, lv/10.0f > 1 ? 1 : lv/10.0f));
		}
	}
	// --- stars
	for (int i = 0; i < 140; i++) {
		uint32_t h = hash32(i + 5);
		int x = (int)(h % gw), y = (int)((h >> 10) % (unsigned)(gh*0.62f));
		x = ((x - (int)(px*0.02f)) % gw + gw) % gw;
		int br = 110 + (h >> 24)%120; RGB c = {br*9/10, br*95/100, br};
		put(g, gw, gh, x, y, c);
		if (i % 11 == 0) { RGB w = {200,215,255}; put(g,gw,gh,x-1,y,c); put(g,gw,gh,x+1,y,c); put(g,gw,gh,x,y-1,c); put(g,gw,gh,x,y+1,c); put(g,gw,gh,x,y,w); }
	}
	// --- far + mid mountains (violet-blue haze, lit rim, soft fade to the fog)
	const struct { int layer; float par; float base; RGB body, rim, fog; } L[2] = {
		{0, 0.10f, 0.74f, {50,58,112}, {104,116,176}, {76,90,140}},
		{1, 0.22f, 0.86f, {34,40,86}, {74,86,144}, {52,62,110}},
	};
	for (int k = 0; k < 2; k++) {
		for (int x = 0; x < gw; x++) {
			float wx = x + px*L[k].par/ 1.0f;
			int y0 = (int)ridge(L[k].layer, wx, L[k].base*gh - py*L[k].par*0.5f);
			for (int y = y0; y < gh; y++) {
				float d = (float)(y - y0);
				RGB c = L[k].body;
				float fade = d/(gh*0.34f); if (fade > 1) fade = 1;
				c = mix(c, L[k].fog, 0.45f*(1-fade) + (L[k].layer==0 ? 0.25f : 0.0f)*fade);
				if (d < 2) c = L[k].rim;
				else if (d < 5 && ((x + y)&1)==0) c = mix(c, L[k].rim, 0.45f);
				// craggy facets: darker streaks on one side of each peak
				if (sinf(wx*0.021f*(k?1.43f:1)+ (k?2.3f:1.1f)) < 0 && ((y + x/3) % 7) < 2 && d > 6) c = mix(c, (RGB){10,14,40}, 0.28f);
				put(g, gw, gh, x, y, c);
			}
		}
	}
	// --- pine forest silhouettes (two rows, darker in front)
	for (int row = 0; row < 2; row++) {
		const float par = 0.40f + row*0.22f; const float base = gh*(0.90f + row*0.075f);
		const RGB col = row ? (RGB){6,10,26} : (RGB){12,20,46}; const RGB rim = row ? (RGB){26,38,80} : (RGB){32,50,96};
		for (int tcell = -2; tcell < gw/7 + 3; tcell++) {
			uint32_t h = hash32(tcell*7 + row*131 + 9);
			int off = (int)(px*par);
			int cx = tcell*(8 + row*2) + (int)(h % 5) - off % (gw + 40) ;
			cx = ((cx + 20) % (gw + 40) + gw + 40) % (gw + 40) - 20;
			int hgt = 16 + (int)((h >> 8) % 14) + row*4;
			int by = (int)base - (int)(sinf((cx + off)*0.06f)*3);
			for (int t = 0; t < hgt; t++) {
				int y = by - hgt + t;
				int hw = 1 + t*4/hgt + (t > hgt*2/3 ? 1 : 0) + ((t*3/hgt) ? (t % 3 == 0) : 0);
				for (int x = -hw; x <= hw; x++) put(g, gw, gh, cx + x, y, (x < -hw+1 && t % 2) ? rim : col);
			}
		}
		for (int y = (int)base; y < gh; y++) for (int x = 0; x < gw; x++) put(g, gw, gh, x, y, col);
		for (int x = 0; x < gw; x++) put(g, gw, gh, x, (int)base, rim);
	}
	// expand cells to pixels
	bgc_w = vw; bgc_h = vh;
	if (!bgc) bgc = (uint32_t*)malloc((size_t)vw*vh*4);
	for (int y = 0; y < vh; y++) { const uint32_t* s = g + (size_t)(y/CELL)*gw; uint32_t* d = bgc + (size_t)y*vw; for (int x = 0; x < vw; x++) d[x] = s[x/CELL]; }
	free(g);
}

// ---- clouds (precomputed pixel-art sprites, drawn every frame)
typedef struct { int w, h; uint32_t* px; uint8_t* a; } Cloud;
static Cloud clouds[4]; static int clouds_ok = 0;
static void make_clouds(int vh) {
	const float sc = vh/128.0f;
	for (int k = 0; k < 4; k++) {
		int cw = (int)((46 + k*14)*sc/CELL), ch = (int)((16 + k*3)*sc/CELL);
		clouds[k].w = cw*CELL; clouds[k].h = ch*CELL;
		clouds[k].px = (uint32_t*)calloc((size_t)cw*ch, 4); clouds[k].a = (uint8_t*)calloc((size_t)cw*ch, 1);
		// union of lumps
		int lumps = 5 + k;
		for (int y = 0; y < ch; y++) for (int x = 0; x < cw; x++) {
			float inside = 0;
			for (int l = 0; l < lumps; l++) {
				uint32_t h = hash32(l*31 + k*977);
				float lx = (0.14f + 0.72f*((h%100)/100.0f))*cw;
				float ly = ch*(0.62f - 0.30f*(((h>>8)%100)/100.0f)*((l==0||l==lumps-1)?0.3f:1.0f));
				float rr = ch*(0.30f + 0.28f*(((h>>16)%100)/100.0f));
				float dx = (x - lx)/(rr*1.55f), dy = (y - ly)/rr;
				if (dx*dx + dy*dy < 1) inside = 1;
			}
			if (y > ch*0.82f) inside = 0;
			clouds[k].a[y*cw + x] = (uint8_t)inside;
		}
		for (int y = 0; y < ch; y++) for (int x = 0; x < cw; x++) {
			if (!clouds[k].a[y*cw + x]) continue;
			int up = y > 0 ? clouds[k].a[(y-1)*cw + x] : 0, dn = y < ch-1 ? clouds[k].a[(y+1)*cw + x] : 0;
			int lf = x > 0 ? clouds[k].a[y*cw + x-1] : 0;
			RGB c = {74, 96, 150};
			float v = (float)y/ch;
			c = mix((RGB){104,130,184}, (RGB){52,66,122}, v);
			if (!up) c = (RGB){168,190,228};
			else if (y > 1 && !clouds[k].a[(y-2)*cw + x]) c = (RGB){132,156,206};
			if (!dn) c = (RGB){38,48,98};
			else if (y < ch-2 && !clouds[k].a[(y+2)*cw + x]) c = mix(c, (RGB){38,48,98}, 0.5f);
			if (!lf && up) c = mix(c, (RGB){168,190,228}, 0.4f);
			clouds[k].px[y*cw + x] = maprgb(c.r, c.g, c.b);
		}
	}
	clouds_ok = 1;
}
static void blit_cloud(int k, int x, int y) {
	const Cloud* c = &clouds[k]; const int cw = c->w/CELL, ch = c->h/CELL;
	for (int cy = 0; cy < ch; cy++) for (int cx = 0; cx < cw; cx++) {
		if (!c->a[cy*cw + cx]) continue;
		uint32_t col = c->px[cy*cw + cx];
		for (int j = 0; j < CELL; j++) for (int i = 0; i < CELL; i++) {
			int X = x + cx*CELL + i, Y = y + cy*CELL + j;
			if (X >= 0 && Y >= 0 && X < tw && Y < th) tp[(size_t)Y*tpitch + X] = col;
		}
	}
}

void hd_bg(int rx, int ry, int frames, int vw, int vh) {
	if (bgc && (bgc_w != vw || bgc_h != vh)) { free(bgc); bgc = NULL; bgc_rx = -999; }
	if (!bgc || bgc_rx != rx || bgc_ry != ry) { bg_render(rx, ry, vw, vh); bgc_rx = rx; bgc_ry = ry; }
	if (!clouds_ok) make_clouds(vh);
	for (int y = 0; y < vh && y < th; y++) memcpy(tp + (size_t)y*tpitch, bgc + (size_t)y*vw, (size_t)(vw < tw ? vw : tw)*4);
	// twinkling stars
	for (int i = 0; i < 14; i++) {
		uint32_t h = hash32(i*13 + 501);
		int x = (int)(h % (vw/CELL))*CELL, y = (int)((h >> 9) % (unsigned)(vh*0.55f/CELL))*CELL;
		int ph = (frames/(18 + (h>>26)) + i) % 4;
		int br = ph == 0 ? 255 : ph == 1 ? 190 : ph == 2 ? 120 : 70;
		uint32_t c = maprgb(br*9/10, br*95/100, br);
		for (int j = 0; j < CELL; j++) for (int a = 0; a < CELL; a++) if (x+a < tw && y+j < th) tp[(size_t)(y+j)*tpitch + x+a] = c;
	}
	// drifting clouds
	const float sc = vh/128.0f;
	static const struct { int k; float y, spd, par; } cl[6] = {
		{0, 16, 0.05f, 0.5f}, {1, 38, 0.08f, 0.8f}, {2, 58, 0.11f, 1.1f}, {3, 28, 0.06f, 0.6f}, {1, 70, 0.14f, 1.4f}, {0, 48, 0.09f, 0.9f}};
	for (int i = 0; i < 6; i++) {
		int span = vw + clouds[cl[i].k].w + 40;
		int x = ((int)((i*197 + frames*cl[i].spd*sc*1.0f) - rx*128*sc*cl[i].par*0.18f) % span + span) % span - clouds[cl[i].k].w - 20;
		blit_cloud(cl[i].k, x, (int)(cl[i].y*sc));
	}
}
