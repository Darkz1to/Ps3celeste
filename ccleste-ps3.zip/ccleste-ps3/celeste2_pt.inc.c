// celeste2_pt.inc.c -- included by celeste.c (after celeste2.inc.c)
//
// The prologue of chapter 2 ("level 0"): the altar leads here before the first level of Celeste 2.
//
//   1. Madeline wakes up in a training room. The old lady (Granny) waits there with an UP prompt above her.
//   2. Talking to her: a dialog window on the top. The powers were lost in the dimensional jump, but she lends
//      her grapple hook: the hook flies to Madeline and a little presentation plays.
//   3. Three lessons in the room, with a banner on the top: hook the walls / jump while the hook pulls you /
//      hold the button to stay clinging to the wall. Then the gate opens.
//   4. A vertical shaft: climb it by chaining hooks. The camera only goes up and there is no way back.
//   5. A little cabin on the plateau. Madeline goes in (UP at the door) and the door closes behind her.
//   6. Inside, the old lady stands in front of the portal. Talking to her is mandatory: the hook is hers and she
//      takes it back, saying she left another one lost in the next room. Then she steps aside: portal -> level 1.
//
// Everything that changes is in c2s (pt_* fields), so save/load state keeps working.
// Texts have no accents (the font has none). Buttons in the texts: [j] jump, [d] grapple (dash button), [p] d-pad.

#define O(i) (c2s.obj[i])

enum {
	PT_TALK1, PT_DLG1, PT_GIVE, PT_DLG2, PT_L_HOOK, PT_L_JUMP, PT_L_CLING, PT_GATE, PT_CLIMB,
	PT_ENTER, PT_TALK2, PT_DLG3, PT_TAKE, PT_FREE, PT_LEAVE
};

typedef struct { const char* l[2][3]; } PTPAGE;     // [language][line]
typedef struct { int n; PTPAGE pg[3]; } PTDLG;

static const PTDLG pt_dlgs[4] = {
	{ 0, {{{{0}}}} },
	{ 3, { // 1: the greeting
		{ {{ "You made it, dear!", "That dimensional jump", "was a rough one." },
		   { "Voce chegou, querida!", "Esse salto dimensional", "foi dos brabos." }} },
		{ {{ "Your powers were lost,", "but only for a while,", "during the jump." },
		   { "Seus poderes foram", "perdidos de forma", "temporaria no salto." }} },
		{ {{ "But do not worry!", "Take my grapple hook.", "Let me show you." },
		   { "Mas calma! Eu posso", "te emprestar o meu", "gancho. Olha so!" }} } } },
	{ 2, { // 2: how to use it
		{ {{ "Press [d] to throw the", "hook where you face.", "It grabs the walls." },
		   { "Aperte [d] para lancar", "o gancho pra onde olha.", "Ele prende nas paredes." }} },
		{ {{ "Go on, practice on the", "walls of this room.", "I will watch over you." },
		   { "Treine nas paredes aqui", "da sala. Eu fico de", "olho em voce." }} } } },
	{ 2, { // 3: the end (in the cabin)
		{ {{ "That hook is mine, dear.", "I only lent it to you", "for the training." },
		   { "Esse gancho e meu,", "so te emprestei para", "o treino." }} },
		{ {{ "But I left another one", "lost in the next room.", "Go and find it!" },
		   { "Mas deixei um perdido", "pela sala seguinte.", "Va procura-lo!" }} } } },
};

static bool pt_has_grapple(void) { return c2s.pt_step >= PT_DLG2 && c2s.pt_step <= PT_DLG3; }

static C2OBJ* pt_player(void) { return (c2s.player != C2_NONE && O(c2s.player).exists) ? &O(c2s.player) : NULL; }

static float pt_lady_feet_x(void) { return c2s.pt_inside ? c2s.pt_lady_x : (float)PT_LADY1_X; }
static float pt_lady_feet_y(void) { return c2s.pt_inside ? (float)PT_LADY2_Y : (float)PT_LADY1_Y; }

static void pt_open_dialog(int id) { c2s.pt_dlg = id; c2s.pt_page = 0; c2s.pt_chars = 0; P8sfx(35); }

//returns true when the dialog was closed
static bool pt_dialog_step(void) {
	const PTDLG* d = &pt_dlgs[c2s.pt_dlg];
	const int L = lang_pt ? 1 : 0;
	const PTPAGE* pg = &d->pg[c2s.pt_page];
	const int total = tut_len(pg->l[L][0]) + tut_len(pg->l[L][1]) + tut_len(pg->l[L][2]);
	const bool adv = c2s.jump_pressed > 0 || c2s.grap_pressed > 0;
	if (adv) { c2_consume_jump(); c2_consume_grapple(); }
	if (c2s.pt_chars < total) {
		c2s.pt_chars += 1;
		if (c2s.pt_chars % 6 == 0) P8sfx(35);
		if (adv) c2s.pt_chars = total;
	} else if (adv) {
		c2s.pt_page += 1; c2s.pt_chars = 0; P8sfx(35);
		if (c2s.pt_page >= d->n) { c2s.pt_dlg = 0; return true; }
	}
	return false;
}

static bool pt_near_lady(const C2OBJ* p) {
	return p->grounded && P8abs(p->x - pt_lady_feet_x()) < 26 && P8abs(p->y - pt_lady_feet_y()) < 10;
}

static void pt_face_lady(C2OBJ* p) {
	p->sx = 0; p->facing = pt_lady_feet_x() >= p->x ? 1 : -1;
}

static bool pt_swing_on_wall(const C2OBJ* p) {
	return p->state == C2S_SWING && c2_check_solid((int)(p - &O(0)), (float)p->grapple_dir, 0);
}

//1 while the gameplay of this step is skipped
static bool pt_update(void) {
	C2OBJ* p = pt_player();
	const bool up = P8btn(k_up);
	const bool up_press = up && !c2s.pt_up_prev;
	c2s.pt_up_prev = up;
	c2s.pt_t += 1;
	if (c2s.pt_flash > 0) c2s.pt_flash -= 1;
	if (!p || p->state >= C2S_DEAD) return false;

	switch (c2s.pt_step) {
	case PT_TALK1: case PT_TALK2:
		if (up_press && pt_near_lady(p)) {
			pt_face_lady(p);
			pt_open_dialog(c2s.pt_step == PT_TALK1 ? 1 : 3);
			c2s.pt_step = c2s.pt_step == PT_TALK1 ? PT_DLG1 : PT_DLG3;
		}
		break;
	case PT_DLG1: case PT_DLG3:
		if (pt_dialog_step()) {
			c2s.pt_item = 0;
			c2s.pt_step = c2s.pt_step == PT_DLG1 ? PT_GIVE : PT_TAKE;
		}
		return true;
	case PT_GIVE:
		// the hook flies from the old lady to Madeline, then the usual pick-up pose with the rays
		if (c2s.pt_item < 44) {
			c2s.pt_item += 1;
			if (c2s.pt_item == 44) {
				c2s.have_grapple = true; c2_psfx(7, 12);
				p->state = C2S_PICKUP; p->t_grapple_pickup = 0; p->sx = 0;
			}
			return true;
		}
		if (p->state != C2S_PICKUP) { c2s.pt_step = PT_DLG2; pt_open_dialog(2); pt_face_lady(p); }
		break;
	case PT_DLG2:
		if (pt_dialog_step()) { c2s.pt_step = PT_L_HOOK; c2s.pt_hook = 0; c2s.pt_t = 0; }
		return true;
	case PT_L_HOOK:
		if (c2s.pt_hook >= 3) { c2s.pt_step = PT_L_JUMP; c2s.pt_jump = 0; c2s.pt_flash = 20; P8sfx(55); }
		break;
	case PT_L_JUMP:
		if (c2s.pt_jump >= 2) { c2s.pt_step = PT_L_CLING; c2s.pt_hold = 0; c2s.pt_flash = 20; P8sfx(55); }
		break;
	case PT_L_CLING:
		if (c2s.grap_held && pt_swing_on_wall(p)) c2s.pt_hold += 1;
		else if (c2s.pt_hold > 0) c2s.pt_hold -= 2;
		if (c2s.pt_hold < 0) c2s.pt_hold = 0;
		if (c2s.pt_hold >= 72) { c2s.pt_step = PT_GATE; c2s.pt_t = 0; c2s.pt_flash = 20; P8sfx(55); }
		break;
	case PT_GATE:
		if (c2s.pt_t == 30) { c2s.pt_gate_open = true; c2s.shake = 14; c2_psfx(14, 8); P8sfx(16); }
		if (c2s.pt_t > 90) c2s.pt_step = PT_CLIMB;
		break;
	case PT_CLIMB:
		if (up_press && p->grounded && P8abs(p->x - PT_CABIN_DOOR_X) < 14 && P8abs(p->y - PT_CABIN_DOOR_Y) < 4) {
			p->sx = 0; p->facing = 1;
			c2s.pt_step = PT_ENTER; c2s.pt_t = 0; P8sfx(16);
		}
		break;
	case PT_ENTER:
		// curtains close, Madeline appears inside the cabin, curtains open, the door closes behind her
		if (c2s.pt_t == 16) {
			p->x = (float)PT_IN_SPAWN_X; p->y = (float)PT_IN_SPAWN_Y; p->sx = p->sy = 0; p->facing = 1;
			p->rx = p->ry = 0; p->state = C2S_NORMAL; p->grapple_retract = false;
			c2s.pt_inside = true; c2s.pt_lady_x = (float)PT_LADY2_X; c2s.pt_door = 0;
			c2s.checkpoint = -1;
			c2_view.x = p->x - 4; c2_view.y = p->y - 8; create_hair(&c2_view);
			c2_snap_camera();
		}
		if (c2s.pt_t > 34) { c2s.pt_step = PT_TALK2; c2s.pt_t = 0; }
		return true;
	case PT_TAKE:
		// the hook flies back to the old lady, then she steps aside
		c2s.pt_item += 1;
		if (c2s.pt_item == 46) { c2s.have_grapple = false; p->grapple_retract = false; P8sfx(55); c2s.pt_flash = 16; }
		if (c2s.pt_item > 70) { c2s.pt_step = PT_FREE; c2s.pt_t = 0; }
		return true;
	case PT_FREE:
		if (c2s.pt_lady_x > 112) c2s.pt_lady_x -= 0.5f;
		if (c2s.pt_t > 70 && p->grounded && P8abs(p->x - PT_PORTAL_X) < 7) {
			c2s.pt_step = PT_LEAVE; p->state = C2S_EXIT; p->wipe_timer = -20; p->sx = 0; P8sfx(38);
		}
		break;
	default: break;
	}

	if (c2s.pt_inside) {
		c2s.pt_door += 1;
		if (c2s.pt_door == 26) { c2s.shake = 8; P8sfx(16); }
		// the old lady blocks the way to the portal until she is done with her speech
		if (c2s.pt_step < PT_FREE) {
			const float lim = c2s.pt_lady_x - 9;
			if (p->x > lim) { p->x = lim; if (p->sx > 0) p->sx = 0; }
		}
		if (p->x < 87 && c2s.pt_door > 4) { p->x = 87; if (p->sx < 0) p->sx = 0; }   // the door is shut
	} else if (c2s.pt_step >= PT_L_HOOK) {
		// no way back: whoever falls out of the bottom of the view is sent back to the last checkpoint
		if (p->y > c2s.cam_y + 128 + 12 && c2s.pt_step >= PT_CLIMB && p->state < C2S_DEAD) { c2_player_die(c2s.player); return false; }
	}
	return false;
}

// ---- drawing -----------------------------------------------------------------------------------------
static void pt_up_bubble(int cx, int cy, bool near) {
	const int bob = (c2s.clock / 12) % 2;
	cy -= bob;
	P8rectfill(cx - 7, cy - 10, cx + 7, cy + 1, 0);
	P8rectfill(cx - 6, cy - 11, cx + 6, cy + 2, 0);
	P8rectfill(cx - 6, cy - 10, cx + 6, cy + 1, near ? 7 : 6);
	P8rectfill(cx - 5, cy - 9, cx + 5, cy, 1);
	P8rectfill(cx - 1, cy + 2, cx + 1, cy + 2, near ? 7 : 6);
	P8rectfill(cx, cy + 3, cx, cy + 3, near ? 7 : 6);
	const int c = near ? ((c2s.clock / 10) % 2 ? 10 : 7) : 6;     // the arrow
	P8rectfill(cx, cy - 8, cx, cy - 8, c);
	P8rectfill(cx - 1, cy - 7, cx + 1, cy - 7, c);
	P8rectfill(cx - 2, cy - 6, cx + 2, cy - 6, c);
	P8rectfill(cx - 1, cy - 5, cx + 1, cy - 1, c);
}

//a 16x16 sprite = 4 tiles of 8x8 (the frontend only draws 1x1 sprites): id, id+1 / id+16, id+17
static void pt_spr16(int id, float x, float y, bool flip) {
	for (int r = 0; r < 2; r++)
		for (int c = 0; c < 2; c++)
			P8spr(id + c + 16 * r, x + (float)((flip ? 1 - c : c) * 8), y + (float)(r * 8), 1, 1, flip, false);
}

static void pt_draw_lady(float fx, float fy, bool flip, bool talking) {
	const int breathe = (c2s.clock / 40) % 2;
	const int frame = talking && (c2s.clock / 8) % 2 ? 2 : 0;
	// shadow
	P8rectfill((int)fx - 6, (int)fy - 1, (int)fx + 6, (int)fy - 1, 1);
	pt_spr16(C2_SPRITE_BASE + 128 + frame, fx - 8, fy - 16, flip);
	if (breathe && !talking) P8rectfill((int)fx - 2, (int)fy - 16, (int)fx + 1, (int)fy - 16, 7);   // the hair bun moves a bit
}

static void pt_portal(int cx, int base) {
	const int t = c2s.clock / 2, phase = t / 4;
	P8rectfill(cx - 5, base - 20, cx + 4, base - 1, 1);
	for (int i = 0; i < 4; i++) {
		static const int cols[3] = { 12, 7, 13 };
		P8rectfill(cx - 5 + i, base - 20 + i, cx + 4 - i, base - 1, cols[(phase + 4 - i) % 3]);
	}
	P8rectfill(cx - 1, base - 16, cx, base - 3, (phase % 2) ? 7 : 12);
	P8rectfill(cx - 8, base - 22, cx - 6, base - 1, 6);
	P8rectfill(cx + 5, base - 22, cx + 7, base - 1, 6);
	P8rectfill(cx - 8, base - 22, cx - 8, base - 1, 7);
	P8rectfill(cx + 7, base - 22, cx + 7, base - 1, 13);
	P8rectfill(cx - 9, base - 25, cx + 8, base - 23, 6);
	P8rectfill(cx - 9, base - 25, cx + 8, base - 25, 7);
	P8rectfill(cx - 9, base - 23, cx + 8, base - 23, 13);
	P8rectfill(cx - 10, base - 1, cx + 9, base, 13);
	P8rectfill(cx - 9, base - 26, cx - 5, base - 26, 11);
	P8rectfill(cx + 3, base - 26, cx + 8, base - 26, 3);
	for (int i = 0; i < 3; i++) {
		const int q = (t * 2 + i * 23) % 40;
		P8rectfill(cx - 3 + i * 3, base - 4 - q / 2, cx - 3 + i * 3, base - 4 - q / 2, (q / 4) % 2 ? 7 : 12);
	}
}

//the cabin, in 3 pieces (-1 left of the 128 px window, 0 the window, 1 right of it): the sides are dimmed
static void pt_draw_inside(int dim) {
	const int x0 = dim < 0 ? c2s.cam_x - wide_pad - 8 : (dim == 0 ? c2s.cam_x : c2s.cam_x + 128);
	const int x1 = dim < 0 ? c2s.cam_x - 1 : (dim == 0 ? c2s.cam_x + 127 : c2s.cam_x + 136 + wide_pad);
	if (dim != 0) for (int c = 1; c < 16; c++) P8pal(c, c2_dark[c]);
	// wall: planks
	P8rectfill(x0, 0, x1, 127, 4);
	for (int x = (x0 / 12) * 12; x <= x1; x += 12) if (x >= x0) P8rectfill(x, 16, x, 111, 2);
	for (int x = (x0 / 12) * 12 + 5; x <= x1; x += 12) if (x >= x0) P8rectfill(x, 16, x, 111, 9);
	// ceiling with beams
	P8rectfill(x0, 0, x1, 15, 2);
	P8rectfill(x0, 12, x1, 15, 1);
	for (int x = (x0 / 40) * 40; x <= x1; x += 40) P8rectfill(x > x0 ? x : x0, 0, x + 5 < x1 ? x + 5 : x1, 15, 1);
	P8rectfill(x0, 16, x1, 16, 1);
	// floor
	P8rectfill(x0, 112, x1, 127, 4);
	P8rectfill(x0, 112, x1, 112, 9);
	P8rectfill(x0, 113, x1, 113, 2);
	for (int x = (x0 / 20) * 20; x <= x1; x += 20) if (x >= x0) P8rectfill(x, 114, x, 127, 2);
	P8rectfill(x0, 120, x1, 120, 2);
	if (dim == 0) {
		const int ox = c2s.cam_x;
		// the window with the snowy night
		const int wx = ox + 40, wy = 30;
		P8rectfill(wx - 2, wy - 2, wx + 25, wy + 29, 9);
		P8rectfill(wx - 1, wy - 1, wx + 24, wy + 28, 4);
		P8rectfill(wx, wy, wx + 23, wy + 27, 1);
		P8rectfill(wx + 11, wy, wx + 12, wy + 27, 4);
		P8rectfill(wx, wy + 13, wx + 23, wy + 14, 4);
		for (int i = 0; i < 9; i++) {
			const int sx = wx + 1 + (i * 7) % 22, sy = wy + 1 + (i * 11 + (c2s.clock / 3 + i * 5) % 28) % 26;
			if (sx != wx + 11 && sx != wx + 12 && sy != wy + 13 && sy != wy + 14) P8rectfill(sx, sy, sx, sy, 7);
		}
		P8rectfill(wx - 3, wy + 30, wx + 26, wy + 31, 9);          // sill
		// a shelf with jars (the third has a glowing spark)
		P8rectfill(ox + 84, 50, ox + 118, 51, 9);
		P8rectfill(ox + 87, 43, ox + 91, 49, 12); P8rectfill(ox + 87, 43, ox + 91, 44, 7);
		P8rectfill(ox + 95, 41, ox + 101, 49, 8);  P8rectfill(ox + 95, 41, ox + 101, 42, 14);
		P8rectfill(ox + 106, 44, ox + 110, 49, 11); P8rectfill(ox + 106, 44, ox + 110, 45, 3);
		P8rectfill(ox + 108, 40 + (c2s.clock / 20) % 2, ox + 108, 41 + (c2s.clock / 20) % 2, 10);
		// the rug
		P8rectfill(ox + 98, 112, ox + 154, 116, 2);
		P8rectfill(ox + 99, 112, ox + 153, 115, 8);
		for (int x = ox + 100; x < ox + 153; x += 6) P8rectfill(x, 113, x + 2, 114, 14);
		// lantern with a soft glow
		const int lx = ox + 124, ly = 20;
		P8rectfill(lx, 16, lx, ly - 1, 5);
		P8rectfill(lx - 3, ly, lx + 3, ly + 7, 9); P8rectfill(lx - 2, ly + 1, lx + 2, ly + 6, 10);
		P8rectfill(lx - 1, ly + 2, lx + 1, ly + 5, 7);
		P8rectfill(lx - 4, ly, lx + 4, ly, 5); P8rectfill(lx - 4, ly + 7, lx + 4, ly + 7, 5);
		// the door Madeline came through (left wall): it swings shut
		const int dx = ox + 3, shut = c2s.pt_door >= 26 ? 14 : (c2s.pt_door * 14 / 26);
		P8rectfill(dx, 64, dx + 15, 111, 2);
		P8rectfill(dx, 64, dx + 15, 64, 9);
		P8rectfill(dx + 14 - shut, 66, dx + 14, 111, 4);
		if (shut >= 14) { P8rectfill(dx + 1, 68, dx + 13, 110, 4); P8rectfill(dx + 10, 90, dx + 11, 91, 10); P8rectfill(dx + 3, 70, dx + 3, 109, 2); }
		else P8rectfill(dx, 66, dx + 13 - shut, 111, 10);
	}
	if (dim != 0) P8pal_reset();
}

static void pt_draw_world(void) {
	const C2OBJ* p = pt_player();
	const int step = c2s.pt_step;
	if (c2s.pt_inside) {
		if (step >= PT_FREE) pt_portal(PT_PORTAL_X, PT_PORTAL_Y);
		else pt_portal(PT_PORTAL_X, PT_PORTAL_Y);
		const bool talking = step == PT_DLG3;
		const bool flip = p ? p->x < c2s.pt_lady_x : false;
		pt_draw_lady(c2s.pt_lady_x, (float)PT_LADY2_Y, step == PT_FREE ? true : flip, talking);
	} else {
		const bool talking = step == PT_DLG1 || step == PT_DLG2;
		const bool flip = p ? p->x < PT_LADY1_X : false;
		pt_draw_lady((float)PT_LADY1_X, (float)PT_LADY1_Y, flip, talking);
		// light spilling from the cabin door
		if (step >= PT_CLIMB) {
			const int gx = PT_CABIN_DOOR_X - 8;
			for (int i = 0; i < 6; i++) P8rectfill(gx + 8 - i, PT_CABIN_DOOR_Y - 2 - i, gx + 8 + i, PT_CABIN_DOOR_Y - 2 - i, (c2s.clock / 8) % 2 ? 10 : 9);
		}
	}
	// the gate sparkles while it is about to open
	if (step == PT_GATE && !c2s.pt_gate_open) {
		for (int i = 0; i < 10; i++) {
			const int sx = PT_GATE_COL0 * 8 + ((i * 13 + c2s.pt_t * 3) % 56), sy = PT_GATE_ROW * 8 + (i * 5 + c2s.pt_t) % 8;
			P8rectfill(sx, sy, sx, sy, (i + c2s.pt_t / 3) % 2 ? 7 : 12);
		}
	}
	if (step == PT_GATE && c2s.pt_gate_open && c2s.pt_t < 60) {      // dust of the vanishing gate
		for (int i = 0; i < 12; i++) {
			const int sx = PT_GATE_COL0 * 8 + (i * 5) % 56, sy = PT_GATE_ROW * 8 - (c2s.pt_t - 30) * (1 + i % 3) / 3;
			P8rectfill(sx, sy, sx + 1, sy + 1, 7);
		}
	}
}

static void pt_flying_item(float fx, float fy, float tx, float ty, int t, int len) {
	const float k = (float)t / (float)len;
	const float x = fx + (tx - fx) * k, y = fy + (ty - fy) * k - P8sin(k * 0.5f) * -18.0f;
	c2_spr(20, x - 4, y - 4, false, false);
	for (int i = 0; i < 5; i++) {
		const float kk = k - (float)i * 0.04f;
		if (kk < 0) continue;
		const int sx = (int)(fx + (tx - fx) * kk), sy = (int)(fy + (ty - fy) * kk + P8sin(kk * 0.5f) * 18.0f * 1.0f);
		P8rectfill(sx, sy, sx, sy, i % 2 ? 7 : 10);
	}
}

static void pt_draw_front(void) {
	const C2OBJ* p = pt_player();
	if (!p) return;
	const int step = c2s.pt_step;
	if (step == PT_TALK1 || step == PT_TALK2) {
		const float lx = pt_lady_feet_x(), ly = pt_lady_feet_y();
		pt_up_bubble((int)lx, (int)ly - 22, pt_near_lady(p));
	}
	if (step == PT_GIVE && c2s.pt_item < 44)
		pt_flying_item(pt_lady_feet_x() - 4, pt_lady_feet_y() - 12, p->x, p->y - 18, c2s.pt_item, 44);
	if (step == PT_TAKE && c2s.pt_item < 46)
		pt_flying_item(p->x, p->y - 12, pt_lady_feet_x(), pt_lady_feet_y() - 14, c2s.pt_item, 46);
	if (step == PT_CLIMB && P8abs(p->x - PT_CABIN_DOOR_X) < 40 && P8abs(p->y - PT_CABIN_DOOR_Y) < 40)
		pt_up_bubble(PT_CABIN_DOOR_X, PT_CABIN_DOOR_Y - 30, P8abs(p->x - PT_CABIN_DOOR_X) < 14 && p->grounded);
	if (step == PT_FREE && c2s.pt_t > 70) {     // an arrow over the portal
		const int bob = (c2s.clock / 10) % 3;
		P8rectfill(PT_PORTAL_X, PT_PORTAL_Y - 36 + bob, PT_PORTAL_X, PT_PORTAL_Y - 36 + bob, 10);
		P8rectfill(PT_PORTAL_X - 1, PT_PORTAL_Y - 37 + bob, PT_PORTAL_X + 1, PT_PORTAL_Y - 37 + bob, 10);
		P8rectfill(PT_PORTAL_X - 2, PT_PORTAL_Y - 38 + bob, PT_PORTAL_X + 2, PT_PORTAL_Y - 38 + bob, 10);
	}
}

// ---- screen space: dialog window, banner, curtains --------------------------------------------------
static void pt_box(int x0, int y0, int x1, int y1, bool flash) {
	P8rectfill(x0 + 1, y1 + 1, x1 + 1, y1 + 2, 0);
	P8rectfill(x0, y0, x1, y1, flash ? 10 : 7);
	P8rectfill(x0 + 1, y0 + 1, x1 - 1, y1 - 1, 1);
	P8rectfill(x0 + 2, y0 + 2, x1 - 2, y0 + 2, 13);
}

static void pt_draw_dialog(void) {
	const PTDLG* d = &pt_dlgs[c2s.pt_dlg];
	const int L = lang_pt ? 1 : 0;
	const PTPAGE* pg = &d->pg[c2s.pt_page];
	const int x0 = 3, x1 = 124, y0 = 3, y1 = 43;
	pt_box(x0, y0, x1, y1, false);
	// portrait
	P8rectfill(x0 + 4, y0 + 5, x0 + 21, y0 + 22, 2);
	P8rectfill(x0 + 5, y0 + 6, x0 + 20, y0 + 21, 13);
	const int total = tut_len(pg->l[L][0]) + tut_len(pg->l[L][1]) + tut_len(pg->l[L][2]);
	const bool typing = c2s.pt_chars < total;
	pt_spr16(C2_SPRITE_BASE + 128 + (typing && (c2s.pt_chars / 4) % 2 ? 2 : 0), (float)(x0 + 5), (float)(y0 + 6), false);
	P8print(lang_pt ? "vovo" : "granny", x0 + 27, y0 + 4, 10);
	// text
	int budget = c2s.pt_chars;
	for (int i = 0; i < 3; i++) {
		const int len = tut_len(pg->l[L][i]);
		tut_print(x0 + 27, y0 + 12 + i * 8, 7, pg->l[L][i], &budget);
		(void)len;
	}
	// "next" arrow
	if (!typing && (c2s.clock / 16) % 2) {
		P8rectfill(x1 - 9, y1 - 7, x1 - 3, y1 - 7, 10);
		P8rectfill(x1 - 8, y1 - 6, x1 - 4, y1 - 6, 10);
		P8rectfill(x1 - 7, y1 - 5, x1 - 5, y1 - 5, 10);
		P8rectfill(x1 - 6, y1 - 4, x1 - 6, y1 - 4, 10);
	}
	// page pips
	for (int i = 0; i < d->n; i++) P8rectfill(x1 - 5 - (d->n - 1 - i) * 4, y0 + 4, x1 - 4 - (d->n - 1 - i) * 4, y0 + 5, i == c2s.pt_page ? 10 : 5);
}

static void pt_draw_banner(const char* title, const char* l1, const char* l2, int pips, int cur, float bar) {
	const int x0 = 4, x1 = 123, y0 = 2, y1 = 27;
	pt_box(x0, y0, x1, y1, c2s.pt_flash > 0 && (c2s.pt_flash / 2) % 2);
	P8rectfill(x0 + 2, y0 + 8, x1 - 2, y0 + 8, 5);
	int budget = 999;
	tut_print(x0 + 6, y0 + 3, 10, title, &budget);
	tut_print(x0 + 6, y0 + 11, 7, l1, &budget);
	if (bar < 0) tut_print(x0 + 6, y0 + 18, 7, l2, &budget);
	else {
		P8rectfill(x0 + 6, y0 + 19, x1 - 6, y0 + 22, 5);
		P8rectfill(x0 + 7, y0 + 20, x1 - 7, y0 + 21, 0);
		const int w = (int)((float)(x1 - 7 - (x0 + 7)) * bar);
		if (w > 0) P8rectfill(x0 + 7, y0 + 20, x0 + 7 + w, y0 + 21, bar > 0.8f ? 11 : 12);
	}
	for (int i = 0; i < pips; i++) {
		const int px = x1 - 5 - (pips - 1 - i) * 5;
		P8rectfill(px, y0 + 3, px + 2, y0 + 5, i == cur ? 10 : (i < cur ? 11 : 5));
	}
}

static void pt_draw_ui(void) {
	const int L = lang_pt ? 1 : 0;
	char b[40];
	if (c2s.pt_dlg > 0) pt_draw_dialog();
	else switch (c2s.pt_step) {
	case PT_L_HOOK:
		snprintf(b, sizeof b, L ? "prenda %d/3" : "hook it %d/3", c2s.pt_hook > 3 ? 3 : c2s.pt_hook);
		pt_draw_banner(L ? "licao 1: gancho" : "lesson 1: hook", L ? "aperte [d] perto da parede" : "press [d] near a wall", b, 3, 0, -1);
		break;
	case PT_L_JUMP:
		snprintf(b, sizeof b, L ? "para saltar. %d/2" : "to leap. %d/2", c2s.pt_jump > 2 ? 2 : c2s.pt_jump);
		pt_draw_banner(L ? "licao 2: pule!" : "lesson 2: jump!", L ? "prenda e aperte [j]" : "hook, then press [j]", b, 3, 1, -1);
		break;
	case PT_L_CLING:
		pt_draw_banner(L ? "licao 3: agarrar" : "lesson 3: cling", L ? "segure [d] na parede" : "hold [d] on a wall", "", 3, 2, (float)c2s.pt_hold / 72.0f);
		break;
	case PT_GATE:
		pt_draw_banner(L ? "muito bem!" : "well done!", L ? "o portao se abriu." : "the gate is opening.", L ? "agora, suba!" : "now climb!", 3, 3, -1);
		break;
	case PT_CLIMB:
		if (c2s.pt_t < 400 && c2s.cam_y > 330 * 8 / 8)
			pt_draw_banner(L ? "suba o poco" : "climb the shaft", L ? "prenda o gancho nas" : "hook the walls and", L ? "paredes e pule!" : "jump to rise!", 0, 0, -1);
		break;
	default: break;
	}
	// curtains of the door
	if (c2s.pt_step == PT_ENTER) {
		const int t = c2s.pt_t;
		const int cov = t <= 16 ? t * 5 : (t >= 34 ? 0 : (34 - t) * 5);
		if (cov > 0) {
			P8rectfill(-wide_pad - 8, 0, 136 + wide_pad, cov - 1, 0);
			P8rectfill(-wide_pad - 8, 128 - cov, 136 + wide_pad, 127, 0);
		}
	}
	// white pulse when a lesson is completed
	if (c2s.pt_flash > 12) P8rectfill(-wide_pad - 8, 0, 136 + wide_pad, 1, 7);
}

#undef O
