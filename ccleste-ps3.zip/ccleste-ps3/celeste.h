#ifndef CELESTE_H_
#define CELESTE_H_

#ifdef __cplusplus
#define _Bool bool
extern "C" {
#endif

typedef enum {
	CELESTE_P8_MUSIC, CELESTE_P8_SPR, CELESTE_P8_BTN, CELESTE_P8_SFX,
	CELESTE_P8_PAL, CELESTE_P8_PAL_RESET, CELESTE_P8_CIRCFILL, CELESTE_P8_PRINT,
	CELESTE_P8_RECTFILL, CELESTE_P8_LINE, CELESTE_P8_MGET, CELESTE_P8_CAMERA,
	CELESTE_P8_FGET, CELESTE_P8_MAP
} CELESTE_P8_CALLBACK_TYPE;

typedef _Bool Celeste_P8_bool_t;
typedef int (*Celeste_P8_cb_func_t) (CELESTE_P8_CALLBACK_TYPE calltype, ...);

extern void Celeste_P8_set_call_func(Celeste_P8_cb_func_t func);
extern void Celeste_P8_set_rndseed(unsigned seed);
extern void Celeste_P8_init(void);
extern void Celeste_P8_update(void);
extern void Celeste_P8_draw(void);

extern void Celeste_P8__DEBUG(void); //debug functionality

//when on, the title screen doesn't print "x+c"/credits (the frontend draws its own menu)
extern void Celeste_P8_set_menu_mode(int on);

//widescreen: extra pixels shown on each side of the 128x128 room (0 = original)
extern void Celeste_P8_set_wide_pad(int px);

//language of the texts drawn by the game itself (0 = english, 1 = portuguese)
extern void Celeste_P8_set_language(int pt);

//progress (what gets written to the savedata)
#define CELESTE_P8_FRUITS 30
typedef struct {
	int room_x, room_y;
	int deaths, max_djump;
	int frames, seconds, minutes;
	unsigned char got_fruit[CELESTE_P8_FRUITS];
} Celeste_P8_progress_t;
extern void Celeste_P8_get_progress(Celeste_P8_progress_t* p);
//puts the game in the saved room; returns 0 on success, -1 if the data is not valid
extern int Celeste_P8_load_progress(const Celeste_P8_progress_t* p);

//state functionality
size_t Celeste_P8_get_state_size(void);
void Celeste_P8_save_state(void* st);
void Celeste_P8_load_state(const void* st);

#ifdef __cplusplus
} //extern "C"
#endif

#endif
