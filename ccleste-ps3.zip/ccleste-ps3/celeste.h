#ifndef CELESTE_H_
#define CELESTE_H_

#ifdef __cplusplus
#define _Bool bool
extern "C" {
#endif

typedef enum {
	CELESTE_P8_MUSIC, CELESTE_P8_SPR, CELESTE_P8_BTN, CELESTE_P8_SFX,
	CELESTE_P8_PAL, CELESTE_P8_PAL_RESET, CELESTE_P8_CIRCFILL, CELESTE_P8_PRINT,
	CELESTE_P8_RECTFILL, CELESTE_P8_LINE, CELESTE_P8_MGET, CELESTE_P8_CAMERA,
	CELESTE_P8_FGET, CELESTE_P8_MAP,
	CELESTE_P8_HDBG,  //hdbg(room_x,room_y,frames): HD frontends draw the whole background and return 1
	CELESTE_P8_HDDIM  //hddim(on): HD frontends darken what is drawn and return 1 (else the game dims with pal())
} CELESTE_P8_CALLBACK_TYPE;

typedef _Bool Celeste_P8_bool_t;
typedef int (*Celeste_P8_cb_func_t) (CELESTE_P8_CALLBACK_TYPE calltype, ...);

extern void Celeste_P8_set_call_func(Celeste_P8_cb_func_t func);
extern void Celeste_P8_set_rndseed(unsigned seed);
extern void Celeste_P8_init(void);
extern void Celeste_P8_update(void);
extern void Celeste_P8_draw(void);

extern void Celeste_P8__DEBUG(void); //debug functionality

//when on, the title screen doesn't print "x+c"/credits (the frontend draws its own menu)
extern void Celeste_P8_set_menu_mode(int on);

//widescreen: extra pixels shown on each side of the 128x128 room (0 = original)
extern void Celeste_P8_set_wide_pad(int px);

//co-op: two players. Player 1 is read through btn(); player 2 and the merge buttons are
//given by the frontend every tick with Celeste_P8_set_coop_input():
//  p1_merge   player 1 is holding the merge button (triangle)
//  p2_bits    player 2 buttons: bits 0..5 = left,right,up,down,jump,dash (like btn()), bit 6 = merge
extern void Celeste_P8_set_coop(int on);
extern int  Celeste_P8_get_coop(void);
extern void Celeste_P8_set_coop_input(int p1_merge, unsigned p2_bits);

//language of the texts drawn by the game itself (0 = english, 1 = portuguese)
extern void Celeste_P8_set_language(int pt);

//progress (what gets written to the savedata)
#define CELESTE_P8_FRUITS 30
typedef struct {
	int room_x, room_y;
	int deaths, max_djump;
	int frames, seconds, minutes;
	unsigned char got_fruit[CELESTE_P8_FRUITS];
	unsigned char coop, coop_tag; //co-op game (coop_tag == 0xC5 when `coop` is valid); these were padding bytes
} Celeste_P8_progress_t;
extern void Celeste_P8_get_progress(Celeste_P8_progress_t* p);
//puts the game in the saved room; returns 0 on success, -1 if the data is not valid
extern int Celeste_P8_load_progress(const Celeste_P8_progress_t* p);

//state functionality
size_t Celeste_P8_get_state_size(void);
void Celeste_P8_save_state(void* st);
void Celeste_P8_load_state(const void* st);

#ifdef __cplusplus
} //extern "C"
#endif

#endif
