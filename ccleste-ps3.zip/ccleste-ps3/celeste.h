#ifndef CELESTE_H_
#define CELESTE_H_

#ifdef __cplusplus
#define _Bool bool
extern "C" {
#endif

typedef enum {
	CELESTE_P8_MUSIC, CELESTE_P8_SPR, CELESTE_P8_BTN, CELESTE_P8_SFX,
	CELESTE_P8_PAL, CELESTE_P8_PAL_RESET, CELESTE_P8_CIRCFILL, CELESTE_P8_PRINT,
	CELESTE_P8_RECTFILL, CELESTE_P8_LINE, CELESTE_P8_MGET, CELESTE_P8_CAMERA,
	CELESTE_P8_FGET, CELESTE_P8_MAP,
	CELESTE_P8_SCROLL, //scroll(x,y): world offset of the view (chapter 2); camera() stays the shake
	CELESTE_P8_HD      //optional HD effects, op = first argument (CELESTE_HD_*). Frontends that don't know it return 0.
} CELESTE_P8_CALLBACK_TYPE;

//HD ops (CELESTE_HD_QUERY returns 1 only in the HD frontend; the other ops are never sent otherwise)
enum {
	CELESTE_HD_QUERY, CELESTE_HD_BACKDROP /*theme,room_x,room_y,frames*/, CELESTE_HD_CLOUD /*x,y,w,h,theme*/,
	CELESTE_HD_PARTICLE /*x,y,size,col*/, CELESTE_HD_SPARK /*x,y,t*/, CELESTE_HD_GLOW /*x,y,radius,kind,strength*/
};
enum { CELESTE_GLOW_WARM, CELESTE_GLOW_RED, CELESTE_GLOW_GOLD, CELESTE_GLOW_CYAN, CELESTE_GLOW_WHITE, CELESTE_GLOW_GREEN };

typedef _Bool Celeste_P8_bool_t;
typedef int (*Celeste_P8_cb_func_t) (CELESTE_P8_CALLBACK_TYPE calltype, ...);

extern void Celeste_P8_set_call_func(Celeste_P8_cb_func_t func);
extern void Celeste_P8_set_rndseed(unsigned seed);
extern void Celeste_P8_init(void);
extern void Celeste_P8_update(void);
extern void Celeste_P8_draw(void);

extern void Celeste_P8__DEBUG(void); //debug functionality

//when on, the title screen doesn't print "x+c"/credits (the frontend draws its own menu)
extern void Celeste_P8_set_menu_mode(int on);

//widescreen: extra pixels shown on each side of the 128x128 room (0 = original)
extern void Celeste_P8_set_wide_pad(int px);

//co-op: two players. Player 1 is read through btn(); player 2 and the merge buttons are
//given by the frontend every tick with Celeste_P8_set_coop_input():
//  p1_merge   player 1 is holding the merge button (triangle)
//  p2_bits    player 2 buttons: bits 0..5 = left,right,up,down,jump,dash (like btn()), bit 6 = merge
extern void Celeste_P8_set_coop(int on);
extern int  Celeste_P8_get_coop(void);
extern void Celeste_P8_set_coop_input(int p1_merge, unsigned p2_bits);

//tutorial level played before level 1 in a new game (needs the 16:9 view, wide_pad >= 48)
extern int  Celeste_P8_in_tutorial(void);
extern void Celeste_P8_tutorial_skip(void);       //jump straight to level 1
extern void Celeste_P8_set_tutorial_enabled(int on);
extern void Celeste_P8_set_pad_icons(int on);     //1: hints show PlayStation symbols, 0: key caps
//names of the controls shown in the hints when pad icons are off (NULL keeps the current one)
extern void Celeste_P8_set_button_names(const char* jump, const char* dash, const char* grab, const char* merge, const char* dpad);

//chapter 2 (Celeste 2): started from the altar at the end of chapter 1
extern int Celeste_P8_in_celeste2(void);
extern int Celeste_P8_altar_busy(void);           //1 while the altar prompt/animation is running (the pause menu should not open)

//language of the texts drawn by the game itself (0 = english, 1 = portuguese)
extern void Celeste_P8_set_language(int pt);


//customization (contents -> customize): 3 slots, 0 = solo, 1 = co-op player 1, 2 = co-op player 2.
//All zeros = the original look. Option names follow the language set with Celeste_P8_set_language().
enum {
	CELESTE_STYLE_HAIR, CELESTE_STYLE_DRESS, CELESTE_STYLE_SKIN, CELESTE_STYLE_HAT, CELESTE_STYLE_HATCOL,
	CELESTE_STYLE_SCARF, CELESTE_STYLE_CAPE, CELESTE_STYLE_EXTRA, CELESTE_STYLE_FIELDS
};
#define CELESTE_STYLE_SLOTS 3
typedef struct { unsigned char v[CELESTE_STYLE_FIELDS]; } Celeste_P8_style_t;
extern int Celeste_P8_style_count(int field);               //how many options a field has
extern const char* Celeste_P8_style_name(int field, int idx);
extern void Celeste_P8_set_style(int slot, const Celeste_P8_style_t* st);
extern void Celeste_P8_get_style(int slot, Celeste_P8_style_t* st);
//draws the character (sprite + hair + accessories) for the menus: x,y = top left of the 8x8 sprite,
//scale = pixels per sprite pixel, frame 1..4, running = the scarf and the cape fly behind
extern void Celeste_P8_draw_preview(int slot, int x, int y, int scale, int flip, int frame, int t, int running);

//game events (used by the trophy system): the frontend gets a callback when something happens
//  ROOM_NEXT   the players went through the exit to the next room   (a = new room index)
//  DEATH       a player died (b = 1: became a bubble, 0: the room restarts)
//  RESCUE      a bubble was revived by the other player
//  FUSE        the two players fused (merge)
//  FRUIT       a strawberry was collected                          (a = strawberries collected so far)
//  ORB         the double dash orb was collected
//  CHEST       the chest was opened with the key
//  SUMMIT      the summit flag was reached
//  RUN_START   a new game started or a save was loaded              (a = strawberries already collected)
enum {
	CELESTE_EV_ROOM_NEXT = 1, CELESTE_EV_DEATH, CELESTE_EV_RESCUE, CELESTE_EV_FUSE, CELESTE_EV_FRUIT,
	CELESTE_EV_ORB, CELESTE_EV_CHEST, CELESTE_EV_SUMMIT, CELESTE_EV_RUN_START
};
typedef void (*Celeste_P8_event_func_t)(int ev, int a, int b);
extern void Celeste_P8_set_event_func(Celeste_P8_event_func_t func);

//progress (what gets written to the savedata)
#define CELESTE_P8_FRUITS 30
typedef struct {
	int room_x, room_y;
	int deaths, max_djump;
	int frames, seconds, minutes;
	unsigned char got_fruit[CELESTE_P8_FRUITS];
	unsigned char coop, coop_tag; //co-op game (coop_tag == 0xC5 when `coop` is valid); these were padding bytes
} Celeste_P8_progress_t;
extern void Celeste_P8_get_progress(Celeste_P8_progress_t* p);
//puts the game in the saved room; returns 0 on success, -1 if the data is not valid
extern int Celeste_P8_load_progress(const Celeste_P8_progress_t* p);

//state functionality
size_t Celeste_P8_get_state_size(void);
void Celeste_P8_save_state(void* st);
void Celeste_P8_load_state(const void* st);

#ifdef __cplusplus
} //extern "C"
#endif

#endif
