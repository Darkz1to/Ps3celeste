// HD (16-bit style) renderer for ccleste. No SDL in here: it only works on 32-bit XRGB pixel buffers and
// 8-bit sprite sheets, so the same code runs in the game (sdl12main.c) and in tools/hd_preview.c.
//
// Colour model: a sheet pixel is (base<<4)|shade. `base` is the PICO-8 colour (pal() swaps it), `shade` 0..15
// picks the tone inside that colour's ramp (8 = the exact PICO-8 colour). 0 = transparent.
#ifndef HDGFX_INC_H_
#define HDGFX_INC_H_

#include <stdint.h>
#include <string.h>
#include <math.h>
#include "hd_ramps.inc.h"

#define HD_S 2                // HD pixels per PICO-8 pixel

static uint32_t hd_ramp[16][16];
static unsigned char hd_palmap[16];

static void hd_pal_reset(void) { for (int i = 0; i < 16; i++) hd_palmap[i] = i; }
static void hd_pal(int a, int b) { if (a >= 0 && a < 16 && b >= 0 && b < 16) hd_palmap[a] = b; }
static void hd_init(void) {
	for (int b = 0; b < 16; b++) for (int s = 0; s < 16; s++)
		hd_ramp[b][s] = ((uint32_t)hd_ramp_rgb[b][s][0] << 16) | ((uint32_t)hd_ramp_rgb[b][s][1] << 8) | hd_ramp_rgb[b][s][2];
	hd_pal_reset();
}
static inline uint32_t hd_col(int base, int shade) { return hd_ramp[hd_palmap[base & 15]][shade & 15]; }

typedef struct { uint32_t* px; int pitch, w, h; } hd_surf;   // pitch in 32-bit words

static inline int hd_clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

// ---------------------------------------------------------------- basic drawing (coordinates in HD pixels)
static void hd_fill(hd_surf* s, int x0, int y0, int w, int h, uint32_t c) {
	if (x0 < 0) { w += x0; x0 = 0; }
	if (y0 < 0) { h += y0; y0 = 0; }
	if (x0 + w > s->w) w = s->w - x0;
	if (y0 + h > s->h) h = s->h - y0;
	if (w <= 0 || h <= 0) return;
	for (int y = 0; y < h; y++) {
		uint32_t* p = s->px + (size_t)(y0 + y) * s->pitch + x0;
		for (int x = 0; x < w; x++) p[x] = c;
	}
}

// alpha blend (a = 0..256)
static inline uint32_t hd_mix(uint32_t dst, uint32_t src, int a) {
	uint32_t rb = ((dst & 0xff00ff) * (256 - a) + (src & 0xff00ff) * a) >> 8;
	uint32_t g  = ((dst & 0x00ff00) * (256 - a) + (src & 0x00ff00) * a) >> 8;
	return (rb & 0xff00ff) | (g & 0x00ff00);
}
static inline uint32_t hd_add(uint32_t dst, uint32_t src, int a) {   // additive light, a = 0..256
	int r = ((dst >> 16) & 255) + ((((src >> 16) & 255) * a) >> 8);
	int g = ((dst >> 8) & 255)  + ((((src >> 8) & 255) * a) >> 8);
	int b = (dst & 255)         + (((src & 255) * a) >> 8);
	if (r > 255) r = 255;
	if (g > 255) g = 255;
	if (b > 255) b = 255;
	return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

// sprite blit from an 8-bit sheet. `override` != 0: every pixel uses that PICO-8 colour (shade kept: the font
// uses shade 8 for the glyph and 3 for its shadow, the sprites use it for the white flash).
static void hd_blit(hd_surf* d, const unsigned char* sheet, int sheet_w, int sheet_h,
                    int sx, int sy, int w, int h, int dx, int dy, int flipx, int flipy, int override) {
	for (int y = 0; y < h; y++) {
		int py = dy + y; if (py < 0 || py >= d->h) continue;
		int syy = sy + (flipy ? h - 1 - y : y);
		if (syy < 0 || syy >= sheet_h) continue;
		const unsigned char* row = sheet + (size_t)syy * sheet_w;
		uint32_t* out = d->px + (size_t)py * d->pitch;
		for (int x = 0; x < w; x++) {
			int px = dx + x; if (px < 0 || px >= d->w) continue;
			int sxx = sx + (flipx ? w - 1 - x : x);
			if (sxx < 0 || sxx >= sheet_w) continue;
			unsigned char p = row[sxx];
			if (!p) continue;
			out[px] = override ? hd_col(override, p & 15) : hd_col(p >> 4, p & 15);
		}
	}
}

// A shaded ball (hair, bubbles, dots). (cx,cy) = PICO-8 pixel; r = PICO-8 radius (0..3 as the game uses).
static void hd_ball(hd_surf* d, int cx, int cy, int r, int col) {
	const float R = r * HD_S + 0.62f * HD_S;              // radius in HD pixels
	const float ccx = cx * HD_S + HD_S * 0.5f, ccy = cy * HD_S + HD_S * 0.5f;
	const int x0 = (int)floorf(ccx - R - 1), x1 = (int)ceilf(ccx + R + 1);
	const int y0 = (int)floorf(ccy - R - 1), y1 = (int)ceilf(ccy + R + 1);
	for (int y = y0; y <= y1; y++) {
		if (y < 0 || y >= d->h) continue;
		for (int x = x0; x <= x1; x++) {
			if (x < 0 || x >= d->w) continue;
			float dx = x + 0.5f - ccx, dy = y + 0.5f - ccy;
			float dist = sqrtf(dx * dx + dy * dy);
			if (dist > R) continue;
			// light from the top-left: normal.z from the sphere, lambert against (-0.5,-0.7,0.5)
			float nz = sqrtf(fmaxf(0.f, 1.f - (dist / R) * (dist / R)));
			float lam = (-dx / R) * 0.5f + (-dy / R) * 0.7f + nz * 0.5f;
			int sh;
			if (R < 3.2f) {                              // tiny balls: flat, with a darker rim only
				sh = (dist > R - 1.f && (dx + dy) > 0) ? 5 : 8;
				if (dist < R * 0.55f && (dx + dy) < 0) sh = 10;
			} else {
				sh = (int)lroundf(8.f + lam * 6.f - 1.f);
				if (dist > R - 1.15f) sh -= 2;           // rim
				sh = hd_clampi(sh, 3, 14);
			}
			d->px[(size_t)y * d->pitch + x] = hd_col(col, sh);
		}
	}
}

// Additive soft light. (cx,cy,radius) in HD pixels; colour = rgb; strength 0..256 at the centre
static void hd_glow(hd_surf* d, int cx, int cy, int radius, uint32_t rgb, int strength) {
	const int r2 = radius * radius;
	for (int y = cy - radius; y <= cy + radius; y++) {
		if (y < 0 || y >= d->h) continue;
		for (int x = cx - radius; x <= cx + radius; x++) {
			if (x < 0 || x >= d->w) continue;
			int dx = x - cx, dy = y - cy, q = dx * dx + dy * dy;
			if (q >= r2) continue;
			int f = 256 - (q * 256) / r2;                // 1 at the centre, 0 at the edge
			f = (f * f) >> 8;                            // quadratic falloff
			int a = (f * strength) >> 8;
			if (a > 0) d->px[(size_t)y * d->pitch + x] = hd_add(d->px[(size_t)y * d->pitch + x], rgb, a);
		}
	}
}

// soft puff (clouds): ellipse with a smooth alpha edge. x,y,w,h in HD pixels
static void hd_puff(hd_surf* d, int x, int y, int w, int h, uint32_t body, uint32_t rim, int alpha) {
	const float rx = w * 0.5f, ry = h * 0.5f, cx = x + rx, cy = y + ry;
	for (int yy = y; yy < y + h; yy++) {
		if (yy < 0 || yy >= d->h) continue;
		for (int xx = x; xx < x + w; xx++) {
			if (xx < 0 || xx >= d->w) continue;
			float nx = (xx + 0.5f - cx) / rx, ny = (yy + 0.5f - cy) / ry;
			float q = nx * nx + ny * ny;
			if (q >= 1.f) continue;
			float e = 1.f - q;                           // 0 at the edge
			int a = (int)(alpha * fminf(1.f, e * 3.2f));
			uint32_t c = (ny < -0.35f + 0.25f * nx) ? rim : body;   // brighter upper rim
			uint32_t* p = d->px + (size_t)yy * d->pitch + xx;
			*p = hd_mix(*p, c, a);
		}
	}
}

// ---------------------------------------------------------------- backdrop
static inline uint32_t hd_rgb(int r, int g, int b) { return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b; }
static inline uint32_t hd_lerp(uint32_t a, uint32_t b, int t256) { return hd_mix(a, b, t256); }

typedef struct { uint32_t top, mid, low, far, near, star, fog; } hd_theme;
static const hd_theme hd_themes[3] = {
	// 0: night (levels 1-10)
	{ 0x070a1f, 0x14183f, 0x2d2457, 0x1b2050, 0x101436, 0xcfd8ff, 0x3a3470 },
	// 1: dusk (the pink levels)
	{ 0x1f0b33, 0x5a1a4e, 0xa4385e, 0x4b1a4c, 0x2c1038, 0xffd0e0, 0xb04a70 },
	// 2: cold summit
	{ 0x0b1530, 0x1d3a6b, 0x4a6aa5, 0x31508a, 0x1b2f5c, 0xeaf6ff, 0x6f8fc7 },
};

static const unsigned char hd_bayer4[16] = { 0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5 };

// height of a mountain layer at column x (HD pixels); pseudo-random ridge from a few sines
static float hd_ridge(float x, float seed, float freq) {
	float v = sinf(x * freq + seed) * 0.5f + sinf(x * freq * 2.3f + seed * 1.7f) * 0.28f + sinf(x * freq * 5.1f + seed * 0.3f) * 0.12f;
	return v;
}

static void hd_backdrop(hd_surf* d, int theme, int room_x, int room_y, int frames) {
	if (theme < 0 || theme > 2) theme = 0;
	const hd_theme* T = &hd_themes[theme];
	const int W = d->w, H = d->h;
	const float par_far = (room_x * 128 + frames * 0.02f) * HD_S * 0.10f;
	const float par_near = (room_x * 128 + frames * 0.04f) * HD_S * 0.22f;
	const float yoff = room_y * 6.0f;
	for (int y = 0; y < H; y++) {
		// vertical sky gradient (3 stops)
		int t = y * 256 / H;
		uint32_t sky = t < 128 ? hd_lerp(T->top, T->mid, t * 2) : hd_lerp(T->mid, T->low, (t - 128) * 2);
		uint32_t* row = d->px + (size_t)y * d->pitch;
		for (int x = 0; x < W; x++) {
			// 4x4 ordered dither of 1/255 steps removes the banding of the gradient
			int dz = hd_bayer4[(y & 3) * 4 + (x & 3)] - 8;
			int r = (int)((sky >> 16) & 255), g = (int)((sky >> 8) & 255), b = (int)(sky & 255);
			r += dz >> 3; g += dz >> 3; b += dz >> 3;
			row[x] = hd_rgb(hd_clampi(r, 0, 255), hd_clampi(g, 0, 255), hd_clampi(b, 0, 255));
		}
	}
	// stars (night / cold only)
	if (theme != 1) {
		for (int i = 0; i < 70; i++) {
			unsigned n = (unsigned)i * 2654435761u;
			int sx = (int)((n >> 3) % (unsigned)W), sy = (int)(((n >> 11) * 40503u) % (unsigned)(H * 6 / 10));
			int tw = (frames / 8 + i * 7) % 24;
			int a = tw < 12 ? 70 + tw * 10 : 70 + (24 - tw) * 10;
			uint32_t* p = d->px + (size_t)sy * d->pitch + sx;
			*p = hd_mix(*p, T->star, a);
			if (i % 9 == 0) {                              // a few brighter crosses
				if (sx > 0) p[-1] = hd_mix(p[-1], T->star, a / 3);
				if (sx < W - 1) p[1] = hd_mix(p[1], T->star, a / 3);
				if (sy > 0) p[-d->pitch] = hd_mix(p[-d->pitch], T->star, a / 3);
				if (sy < H - 1) p[d->pitch] = hd_mix(p[d->pitch], T->star, a / 3);
			}
		}
	}
	// two mountain ranges, far then near, each with a bright rim on its sunlit (left) slope
	for (int layer = 0; layer < 2; layer++) {
		const float par = layer == 0 ? par_far : par_near;
		const float base = H * (layer == 0 ? 0.60f : 0.74f) - yoff * (layer + 1) * 0.3f;
		const float amp = H * (layer == 0 ? 0.26f : 0.22f);
		uint32_t body = layer == 0 ? T->far : T->near;
		uint32_t rim = hd_lerp(body, T->star, layer == 0 ? 46 : 30);
		uint32_t fog = T->fog;
		float prev = 0;
		for (int x = 0; x < W; x++) {
			float hgt = hd_ridge((x + par) , layer * 3.1f + 1.3f, layer == 0 ? 0.012f : 0.019f);
			float top = base - hgt * amp;
			if (x == 0) prev = top;
			int ytop = (int)top;
			float slope = top - prev; prev = top;
			for (int y = ytop; y < H; y++) {
				if (y < 0) continue;
				uint32_t* p = d->px + (size_t)y * d->pitch + x;
				int depth = y - ytop;
				uint32_t c = body;
				// rim light along the ridge, stronger on slopes that face the light (falling to the right = lit)
				if (depth < 2) c = hd_lerp(body, rim, slope > 0 ? 210 : 120);
				else if (depth < 5 && slope > 0.12f) c = hd_lerp(body, rim, 70);
				// mist: fades the mountain towards the fog colour near the bottom
				int mist = y * 256 / H - 110; if (mist < 0) mist = 0; if (mist > 200) mist = 200;
				c = hd_lerp(c, fog, layer == 0 ? mist / 2 : mist / 4);
				*p = c;
			}
		}
	}
}

// ---------------------------------------------------------------- final pass: vignette (+ slight warm/cool grade)
static unsigned char hd_vig[1];                    // placeholder to keep the symbol list tidy
static void hd_vignette(uint32_t* dst, const uint32_t* src, int w, int h, int pitch_src, int strength /*0..256*/) {
	static int lw = 0, lh = 0, ls = -1;
	static unsigned char* lut = NULL;
	static unsigned char store[1920 * 1088 / 4];
	if (w != lw || h != lh || ls != strength) {
		if ((size_t)w * h <= sizeof store) { lut = store; }
		else lut = NULL;
		if (lut) {
			for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
				float nx = (x + 0.5f) / w * 2.f - 1.f, ny = (y + 0.5f) / h * 2.f - 1.f;
				float q = nx * nx * 0.55f + ny * ny * 0.9f;       // wider than tall
				float v = 1.f - fminf(1.f, q * q * 0.55f) * (strength / 256.f);
				lut[y * w + x] = (unsigned char)(v * 255.f);
			}
		}
		lw = w; lh = h; ls = strength;
	}
	for (int y = 0; y < h; y++) {
		const uint32_t* s = src + (size_t)y * pitch_src;
		uint32_t* o = dst + (size_t)y * w;
		for (int x = 0; x < w; x++) {
			uint32_t c = s[x];
			if (!lut) { o[x] = c; continue; }
			unsigned v = lut[y * w + x] + 1;                 // 1..256
			uint32_t rb = (((c & 0xff00ff) * v) >> 8) & 0xff00ff;
			uint32_t g  = (((c & 0x00ff00) * v) >> 8) & 0x00ff00;
			o[x] = rb | g;
		}
	}
}

#endif
