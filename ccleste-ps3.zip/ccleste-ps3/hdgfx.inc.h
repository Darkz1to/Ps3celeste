// HD (16-bit style) renderer for ccleste. No SDL in here: it only works on 32-bit XRGB pixel buffers and
// 8-bit sprite sheets, so the same code runs in the game (sdl12main.c) and in tools/hd_preview.c.
//
// Colour model: a sheet pixel is (base<<4)|shade. `base` is the PICO-8 colour (pal() swaps it), `shade` 0..15
// picks the tone inside that colour's ramp (8 = the exact PICO-8 colour). 0 = transparent.
#ifndef HDGFX_INC_H_
#define HDGFX_INC_H_

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "hd_ramps.inc.h"

#define HD_S 2                // HD pixels per PICO-8 pixel

static uint32_t hd_ramp[16][16];
static unsigned char hd_palmap[16];
// sheet pixel ((base<<4)|shade) -> final colour with the current pal(). Rebuilt lazily, only after pal() changed something:
// the blitter then needs one table read per pixel instead of two.
static uint32_t hd_lut[256];
static int hd_lut_dirty = 1;

static void hd_pal_reset(void) {
	for (int i = 0; i < 16; i++) if (hd_palmap[i] != i) { hd_palmap[i] = (unsigned char)i; hd_lut_dirty = 1; }
}
static void hd_pal(int a, int b) {
	if (a >= 0 && a < 16 && b >= 0 && b < 16 && hd_palmap[a] != b) { hd_palmap[a] = (unsigned char)b; hd_lut_dirty = 1; }
}
static void hd_init(void) {
	for (int b = 0; b < 16; b++) for (int s = 0; s < 16; s++)
		hd_ramp[b][s] = ((uint32_t)hd_ramp_rgb[b][s][0] << 16) | ((uint32_t)hd_ramp_rgb[b][s][1] << 8) | hd_ramp_rgb[b][s][2];
	hd_pal_reset();
	hd_lut_dirty = 1;
}
static inline uint32_t hd_col(int base, int shade) { return hd_ramp[hd_palmap[base & 15]][shade & 15]; }
static void hd_lut_build(void) {
	for (int p = 0; p < 256; p++) hd_lut[p] = hd_col(p >> 4, p & 15);
	hd_lut_dirty = 0;
}

typedef struct { uint32_t* px; int pitch, w, h; } hd_surf;   // pitch in 32-bit words

static inline int hd_clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

// ---------------------------------------------------------------- basic drawing (coordinates in HD pixels)
static void hd_fill(hd_surf* s, int x0, int y0, int w, int h, uint32_t c) {
	if (x0 < 0) { w += x0; x0 = 0; }
	if (y0 < 0) { h += y0; y0 = 0; }
	if (x0 + w > s->w) w = s->w - x0;
	if (y0 + h > s->h) h = s->h - y0;
	if (w <= 0 || h <= 0) return;
	for (int y = 0; y < h; y++) {
		uint32_t* p = s->px + (size_t)(y0 + y) * s->pitch + x0;
		for (int x = 0; x < w; x++) p[x] = c;
	}
}

// alpha blend (a = 0..256)
static inline uint32_t hd_mix(uint32_t dst, uint32_t src, int a) {
	uint32_t rb = ((dst & 0xff00ff) * (256 - a) + (src & 0xff00ff) * a) >> 8;
	uint32_t g  = ((dst & 0x00ff00) * (256 - a) + (src & 0x00ff00) * a) >> 8;
	return (rb & 0xff00ff) | (g & 0x00ff00);
}
static inline uint32_t hd_add(uint32_t dst, uint32_t src, int a) {   // additive light, a = 0..256
	int r = ((dst >> 16) & 255) + ((((src >> 16) & 255) * a) >> 8);
	int g = ((dst >> 8) & 255)  + ((((src >> 8) & 255) * a) >> 8);
	int b = (dst & 255)         + (((src & 255) * a) >> 8);
	if (r > 255) r = 255;
	if (g > 255) g = 255;
	if (b > 255) b = 255;
	return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

// sprite blit from an 8-bit sheet. `override` != 0: every pixel uses that PICO-8 colour (shade kept: the font
// uses shade 8 for the glyph and 3 for its shadow, the sprites use it for the white flash).
// The clipping is done once per call (not per pixel) and the colour comes from a table.
static void hd_blit(hd_surf* d, const unsigned char* sheet, int sheet_w, int sheet_h,
                    int sx, int sy, int w, int h, int dx, int dy, int flipx, int flipy, int override) {
	// visible part, in sprite-local coordinates [x0,x1) x [y0,y1): inside the target and inside the sheet
	int x0 = 0, x1 = w, y0 = 0, y1 = h;
	if (dx < 0) x0 = -dx;
	if (dx + w > d->w) x1 = d->w - dx;
	if (dy < 0) y0 = -dy;
	if (dy + h > d->h) y1 = d->h - dy;
	if (!flipx) { if (x0 < -sx) x0 = -sx; if (x1 > sheet_w - sx) x1 = sheet_w - sx; }
	else        { if (x0 < sx + w - sheet_w) x0 = sx + w - sheet_w; if (x1 > sx + w) x1 = sx + w; }
	if (!flipy) { if (y0 < -sy) y0 = -sy; if (y1 > sheet_h - sy) y1 = sheet_h - sy; }
	else        { if (y0 < sy + h - sheet_h) y0 = sy + h - sheet_h; if (y1 > sy + h) y1 = sy + h; }
	if (x0 >= x1 || y0 >= y1) return;

	uint32_t ov[16];
	if (override) { for (int s = 0; s < 16; s++) ov[s] = hd_col(override, s); }
	else if (hd_lut_dirty) hd_lut_build();

	for (int y = y0; y < y1; y++) {
		const int syy = sy + (flipy ? h - 1 - y : y);
		const unsigned char* row = sheet + (size_t)syy * sheet_w;
		uint32_t* out = d->px + (size_t)(dy + y) * d->pitch + dx;
		if (!flipx) {
			const unsigned char* s = row + sx;
			if (override) { for (int x = x0; x < x1; x++) { unsigned char p = s[x]; if (p) out[x] = ov[p & 15]; } }
			else          { for (int x = x0; x < x1; x++) { unsigned char p = s[x]; if (p) out[x] = hd_lut[p]; } }
		} else {
			const unsigned char* s = row + sx + w - 1;
			if (override) { for (int x = x0; x < x1; x++) { unsigned char p = s[-x]; if (p) out[x] = ov[p & 15]; } }
			else          { for (int x = x0; x < x1; x++) { unsigned char p = s[-x]; if (p) out[x] = hd_lut[p]; } }
		}
	}
}

// A shaded ball (hair, bubbles, dots). (cx,cy) = PICO-8 pixel; r = PICO-8 radius (0..3 as the game uses).
// shade of one pixel at offset (dx,dy) from the ball centre, or -1 outside the ball
static inline int hd_ball_shade(float dx, float dy, float R) {
	float dist = sqrtf(dx * dx + dy * dy);
	if (dist > R) return -1;
	// light from the top-left: normal.z from the sphere, lambert against (-0.5,-0.7,0.5)
	float nz = sqrtf(fmaxf(0.f, 1.f - (dist / R) * (dist / R)));
	float lam = (-dx / R) * 0.5f + (-dy / R) * 0.7f + nz * 0.5f;
	int sh;
	if (R < 3.2f) {                              // tiny balls: flat, with a darker rim only
		sh = (dist > R - 1.f && (dx + dy) > 0) ? 5 : 8;
		if (dist < R * 0.55f && (dx + dy) < 0) sh = 10;
	} else {
		sh = (int)lroundf(8.f + lam * 6.f - 1.f);
		if (dist > R - 1.15f) sh -= 2;           // rim
		sh = hd_clampi(sh, 3, 14);
	}
	return sh;
}
// The shading only depends on the offset from the centre, so it is computed once per radius (for a ball centred at
// PICO-8 pixel 0,0) and then every ball of that radius is just a table read per pixel.
#define HD_BALL_MAXR 8
typedef struct { int ox, oy, w, h; signed char* sh; int ready; } hd_ballmap_t;
static hd_ballmap_t hd_ballmaps[HD_BALL_MAXR + 1];
static const hd_ballmap_t* hd_ball_get(int r) {
	if (r < 0 || r > HD_BALL_MAXR) return NULL;
	hd_ballmap_t* m = &hd_ballmaps[r];
	if (!m->ready) {
		const float R = r * HD_S + 0.62f * HD_S;
		const float ccx = HD_S * 0.5f, ccy = HD_S * 0.5f;
		const int x0 = (int)floorf(ccx - R - 1), x1 = (int)ceilf(ccx + R + 1);
		const int y0 = (int)floorf(ccy - R - 1), y1 = (int)ceilf(ccy + R + 1);
		m->w = x1 - x0 + 1; m->h = y1 - y0 + 1; m->ox = x0; m->oy = y0;
		m->sh = (signed char*)malloc((size_t)m->w * m->h);
		if (!m->sh) return NULL;
		for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++)
			m->sh[(size_t)(y - y0) * m->w + (x - x0)] = (signed char)hd_ball_shade(x + 0.5f - ccx, y + 0.5f - ccy, R);
		m->ready = 1;
	}
	return m;
}
static void hd_ball(hd_surf* d, int cx, int cy, int r, int col) {
	const hd_ballmap_t* m = hd_ball_get(r);
	if (m) {
		const int bx = cx * HD_S + m->ox, by = cy * HD_S + m->oy;
		int xa = 0, xb = m->w, ya = 0, yb = m->h;
		if (bx < 0) xa = -bx;
		if (bx + m->w > d->w) xb = d->w - bx;
		if (by < 0) ya = -by;
		if (by + m->h > d->h) yb = d->h - by;
		if (xa >= xb || ya >= yb) return;
		const unsigned char pal = hd_palmap[col & 15];
		for (int y = ya; y < yb; y++) {
			const signed char* srow = m->sh + (size_t)y * m->w;
			uint32_t* out = d->px + (size_t)(by + y) * d->pitch + bx;
			for (int x = xa; x < xb; x++) { int sh = srow[x]; if (sh >= 0) out[x] = hd_ramp[pal][sh & 15]; }
		}
		return;
	}
	// radius outside the cache: the plain version
	const float R = r * HD_S + 0.62f * HD_S;              // radius in HD pixels
	const float ccx = cx * HD_S + HD_S * 0.5f, ccy = cy * HD_S + HD_S * 0.5f;
	const int x0 = (int)floorf(ccx - R - 1), x1 = (int)ceilf(ccx + R + 1);
	const int y0 = (int)floorf(ccy - R - 1), y1 = (int)ceilf(ccy + R + 1);
	for (int y = y0; y <= y1; y++) {
		if (y < 0 || y >= d->h) continue;
		for (int x = x0; x <= x1; x++) {
			if (x < 0 || x >= d->w) continue;
			int sh = hd_ball_shade(x + 0.5f - ccx, y + 0.5f - ccy, R);
			if (sh >= 0) d->px[(size_t)y * d->pitch + x] = hd_col(col, sh);
		}
	}
}

// Additive soft light. (cx,cy,radius) in HD pixels; colour = rgb; strength 0..256 at the centre
// The falloff (it had an integer division per pixel) is a table indexed by the squared distance, one per radius.
#define HD_GLOW_LUT_MAXR 64
static uint16_t* hd_glow_lut[HD_GLOW_LUT_MAXR + 1];
static inline int hd_glow_f(int q, int r2) { int f = 256 - (q * 256) / r2; return (f * f) >> 8; }
static const uint16_t* hd_glow_lut_get(int radius) {
	if (radius < 1 || radius > HD_GLOW_LUT_MAXR) return NULL;
	if (!hd_glow_lut[radius]) {
		const int r2 = radius * radius;
		uint16_t* t = (uint16_t*)malloc(sizeof(uint16_t) * (size_t)r2);
		if (!t) return NULL;
		for (int q = 0; q < r2; q++) t[q] = (uint16_t)hd_glow_f(q, r2);
		hd_glow_lut[radius] = t;
	}
	return hd_glow_lut[radius];
}
static void hd_glow(hd_surf* d, int cx, int cy, int radius, uint32_t rgb, int strength) {
	if (radius <= 0) return;
	const int r2 = radius * radius;
	const uint16_t* lut = hd_glow_lut_get(radius);
	int y0 = cy - radius, y1 = cy + radius, x0 = cx - radius, x1 = cx + radius;
	if (y0 < 0) y0 = 0;
	if (y1 > d->h - 1) y1 = d->h - 1;
	if (x0 < 0) x0 = 0;
	if (x1 > d->w - 1) x1 = d->w - 1;
	const int sr = (int)((rgb >> 16) & 255), sg = (int)((rgb >> 8) & 255), sb = (int)(rgb & 255);
	for (int y = y0; y <= y1; y++) {
		const int dy = y - cy, dy2 = dy * dy;
		uint32_t* row = d->px + (size_t)y * d->pitch;
		for (int x = x0; x <= x1; x++) {
			const int dx = x - cx, q = dx * dx + dy2;
			if (q >= r2) continue;
			const int f = lut ? lut[q] : hd_glow_f(q, r2);   // 1 at the centre, 0 at the edge, quadratic falloff
			const int a = (f * strength) >> 8;
			if (a > 0) {
				const uint32_t dst = row[x];
				int r = (int)((dst >> 16) & 255) + ((sr * a) >> 8);
				int g = (int)((dst >> 8) & 255)  + ((sg * a) >> 8);
				int b = (int)(dst & 255)         + ((sb * a) >> 8);
				if (r > 255) r = 255;
				if (g > 255) g = 255;
				if (b > 255) b = 255;
				row[x] = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
			}
		}
	}
}

// soft puff (clouds): ellipse with a smooth alpha edge. x,y,w,h in HD pixels
// The parts of the maths that only depend on the column (or only on the row) are done once per column / row.
#define HD_PUFF_MAXW 512
static void hd_puff(hd_surf* d, int x, int y, int w, int h, uint32_t body, uint32_t rim, int alpha) {
	const float rx = w * 0.5f, ry = h * 0.5f, cx = x + rx, cy = y + ry;
	int xa = x, xb = x + w, ya = y, yb = y + h;
	if (xa < 0) xa = 0;
	if (xb > d->w) xb = d->w;
	if (ya < 0) ya = 0;
	if (yb > d->h) yb = d->h;
	if (xa >= xb || ya >= yb) return;
	float nx2[HD_PUFF_MAXW], thr[HD_PUFF_MAXW];
	for (int xs = xa; xs < xb; xs += HD_PUFF_MAXW) {
		const int xe = (xb - xs > HD_PUFF_MAXW) ? xs + HD_PUFF_MAXW : xb;
		for (int xx = xs; xx < xe; xx++) {
			float nx = (xx + 0.5f - cx) / rx;
			nx2[xx - xs] = nx * nx;
			thr[xx - xs] = -0.35f + 0.25f * nx;             // rim colour above this line
		}
		for (int yy = ya; yy < yb; yy++) {
			const float ny = (yy + 0.5f - cy) / ry;
			const float ny2 = ny * ny;
			uint32_t* row = d->px + (size_t)yy * d->pitch;
			for (int xx = xs; xx < xe; xx++) {
				float q = nx2[xx - xs] + ny2;
				if (q >= 1.f) continue;
				float e = 1.f - q;                           // 0 at the edge
				int a = (int)(alpha * fminf(1.f, e * 3.2f));
				if (a <= 0) continue;                        // (a mix with 0 leaves the pixel as it is)
				uint32_t c = (ny < thr[xx - xs]) ? rim : body;   // brighter upper rim
				row[xx] = hd_mix(row[xx], c, a);
			}
		}
	}
}

// ---------------------------------------------------------------- backdrop
static inline uint32_t hd_rgb(int r, int g, int b) { return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b; }
static inline uint32_t hd_lerp(uint32_t a, uint32_t b, int t256) { return hd_mix(a, b, t256); }

typedef struct { uint32_t top, mid, low, far, near, star, fog; } hd_theme;
static const hd_theme hd_themes[3] = {
	// 0: night (levels 1-10)
	{ 0x070a1f, 0x14183f, 0x2d2457, 0x1b2050, 0x101436, 0xcfd8ff, 0x3a3470 },
	// 1: dusk (the pink levels)
	{ 0x1f0b33, 0x5a1a4e, 0xa4385e, 0x4b1a4c, 0x2c1038, 0xffd0e0, 0xb04a70 },
	// 2: cold summit
	{ 0x0b1530, 0x1d3a6b, 0x4a6aa5, 0x31508a, 0x1b2f5c, 0xeaf6ff, 0x6f8fc7 },
};

static const unsigned char hd_bayer4[16] = { 0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5 };

// height of a mountain layer at column x (HD pixels); pseudo-random ridge from a few sines
static float hd_ridge(float x, float seed, float freq) {
	float v = sinf(x * freq + seed) * 0.5f + sinf(x * freq * 2.3f + seed * 1.7f) * 0.28f + sinf(x * freq * 5.1f + seed * 0.3f) * 0.12f;
	return v;
}

__attribute__((unused)) static void hd_backdrop_ref(hd_surf* d, int theme, int room_x, int room_y, int frames) {
	if (theme < 0 || theme > 2) theme = 0;
	const hd_theme* T = &hd_themes[theme];
	const int W = d->w, H = d->h;
	const float par_far = (room_x * 128 + frames * 0.02f) * HD_S * 0.10f;
	const float par_near = (room_x * 128 + frames * 0.04f) * HD_S * 0.22f;
	const float yoff = room_y * 6.0f;
	for (int y = 0; y < H; y++) {
		// vertical sky gradient (3 stops)
		int t = y * 256 / H;
		uint32_t sky = t < 128 ? hd_lerp(T->top, T->mid, t * 2) : hd_lerp(T->mid, T->low, (t - 128) * 2);
		uint32_t* row = d->px + (size_t)y * d->pitch;
		for (int x = 0; x < W; x++) {
			// 4x4 ordered dither of 1/255 steps removes the banding of the gradient
			int dz = hd_bayer4[(y & 3) * 4 + (x & 3)] - 8;
			int r = (int)((sky >> 16) & 255), g = (int)((sky >> 8) & 255), b = (int)(sky & 255);
			r += dz >> 3; g += dz >> 3; b += dz >> 3;
			row[x] = hd_rgb(hd_clampi(r, 0, 255), hd_clampi(g, 0, 255), hd_clampi(b, 0, 255));
		}
	}
	// stars (night / cold only)
	if (theme != 1) {
		for (int i = 0; i < 70; i++) {
			unsigned n = (unsigned)i * 2654435761u;
			int sx = (int)((n >> 3) % (unsigned)W), sy = (int)(((n >> 11) * 40503u) % (unsigned)(H * 6 / 10));
			int tw = (frames / 8 + i * 7) % 24;
			int a = tw < 12 ? 70 + tw * 10 : 70 + (24 - tw) * 10;
			uint32_t* p = d->px + (size_t)sy * d->pitch + sx;
			*p = hd_mix(*p, T->star, a);
			if (i % 9 == 0) {                              // a few brighter crosses
				if (sx > 0) p[-1] = hd_mix(p[-1], T->star, a / 3);
				if (sx < W - 1) p[1] = hd_mix(p[1], T->star, a / 3);
				if (sy > 0) p[-d->pitch] = hd_mix(p[-d->pitch], T->star, a / 3);
				if (sy < H - 1) p[d->pitch] = hd_mix(p[d->pitch], T->star, a / 3);
			}
		}
	}
	// two mountain ranges, far then near, each with a bright rim on its sunlit (left) slope
	for (int layer = 0; layer < 2; layer++) {
		const float par = layer == 0 ? par_far : par_near;
		const float base = H * (layer == 0 ? 0.60f : 0.74f) - yoff * (layer + 1) * 0.3f;
		const float amp = H * (layer == 0 ? 0.26f : 0.22f);
		uint32_t body = layer == 0 ? T->far : T->near;
		uint32_t rim = hd_lerp(body, T->star, layer == 0 ? 46 : 30);
		uint32_t fog = T->fog;
		float prev = 0;
		for (int x = 0; x < W; x++) {
			float hgt = hd_ridge((x + par) , layer * 3.1f + 1.3f, layer == 0 ? 0.012f : 0.019f);
			float top = base - hgt * amp;
			if (x == 0) prev = top;
			int ytop = (int)top;
			float slope = top - prev; prev = top;
			for (int y = ytop; y < H; y++) {
				if (y < 0) continue;
				uint32_t* p = d->px + (size_t)y * d->pitch + x;
				int depth = y - ytop;
				uint32_t c = body;
				// rim light along the ridge, stronger on slopes that face the light (falling to the right = lit)
				if (depth < 2) c = hd_lerp(body, rim, slope > 0 ? 210 : 120);
				else if (depth < 5 && slope > 0.12f) c = hd_lerp(body, rim, 70);
				// mist: fades the mountain towards the fog colour near the bottom
				int mist = y * 256 / H - 110; if (mist < 0) mist = 0; if (mist > 200) mist = 200;
				c = hd_lerp(c, fog, layer == 0 ? mist / 2 : mist / 4);
				*p = c;
			}
		}
	}
}


// ---- cached backdrop ----
// The backdrop is the same picture almost every frame: the sky gradient never changes (it is built once per theme) and the
// mountains scroll so slowly (0.004 / 0.018 HD pixels per frame) that only a few columns change their height per frame.
// So the sky+mountains image is kept between frames and only the columns whose outline changed are redrawn; then it is
// copied to the screen and the stars (which twinkle) go on top, skipping the pixels a mountain covers. The result is
// identical, pixel for pixel, to hd_backdrop_ref() above.
#define HD_BD_MAXW 2048
#define HD_BD_MAXH 1088
static uint32_t* hd_bd_sky[3];                     // sky gradient per theme (w*h)
static int hd_bd_sky_w = 0, hd_bd_sky_h = 0;
static uint32_t* hd_bd_comp = NULL;                // sky + both mountain ranges (w*h)
static int hd_bd_comp_theme = -1;
static int hd_bd_top[2][HD_BD_MAXW];               // outline of the image in hd_bd_comp: first mountain row per column
static unsigned char hd_bd_cls[2][HD_BD_MAXW];     // bit0: slope > 0, bit1: slope > 0.12
static uint32_t hd_bd_body[2][HD_BD_MAXH];         // mountain colour per row (body + mist), for the part below the rim

static void hd_bd_build_sky(uint32_t* out, const hd_theme* T, int W, int H) {
	for (int y = 0; y < H; y++) {
		// vertical sky gradient (3 stops)
		int t = y * 256 / H;
		uint32_t sky = t < 128 ? hd_lerp(T->top, T->mid, t * 2) : hd_lerp(T->mid, T->low, (t - 128) * 2);
		const int sr = (int)((sky >> 16) & 255), sg = (int)((sky >> 8) & 255), sb = (int)(sky & 255);
		uint32_t* row = out + (size_t)y * W;
		for (int x = 0; x < W; x++) {
			// 4x4 ordered dither of 1/255 steps removes the banding of the gradient
			int dz = hd_bayer4[(y & 3) * 4 + (x & 3)] - 8;
			int r = sr + (dz >> 3), g = sg + (dz >> 3), b = sb + (dz >> 3);
			row[x] = hd_rgb(hd_clampi(r, 0, 255), hd_clampi(g, 0, 255), hd_clampi(b, 0, 255));
		}
	}
}

// redraws one column of hd_bd_comp: sky from row `from`, then both mountain ranges
static void hd_bd_column(int theme, int W, int H, int x, int from) {
	const hd_theme* T = &hd_themes[theme];
	uint32_t* comp = hd_bd_comp;
	const uint32_t* sky = hd_bd_sky[theme];
	if (from < 0) from = 0;
	for (int y = from; y < H; y++) comp[(size_t)y * W + x] = sky[(size_t)y * W + x];
	for (int layer = 0; layer < 2; layer++) {
		const int ytop = hd_bd_top[layer][x];
		const int cls = hd_bd_cls[layer][x];
		const uint32_t body = layer == 0 ? T->far : T->near;
		const uint32_t rim = hd_lerp(body, T->star, layer == 0 ? 46 : 30);
		const int y0 = ytop < 0 ? 0 : ytop;
		const int yr = ytop + 5 < H ? ytop + 5 : H;          // rows [ytop, ytop+5) may have the rim light
		int y = y0;
		for (; y < yr; y++) {
			const int depth = y - ytop;
			uint32_t c = body;
			// rim light along the ridge, stronger on slopes that face the light (falling to the right = lit)
			if (depth < 2) c = hd_lerp(body, rim, (cls & 1) ? 210 : 120);
			else if (depth < 5 && (cls & 2)) c = hd_lerp(body, rim, 70);
			// mist: fades the mountain towards the fog colour near the bottom
			int mist = y * 256 / H - 110; if (mist < 0) mist = 0; if (mist > 200) mist = 200;
			comp[(size_t)y * W + x] = hd_lerp(c, T->fog, layer == 0 ? mist / 2 : mist / 4);
		}
		for (; y < H; y++) comp[(size_t)y * W + x] = hd_bd_body[layer][y];
	}
}

static void hd_backdrop(hd_surf* d, int theme, int room_x, int room_y, int frames) {
	if (theme < 0 || theme > 2) theme = 0;
	const int W = d->w, H = d->h;
	if (W > HD_BD_MAXW || H > HD_BD_MAXH || W < 1 || H < 1) { hd_backdrop_ref(d, theme, room_x, room_y, frames); return; }
	const hd_theme* T = &hd_themes[theme];

	// buffers (re)allocated only when the surface size changes
	if (W != hd_bd_sky_w || H != hd_bd_sky_h || !hd_bd_comp) {
		for (int i = 0; i < 3; i++) { free(hd_bd_sky[i]); hd_bd_sky[i] = NULL; }
		free(hd_bd_comp); hd_bd_comp = (uint32_t*)malloc((size_t)W * H * sizeof(uint32_t));
		hd_bd_sky_w = W; hd_bd_sky_h = H; hd_bd_comp_theme = -1;
		if (!hd_bd_comp) { hd_bd_sky_w = 0; hd_backdrop_ref(d, theme, room_x, room_y, frames); return; }
	}
	if (!hd_bd_sky[theme]) {
		hd_bd_sky[theme] = (uint32_t*)malloc((size_t)W * H * sizeof(uint32_t));
		if (!hd_bd_sky[theme]) { hd_backdrop_ref(d, theme, room_x, room_y, frames); return; }
		hd_bd_build_sky(hd_bd_sky[theme], T, W, H);
	}
	if (hd_bd_comp_theme != theme) {                       // everything is redrawn for a new theme
		hd_bd_comp_theme = theme;
		for (int layer = 0; layer < 2; layer++) {
			const uint32_t body = layer == 0 ? T->far : T->near;
			for (int y = 0; y < H; y++) {
				int mist = y * 256 / H - 110; if (mist < 0) mist = 0; if (mist > 200) mist = 200;
				hd_bd_body[layer][y] = hd_lerp(body, T->fog, layer == 0 ? mist / 2 : mist / 4);
			}
			for (int x = 0; x < W; x++) hd_bd_top[layer][x] = -0x7fffffff;   // "unknown": forces the redraw
		}
	}

	// outline of both mountain ranges for this frame (same maths as the reference)
	static int ntop[2][HD_BD_MAXW];
	static unsigned char ncls[2][HD_BD_MAXW];
	const float par_far = (room_x * 128 + frames * 0.02f) * HD_S * 0.10f;
	const float par_near = (room_x * 128 + frames * 0.04f) * HD_S * 0.22f;
	const float yoff = room_y * 6.0f;
	for (int layer = 0; layer < 2; layer++) {
		const float par = layer == 0 ? par_far : par_near;
		const float base = H * (layer == 0 ? 0.60f : 0.74f) - yoff * (layer + 1) * 0.3f;
		const float amp = H * (layer == 0 ? 0.26f : 0.22f);
		float prev = 0;
		for (int x = 0; x < W; x++) {
			float hgt = hd_ridge((x + par), layer * 3.1f + 1.3f, layer == 0 ? 0.012f : 0.019f);
			float top = base - hgt * amp;
			if (x == 0) prev = top;
			float slope = top - prev; prev = top;
			ntop[layer][x] = (int)top;
			ncls[layer][x] = (unsigned char)((slope > 0 ? 1 : 0) | (slope > 0.12f ? 2 : 0));
		}
	}
	// redraw the columns that changed
	for (int x = 0; x < W; x++) {
		if (ntop[0][x] == hd_bd_top[0][x] && ncls[0][x] == hd_bd_cls[0][x] &&
		    ntop[1][x] == hd_bd_top[1][x] && ncls[1][x] == hd_bd_cls[1][x]) continue;
		int from = ntop[0][x] < ntop[1][x] ? ntop[0][x] : ntop[1][x];
		if (hd_bd_top[0][x] == -0x7fffffff) from = 0;      // nothing valid there yet
		else {
			if (hd_bd_top[0][x] < from) from = hd_bd_top[0][x];
			if (hd_bd_top[1][x] < from) from = hd_bd_top[1][x];
		}
		hd_bd_top[0][x] = ntop[0][x]; hd_bd_top[1][x] = ntop[1][x];
		hd_bd_cls[0][x] = ncls[0][x]; hd_bd_cls[1][x] = ncls[1][x];
		hd_bd_column(theme, W, H, x, from);
	}

	// to the screen
	if (d->pitch == W) memcpy(d->px, hd_bd_comp, (size_t)W * H * sizeof(uint32_t));
	else for (int y = 0; y < H; y++) memcpy(d->px + (size_t)y * d->pitch, hd_bd_comp + (size_t)y * W, (size_t)W * sizeof(uint32_t));

	// stars (night / cold only); a pixel under a mountain is left alone
	if (theme != 1) {
		#define HD_BD_FREE(px_, py_) ((py_) < hd_bd_top[0][px_] && (py_) < hd_bd_top[1][px_])
		for (int i = 0; i < 70; i++) {
			unsigned n = (unsigned)i * 2654435761u;
			int sx = (int)((n >> 3) % (unsigned)W), sy = (int)(((n >> 11) * 40503u) % (unsigned)(H * 6 / 10));
			int tw = (frames / 8 + i * 7) % 24;
			int a = tw < 12 ? 70 + tw * 10 : 70 + (24 - tw) * 10;
			uint32_t* p = d->px + (size_t)sy * d->pitch + sx;
			if (HD_BD_FREE(sx, sy)) *p = hd_mix(*p, T->star, a);
			if (i % 9 == 0) {                              // a few brighter crosses
				if (sx > 0 && HD_BD_FREE(sx - 1, sy)) p[-1] = hd_mix(p[-1], T->star, a / 3);
				if (sx < W - 1 && HD_BD_FREE(sx + 1, sy)) p[1] = hd_mix(p[1], T->star, a / 3);
				if (sy > 0 && HD_BD_FREE(sx, sy - 1)) p[-d->pitch] = hd_mix(p[-d->pitch], T->star, a / 3);
				if (sy < H - 1 && HD_BD_FREE(sx, sy + 1)) p[d->pitch] = hd_mix(p[d->pitch], T->star, a / 3);
			}
		}
		#undef HD_BD_FREE
	}
}

// ---------------------------------------------------------------- final pass: vignette (+ slight warm/cool grade)
static unsigned char hd_vig[1];                    // placeholder to keep the symbol list tidy
static int hd_vig_lw = 0, hd_vig_lh = 0, hd_vig_ls = -1;
static unsigned char* hd_vig_lut = NULL;
static unsigned char hd_vig_store[1920 * 1088 / 4];
// builds the vignette table when the size / strength changed. Returns 1 if the table is usable.
static int hd_vignette_prepare(int w, int h, int strength /*0..256*/) {
	if (w != hd_vig_lw || h != hd_vig_lh || hd_vig_ls != strength) {
		hd_vig_lut = ((size_t)w * h <= sizeof hd_vig_store) ? hd_vig_store : NULL;
		if (hd_vig_lut) {
			for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
				float nx = (x + 0.5f) / w * 2.f - 1.f, ny = (y + 0.5f) / h * 2.f - 1.f;
				float q = nx * nx * 0.55f + ny * ny * 0.9f;       // wider than tall
				float v = 1.f - fminf(1.f, q * q * 0.55f) * (strength / 256.f);
				hd_vig_lut[y * w + x] = (unsigned char)(v * 255.f);
			}
		}
		hd_vig_lw = w; hd_vig_lh = h; hd_vig_ls = strength;
	}
	return hd_vig_lut != NULL;
}
// one row of the vignette (hd_vignette_prepare() must have been called with the same w/h/strength)
static inline void hd_vignette_row(uint32_t* o, const uint32_t* s, int y, int w) {
	if (!hd_vig_lut) { memcpy(o, s, (size_t)w * sizeof(uint32_t)); return; }
	const unsigned char* lut = hd_vig_lut + (size_t)y * w;
	for (int x = 0; x < w; x++) {
		const uint32_t c = s[x];
		const unsigned v = lut[x] + 1u;                 // 1..256
		const uint32_t rb = (((c & 0xff00ff) * v) >> 8) & 0xff00ff;
		const uint32_t g  = (((c & 0x00ff00) * v) >> 8) & 0x00ff00;
		o[x] = rb | g;
	}
}
static void hd_vignette(uint32_t* dst, const uint32_t* src, int w, int h, int pitch_src, int strength /*0..256*/) {
	hd_vignette_prepare(w, h, strength);
	for (int y = 0; y < h; y++) hd_vignette_row(dst + (size_t)y * w, src + (size_t)y * pitch_src, y, w);
}

#endif
