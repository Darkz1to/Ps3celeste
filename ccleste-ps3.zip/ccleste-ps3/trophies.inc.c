// Trophies (co-op) for ccleste.
// Included by menu.inc.c, after the drawing helpers (m_rect, m_text, m_spr, ...) and after
// savedata.inc.c (the unlocked trophies live in `trophy_mask`, which the savedata writes).
//
//  - 10 trophies (bronze / silver / gold) + 1 platinum for unlocking all of them
//  - the game (celeste.c) sends events through Celeste_P8_set_event_func(): trophy_event()
//  - a banner (toast) slides in at the top of the screen when something is unlocked
//  - trophy_draw_list() draws the list screen (used by the title menu and by the pause menu)
//
// To add a trophy: add an id to the enum (and bump TROPHY_TOTAL in savedata.inc.c), a line in
// tr_defs[], and call trophy_unlock(id) from trophy_event().

// 1 = only co-op games unlock trophies (the trophy screen says "co-op"); 0 = solo too
#define TROPHY_COOP_ONLY 1

// ids = bit numbers in trophy_mask, also the order of the list on screen
enum {
	TR_PLATINUM = 0,
	TR_SUMMIT, TR_BERRIES, TR_SYNC10,          // gold
	TR_SYNC5, TR_ANGEL, TR_ORB,                // silver
	TR_FIRST_BERRY, TR_RESCUE1, TR_FUSION, TR_CHEST,   // bronze
	TR_COUNT
};
// TROPHY_TOTAL (savedata.inc.c) must match the number of trophies
typedef char tr_count_check_[(TR_COUNT == TROPHY_TOTAL) ? 1 : -1];
// the platinum needs every other trophy
#define TR_PLAT_REQ (TROPHY_ALL_MASK & ~(1u << TR_PLATINUM))

// goals (change here to rebalance)
#define TR_GOAL_SYNC_A    5     // rooms in a row without anyone dying (silver)
#define TR_GOAL_SYNC_B   10     // (gold)
#define TR_GOAL_RESCUES  15     // rescues in a single game
#define TR_GOAL_BERRIES  18     // every strawberry of the mountain

enum { TIER_BRONZE, TIER_SILVER, TIER_GOLD, TIER_PLAT };
enum { IC_HEART, IC_SUMMIT, IC_GOLDBERRY, IC_FLAME, IC_NOTE, IC_ANGEL, IC_ORB, IC_BERRY,
       IC_BUBBLE, IC_FUSE, IC_CHEST, IC_LOCK, IC_COUNT };

typedef struct { const char* name[2]; const char* desc[2]; unsigned char tier, icon; } trophy_def_t;
// no accents: the pico-8 font doesn't have them. [0] = english, [1] = portuguese
static const trophy_def_t tr_defs[TR_COUNT] = {
	[TR_PLATINUM]    = { { "heart of the mountain", "coracao da montanha" },
	                     { "unlock every trophy",   "conquiste todos os trofeus" }, TIER_PLAT, IC_HEART },
	[TR_SUMMIT]      = { { "top of the world",      "topo do mundo" },
	                     { "reach the summit",      "chegue ao topo da montanha" }, TIER_GOLD, IC_SUMMIT },
	[TR_BERRIES]     = { { "berry hunters",         "cacadores de morangos" },
	                     { "collect all 18 strawberries", "colete os 18 morangos" }, TIER_GOLD, IC_GOLDBERRY },
	[TR_SYNC10]      = { { "total sync",            "sincronia total" },
	                     { "10 rooms in a row, no deaths", "10 salas seguidas sem ninguem morrer" }, TIER_GOLD, IC_FLAME },
	[TR_SYNC5]       = { { "in tune",               "sintonia fina" },
	                     { "5 rooms in a row, no deaths", "5 salas seguidas sem ninguem morrer" }, TIER_SILVER, IC_NOTE },
	[TR_ANGEL]       = { { "guardian angel",        "anjo da guarda" },
	                     { "save your partner 15x in one game", "salve o parceiro 15x em uma partida" }, TIER_SILVER, IC_ANGEL },
	[TR_ORB]         = { { "beyond the limit",      "alem do limite" },
	                     { "grab the double dash crystal", "pegue o cristal do dash duplo" }, TIER_SILVER, IC_ORB },
	[TR_FIRST_BERRY] = { { "first berry",           "primeiro morango" },
	                     { "collect your first strawberry", "colete seu primeiro morango" }, TIER_BRONZE, IC_BERRY },
	[TR_RESCUE1]     = { { "first rescue",          "primeiro resgate" },
	                     { "save your partner from the bubble", "salve o parceiro da bolha" }, TIER_BRONZE, IC_BUBBLE },
	[TR_FUSION]      = { { "two as one",            "dois em um" },
	                     { "fuse both players",     "funda os dois jogadores" }, TIER_BRONZE, IC_FUSE },
	[TR_CHEST]       = { { "treasure hunters",      "cacadores de tesouro" },
	                     { "open the chest with the key", "abra o bau com a chave" }, TIER_BRONZE, IC_CHEST },
};
static const char* const tr_tier_name[2][4] = {
	{ "bronze", "silver", "gold", "platinum" },
	{ "bronze", "prata",  "ouro", "platina" },
};
static const unsigned char tr_tier_col[4] = { 9, 6, 10, 12 };   // bronze orange, silver gray, gold yellow, platinum blue

#define TR_NAME(i) (tr_defs[i].name[cfg_lang])
#define TR_DESC(i) (tr_defs[i].desc[cfg_lang])
#define TR_UNLOCKED(i) (((trophy_mask >> (i)) & 1u) != 0)

// ---------------------------------------------------------------- run counters (not saved)
static int tr_streak = 0;        // rooms in a row without anyone dying
static int tr_rescues = 0;       // rescues in this game
static int tr_berries = 0;       // strawberries collected in this game
static int tr_save_pending = 0;  // an unlock happened: the frontend must write the savedata

// ---------------------------------------------------------------- banner (toast)
#define TR_TOAST_TICKS 100       // game ticks (30 per second): ~3.3 s
#define TR_TOAST_SLIDE 8
static int tr_toast_q[TR_COUNT + 2], tr_toast_n = 0;
static int tr_toast_id = -1, tr_toast_t = 0;

static void trophy_unlock(int id) {
	if (id < 0 || id >= TR_COUNT || TR_UNLOCKED(id)) return;
	trophy_mask |= 1u << id;
	tr_save_pending = 1;
	if (tr_toast_n < (int)(sizeof tr_toast_q / sizeof *tr_toast_q)) tr_toast_q[tr_toast_n++] = id;
	if ((trophy_mask & TR_PLAT_REQ) == TR_PLAT_REQ) trophy_unlock(TR_PLATINUM);
}

// returns 1 (once) after something was unlocked: the frontend writes the savedata
static int trophy_take_save(void) {
	const int r = tr_save_pending;
	tr_save_pending = 0;
	return r;
}

// the game tells us what happens (see celeste.h)
static void trophy_event(int ev, int a, int b) {
	(void)b;
	if (ev == CELESTE_EV_RUN_START) {            // new game or continue: counters start over
		tr_streak = 0; tr_rescues = 0; tr_berries = a;
		return;
	}
#if TROPHY_COOP_ONLY
	if (!Celeste_P8_get_coop()) return;
#endif
	switch (ev) {
	case CELESTE_EV_ROOM_NEXT:
		tr_streak++;
		if (tr_streak >= TR_GOAL_SYNC_A) trophy_unlock(TR_SYNC5);
		if (tr_streak >= TR_GOAL_SYNC_B) trophy_unlock(TR_SYNC10);
		break;
	case CELESTE_EV_DEATH:
		tr_streak = 0;
		break;
	case CELESTE_EV_RESCUE:
		tr_rescues++;
		trophy_unlock(TR_RESCUE1);
		if (tr_rescues >= TR_GOAL_RESCUES) trophy_unlock(TR_ANGEL);
		break;
	case CELESTE_EV_FUSE:   trophy_unlock(TR_FUSION); break;
	case CELESTE_EV_FRUIT:
		tr_berries = a;
		trophy_unlock(TR_FIRST_BERRY);
		if (a >= TR_GOAL_BERRIES) trophy_unlock(TR_BERRIES);
		break;
	case CELESTE_EV_ORB:    trophy_unlock(TR_ORB); break;
	case CELESTE_EV_CHEST:  trophy_unlock(TR_CHEST); break;
	case CELESTE_EV_SUMMIT: trophy_unlock(TR_SUMMIT); break;
	}
}

// progress of a locked trophy: returns 1 and fills cur / max when it can be counted
static int trophy_progress(int id, int* cur, int* max) {
	switch (id) {
	case TR_PLATINUM: {
		int n = 0;
		for (int i = 1; i < TR_COUNT; i++) n += TR_UNLOCKED(i);
		*cur = n; *max = TR_COUNT - 1; return 1;
	}
	case TR_SYNC5:   *cur = tr_streak < TR_GOAL_SYNC_A ? tr_streak : TR_GOAL_SYNC_A; *max = TR_GOAL_SYNC_A; return 1;
	case TR_SYNC10:  *cur = tr_streak < TR_GOAL_SYNC_B ? tr_streak : TR_GOAL_SYNC_B; *max = TR_GOAL_SYNC_B; return 1;
	case TR_ANGEL:   *cur = tr_rescues < TR_GOAL_RESCUES ? tr_rescues : TR_GOAL_RESCUES; *max = TR_GOAL_RESCUES; return 1;
	case TR_BERRIES: *cur = tr_berries < TR_GOAL_BERRIES ? tr_berries : TR_GOAL_BERRIES; *max = TR_GOAL_BERRIES; return 1;
	}
	return 0;
}

// ---------------------------------------------------------------- icons (8x8)
// '.' = transparent; letters are pico-8 colors
static const char* const tr_bitmaps[IC_COUNT][8] = {
	[IC_HEART]  = { ".yy..yy.", "ywyyyyyy", "ywyyyyyy", "yyyyyyyo", ".yyyyyo.", "..yyyo..", "...yo...", "........" },
	[IC_SUMMIT] = { "....wrr.", "....wr..", "...lw...", "..lwww..", ".llwwlk.", ".lllllkk", "lllllkkk", "llllkkkk" },
	[IC_FLAME]  = { "...o....", "..oo.o..", "..ooyo..", ".ooyyoo.", ".oyyyyo.", ".oyyyyo.", "..oyyo..", "...oo..." },
	[IC_NOTE]   = { "...bbbbb", "...bbbbb", "...b...b", "...b...b", "..bb..bb", ".bbb.bbb", "..b...b.", "........" },
	[IC_ANGEL]  = { "..yyyy..", ".y....y.", "..yyyy..", "w..pp..w", "ww.pp.ww", ".wwppww.", "..wppw..", "...pp..." },
	[IC_BUBBLE] = { "..bbbb..", ".bwbbbb.", "bbwbbbbb", "bbdbbdbb", "bbbbbbbb", "bdbbbbdb", ".bddddb.", "..bbbb.." },
	[IC_FUSE]   = { "..ppbb..", ".pppbbb.", "pppwwbbb", "ppwwwwbb", "ppwwwwbb", "pppwwbbb", ".pppbbb.", "..ppbb.." },
	[IC_LOCK]   = { "..llll..", ".l....l.", ".l....l.", "kkkkkkkk", "kkkddkkk", "kkkddkkk", "kkkkkkkk", "kkkkkkkk" },
};
static int tr_pix_col(char ch) {
	switch (ch) {
	case 'r': return 8;  case 'y': return 10; case 'g': return 11; case 'b': return 12;
	case 'w': return 7;  case 'p': return 14; case 'o': return 9;  case 'd': return 1;
	case 'k': return 5;  case 'l': return 6;  case 'n': return 4;  case 'c': return 13;
	}
	return -1;
}
static void tr_icon8(int icon, int x, int y) {
	switch (icon) {
	case IC_BERRY:      m_spr(26, x, y, 0); return;                       // the game's strawberry
	case IC_GOLDBERRY:  pico8emu(CELESTE_P8_PAL, 8, 10); m_spr(26, x, y, 0);   // a golden one
	                    pico8emu(CELESTE_P8_PAL_RESET); return;
	case IC_ORB:        m_spr(102, x, y, 0); return;
	case IC_CHEST:      m_spr(20, x, y, 0); return;
	}
	if (icon < 0 || icon >= IC_COUNT) return;
	for (int r = 0; r < 8; r++) {
		const char* row = tr_bitmaps[icon][r];
		for (int c = 0; c < 8; ) {
			const int col = tr_pix_col(row[c]);
			int e = c;
			while (e + 1 < 8 && row[e + 1] == row[c]) e++;
			if (col >= 0) m_rect(x + c, y + r, x + e, y + r, col);
			c = e + 1;
		}
	}
}
// icon in a small framed slot (14x14); locked ones show the lock and a gray frame
static void tr_icon_slot(int id, int x, int y, int unlocked) {
	const int col = unlocked ? tr_tier_col[tr_defs[id].tier] : 5;
	m_rect(x, y, x + 13, y + 13, col);
	m_rect(x + 1, y + 1, x + 12, y + 12, 0);
	tr_icon8(unlocked ? tr_defs[id].icon : IC_LOCK, x + 3, y + 3);
}

// ---------------------------------------------------------------- small drawing helpers
// text clipped to maxw pixels
static void m_text_clip(const char* s, int x, int y, int c, int maxw) {
	char buf[72];
	int n = maxw / 4;
	if (n < 0) n = 0;
	if (n > (int)sizeof buf - 1) n = (int)sizeof buf - 1;
	strncpy(buf, s, (size_t)n);
	buf[n] = 0;
	m_text(buf, x, y, c);
}
// framed box like the reference: light blue frame, white line, black inside
static void m_panel(int x0, int y0, int x1, int y1) {
	m_rect(x0, y0, x1, y1, 12);
	m_rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, 7);
	m_rect(x0 + 2, y0 + 2, x1 - 2, y1 - 2, 0);
}
// controller button glyphs for the footer (PS3): cross (blue) and circle (red)
static void m_glyph_cross(int x, int y, int c) {
	for (int k = 0; k < 5; k++) { m_rect(x + k, y + k, x + k, y + k, c); m_rect(x + 4 - k, y + k, x + 4 - k, y + k, c); }
}
static void m_glyph_circle(int x, int y, int c) {
	m_rect(x + 1, y, x + 3, y, c); m_rect(x + 1, y + 4, x + 3, y + 4, c);
	m_rect(x, y + 1, x, y + 3, c); m_rect(x + 4, y + 1, x + 4, y + 3, c);
}

// word wrap: writes up to max_lines lines of at most `cols` characters; returns the line count
static int tr_wrap(const char* s, int cols, char out[][40], int max_lines) {
	int n = 0;
	const char* p = s;
	if (cols > 38) cols = 38;
	while (*p && n < max_lines) {
		while (*p == ' ') p++;
		int len = (int)strlen(p);
		if (len <= cols) { strcpy(out[n++], p); break; }
		int cut = cols;
		while (cut > 0 && p[cut] != ' ') cut--;
		if (cut == 0) cut = cols;
		memcpy(out[n], p, (size_t)cut);
		out[n][cut] = 0;
		n++;
		p += cut;
	}
	return n;
}

// ---------------------------------------------------------------- banner drawing
static void trophy_toast_update_draw(void) {
	if (tr_toast_id < 0) {
		if (tr_toast_n == 0) return;
		tr_toast_id = tr_toast_q[0];
		for (int i = 1; i < tr_toast_n; i++) tr_toast_q[i - 1] = tr_toast_q[i];
		tr_toast_n--;
		tr_toast_t = 0;
		menu_play_sfx(55);
	}
	const int id = tr_toast_id;
	const int t = tr_toast_t++;
	if (t >= TR_TOAST_TICKS) { tr_toast_id = -1; return; }

	// slide in from the top, hold, slide out
	const int h = 22, rest_y = 3;
	int y = rest_y;
	if (t < TR_TOAST_SLIDE) y = rest_y - (h + rest_y) * (TR_TOAST_SLIDE - t) / TR_TOAST_SLIDE;
	else if (t >= TR_TOAST_TICKS - TR_TOAST_SLIDE) y = rest_y - (h + rest_y) * (t - (TR_TOAST_TICKS - TR_TOAST_SLIDE)) / TR_TOAST_SLIDE;

	const int tier = tr_defs[id].tier, col = tr_tier_col[tier];
	char l2[48];
	snprintf(l2, sizeof l2, "[%s] %s", tr_tier_name[cfg_lang][tier], cfg_lang == LANG_PT ? "trofeu desbloqueado!" : "trophy unlocked!");
	const char* l1 = TR_NAME(id);
	int cw = (int)strlen(l1) > (int)strlen(l2) ? (int)strlen(l1) : (int)strlen(l2);
	int w = cw * 4 + 28;
	const int maxw = 128 + 2 * VIEW_OX - 8;
	if (w > maxw) w = maxw;
	const int x0 = 64 - w / 2, x1 = x0 + w - 1;

	pico8emu(CELESTE_P8_CAMERA, 0, 0);
	pico8emu(CELESTE_P8_PAL_RESET);
	m_rect(x0, y, x1, y + h - 1, col);
	m_rect(x0 + 1, y + 1, x1 - 1, y + h - 2, 0);
	tr_icon_slot(id, x0 + 4, y + 4, 1);
	// gold / platinum: a faint shine runs over the banner
	const int sh = (tr_toast_t * 3) % (w + 30) - 15;
	if (tier >= TIER_GOLD && sh > 2 && sh < w - 2) m_rect(x0 + sh, y + 1, x0 + sh, y + h - 2, 5);
	m_text_clip(l1, x0 + 22, y + 5, 7, w - 26);
	m_text_clip(l2, x0 + 22, y + 12, col, w - 26);
}

// ---------------------------------------------------------------- list screen
#define TR_ROWS   4
#define TR_ROW_H  19
#define TR_LIST_Y 34

// panel limits: as wide as the screen allows (widescreen), but not more than 184 px
static void tr_layout(int* x0, int* x1) {
	int w = 128 + 2 * VIEW_OX - (VIEW_OX ? 24 : 8);
	if (w > 184) w = 184;
	*x0 = 64 - w / 2;
	*x1 = *x0 + w - 1;
}

// keeps the selected entry inside the window of TR_ROWS rows
static int trophy_fix_top(int sel, int top) {
	if (sel < top) top = sel;
	if (sel >= top + TR_ROWS) top = sel - TR_ROWS + 1;
	if (top > TR_COUNT - TR_ROWS) top = TR_COUNT - TR_ROWS;
	if (top < 0) top = 0;
	return top;
}

static void tr_footer(void) {
#if defined(PLATFORM_PS3)
	const char* a = cfg_lang == LANG_PT ? "selecionar" : "select";
	const char* b = cfg_lang == LANG_PT ? "voltar" : "back";
	const int wa = 7 + (int)strlen(a) * 4, wb = 7 + (int)strlen(b) * 4;
	int x = 64 - (wa + 8 + wb) / 2;
	m_glyph_cross(x, 118, 12);      m_text(a, x + 7, 117, 7);
	x += wa + 8;
	m_glyph_circle(x, 118, 8);      m_text(b, x + 7, 117, 7);
#else
	m_text_c(menu_hint_sub(), 117, 6);
#endif
}

// the list of trophies. sel = highlighted entry, top = first visible entry,
// detail = the popup of the selected trophy is open, from_pause = a game is paused behind
static void trophy_draw_list(int sel, int top, int detail, int from_pause) {
	int x0, x1;
	tr_layout(&x0, &x1);
	const int compact = (x1 - x0) < 150;
	m_panel(x0, 8, x1, 113);

	// tab with the title, overlapping the top edge
	const char* tab = cfg_lang == LANG_PT ? "taba de trofeus locais" : "local trophy tab";
	const int tw = (int)strlen(tab) * 4 + 10, tx0 = 64 - tw / 2, tx1 = tx0 + tw - 1;
	m_panel(tx0, 1, tx1, 10);
	m_text(tab, tx0 + 5, 3, 7);

	// counter and bar
	const int n = trophy_count();
	char line[48];
	m_text_c(cfg_lang == LANG_PT ? "trofeus locais (co-op)" : "local trophies (co-op)", 15, 7);
	snprintf(line, sizeof line, "%d/%d %s (%d%%)", n, TR_COUNT, cfg_lang == LANG_PT ? "desbloqueados" : "unlocked", n * 100 / TR_COUNT);
	m_text_c(line, 22, 7);
	{
		const int bx0 = x0 + 6, bx1 = x1 - 6, fill = (bx1 - bx0 + 1) * n / TR_COUNT;
		m_rect(bx0, 29, bx1, 30, 1);
		if (fill > 0) m_rect(bx0, 29, bx0 + fill - 1, 30, n == TR_COUNT ? 10 : 11);
	}

	// rows
	for (int r = 0; r < TR_ROWS; r++) {
		const int i = top + r;
		if (i >= TR_COUNT) break;
		const int ry = TR_LIST_Y + r * TR_ROW_H, unl = TR_UNLOCKED(i);
		const int tier = tr_defs[i].tier;
		tr_icon_slot(i, x0 + 5, ry + 2, unl);

		char tag[16];
		snprintf(tag, sizeof tag, unl ? "[%s]" : "[???]", tr_tier_name[cfg_lang][tier]);
		const int tx = x0 + 24, right = x1 - 12, tagx = right - (int)strlen(tag) * 4;
		m_text_clip(TR_NAME(i), tx, ry + 3, unl ? 7 : 5, (compact ? right : tagx - 4) - tx);
		m_text_clip(TR_DESC(i), tx, ry + 11, unl ? 6 : 5, right - tx);
		if (!compact) m_text(tag, tagx, ry + 3, unl ? tr_tier_col[tier] : 5);

		m_rect(x0 + 4, ry + 18, right, ry + 18, 1);              // divider
		if (i == sel) {                                          // blinking outline
			const int c = (menu_t / 5 % 2) ? 7 : 12;
			m_rect(x0 + 3, ry, right + 1, ry, c);
			m_rect(x0 + 3, ry + 17, right + 1, ry + 17, c);
			m_rect(x0 + 3, ry, x0 + 3, ry + 17, c);
			m_rect(right + 1, ry, right + 1, ry + 17, c);
		}
	}

	// scroll bar
	if (TR_COUNT > TR_ROWS) {
		const int sbx = x1 - 9, full = TR_ROWS * TR_ROW_H - 1;
		const int th = full * TR_ROWS / TR_COUNT;
		const int ty = TR_LIST_Y + (full - th) * top / (TR_COUNT - TR_ROWS);
		m_rect(sbx, TR_LIST_Y, sbx + 1, TR_LIST_Y + full - 1, 1);
		m_rect(sbx, ty, sbx + 1, ty + th - 1, 13);
	}

	tr_footer();

	// popup with the details of the selected trophy
	if (detail) {
		const int id = sel, unl = TR_UNLOCKED(id), tier = tr_defs[id].tier;
		const int dx0 = x0 + 10, dx1 = x1 - 10, dy0 = 40, dy1 = 94;
		m_panel(dx0, dy0, dx1, dy1);
		tr_icon_slot(id, dx0 + 6, dy0 + 6, unl);
		m_text_clip(TR_NAME(id), dx0 + 26, dy0 + 7, 7, dx1 - dx0 - 30);
		char tag[24];
		snprintf(tag, sizeof tag, "[%s]", tr_tier_name[cfg_lang][tier]);
		m_text(tag, dx0 + 26, dy0 + 15, tr_tier_col[tier]);
		char lines[3][40];
		const int cnt = tr_wrap(TR_DESC(id), (dx1 - dx0 - 12) / 4, lines, 3);
		for (int k = 0; k < cnt; k++) m_text(lines[k], dx0 + 6, dy0 + 27 + k * 7, 6);
		int cur, max;
		if (unl) {
			m_text(cfg_lang == LANG_PT ? "desbloqueado" : "unlocked", dx0 + 6, dy1 - 10, 11);
		} else {
			if (trophy_progress(id, &cur, &max) && (from_pause || id == TR_PLATINUM))
				snprintf(line, sizeof line, "%s: %d/%d", cfg_lang == LANG_PT ? "progresso" : "progress", cur, max);
			else
				snprintf(line, sizeof line, "%s", cfg_lang == LANG_PT ? "bloqueado" : "locked");
			m_text_clip(line, dx0 + 6, dy1 - 10, 10, dx1 - dx0 - 12);
		}
	}
}
