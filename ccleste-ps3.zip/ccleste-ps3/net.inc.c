// net.inc.c - online co-op for ccleste: two consoles talk through a small TCP relay
// (tools/relay.py, runs in Termux or anywhere with Python 3) and play in lockstep.
//
//  * HOST ("create"): types the IP of the phone running the relay; the relay creates a room and
//    answers with a 16-character CODE that holds the relay's public address + the room.
//  * GUEST ("join"): types that code; the console decodes it back into address + room and
//    connects to the relay. The relay pairs the two, sends each its role (0 = host = player 1,
//    1 = guest = player 2) and a random seed, then just forwards bytes.
//  * Every game tick (30/s) each side sends its own input; a tick only runs when the inputs
//    of both players for that tick are known. Inputs are applied NET_DELAY ticks late, so a
//    normal connection never has to wait. Both sides run the exact same simulation.
//  * Every 60 ticks both sides exchange a hash of the game state to detect desyncs.
//
// The code is only an encoding with a checksum (typos are detected and the address is not
// readable at a glance). It is NOT strong encryption: treat it as a password.
//
// This file has no SDL dependency, so it can be tested on a PC (tools/net_test.c).
#ifndef CCLESTE_NET_INC_C
#define CCLESTE_NET_INC_C

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>

#if defined(PLATFORM_PS3)
	#include <net/net.h>
	#include <netdb.h>
	#include <arpa/inet.h>
	#include <netinet/in.h>
	#include <sys/socket.h>
	#define NET_SUPPORTED 1
#elif defined(_WIN32) || defined(_3DS) || defined(EMSCRIPTEN)
	#define NET_SUPPORTED 0
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <netinet/tcp.h>
	#include <arpa/inet.h>
	#include <netdb.h>
	#include <unistd.h>
	#include <fcntl.h>
	#include <errno.h>
	#define NET_SUPPORTED 1
#endif

#define NET_DELAY        3     // input delay in game ticks (3 ticks = 100 ms)
#define NET_RING         64
#define NET_HASH_EVERY   60
#define NET_STALL_LIMIT  600   // net_step() calls without progress (~20 s) before giving up

enum {
	NET_ST_IDLE, NET_ST_CONNECTING, NET_ST_WAITING, NET_ST_READY,
	NET_ST_ERR_RESOLVE, NET_ST_ERR_CONNECT, NET_ST_ERR_UNSUPPORTED, NET_ST_ERR_LOST, NET_ST_ERR_CODE, NET_ST_ERR_ROOM
};
#define NET_ST_FIRST_ERR NET_ST_ERR_RESOLVE
#define NET_DEFAULT_PORT 7777

static int      net_st = NET_ST_IDLE;
static int      net_sock = -1;
static int      net_mode;             // 0 = host (create), 1 = join
static uint32_t net_target_ip;        // network byte order
static int      net_target_port;
static uint8_t  net_join_room[3];
static char     net_code[20];         // "XXXX-XXXX-XXXX-XXXX" (host: given by the relay)
static char     net_code_raw[24];
static int      net_code_parts;       // bit mask of the 3 code frames received
static int      net_cfg_port = NET_DEFAULT_PORT;
static int      net_role_v;           // 0 = host (player 1), 1 = guest (player 2)
static unsigned net_seed_v;
static int      net_connect_delay;
static int      net_active_v;         // 1 while a networked game is running

static uint8_t  net_rx[8];
static int      net_rx_len;

// lockstep state
static uint32_t net_tick;             // next tick to execute
static uint32_t net_next_send;        // next tick whose local input has not been sent yet
static uint16_t net_in_local[NET_RING];
static uint16_t net_in_remote[NET_RING];
static uint8_t  net_have_remote[NET_RING];
static int      net_stall_calls;
static int      net_stalling_v;

// desync detection
typedef struct { uint16_t tick; uint32_t hash; int valid; } net_hrec_t;
static net_hrec_t net_hmine[8], net_hpeer[8];
static int      net_hmine_n, net_hpeer_n;
static int      net_desync_v;
static unsigned net_desync_tick;

// ---------------------------------------------------------------- platform layer
#if NET_SUPPORTED
static int net_plat_init(void) {
#ifdef PLATFORM_PS3
	static int done = 0;
	if (!done) { if (netInitialize() < 0) return -1; done = 1; }
#endif
	return 0;
}
static int net_plat_socket(void) {
#ifdef PLATFORM_PS3
	return netSocket(AF_INET, SOCK_STREAM, 0);
#else
	return socket(AF_INET, SOCK_STREAM, 0);
#endif
}
static void net_plat_close(int s) {
#ifdef PLATFORM_PS3
	netClose(s);
#else
	close(s);
#endif
}
static void net_plat_timeouts(int s) {   // so a dead relay does not freeze the console for minutes
#if defined(SO_SNDTIMEO) && defined(SO_RCVTIMEO)
	struct timeval tv; tv.tv_sec = 8; tv.tv_usec = 0;
#ifdef PLATFORM_PS3
	netSetSockOpt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv);
	netSetSockOpt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#else
	setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv);
	setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
#else
	(void)s;
#endif
}
static void net_plat_nonblock(int s) {
#ifdef PLATFORM_PS3
	#ifdef SO_NBIO
	int one = 1;
	netSetSockOpt(s, SOL_SOCKET, SO_NBIO, &one, sizeof one);
	#endif
#else
	int fl = fcntl(s, F_GETFL, 0);
	fcntl(s, F_SETFL, fl | O_NONBLOCK);
	int one = 1;
	setsockopt(s, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
#endif
}
static int net_plat_connect(int s, uint32_t ip_be, int port) {
	struct sockaddr_in a;
	memset(&a, 0, sizeof a);
	a.sin_family = AF_INET;
	a.sin_port = htons((unsigned short)port);
	a.sin_addr.s_addr = ip_be;
#ifdef PLATFORM_PS3
	return netConnect(s, (struct sockaddr*)&a, sizeof a);
#else
	return connect(s, (struct sockaddr*)&a, sizeof a);
#endif
}
// >0 bytes read, 0 nothing available, -1 connection closed
static int net_plat_recv(int s, void* buf, int len) {
#ifdef PLATFORM_PS3
	int r = netRecv(s, buf, len, 0);
	if (r == 0) return -1;      // orderly close
	return r < 0 ? 0 : r;       // no data (a dead link is caught by the stall limit)
#else
	int r = (int)recv(s, buf, len, 0);
	if (r > 0) return r;
	if (r == 0) return -1;
	return (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) ? 0 : -1;
#endif
}
static int net_plat_send(int s, const void* buf, int len) {
#ifdef PLATFORM_PS3
	return netSend(s, buf, len, 0);
#else
	#ifdef MSG_NOSIGNAL
	return (int)send(s, buf, len, MSG_NOSIGNAL);
	#else
	return (int)send(s, buf, len, 0);
	#endif
#endif
}
#endif // NET_SUPPORTED

// ---------------------------------------------------------------- frames (8 bytes)
// [type u8][tick u16 le][value u32 le][pad u8]      'I' input, 'H' hash, 'Q' quit
static int net_send_frame(char type, uint16_t tick, uint32_t val) {
#if NET_SUPPORTED
	uint8_t f[8];
	f[0] = (uint8_t)type; f[1] = tick & 255; f[2] = tick >> 8;
	f[3] = val & 255; f[4] = (val >> 8) & 255; f[5] = (val >> 16) & 255; f[6] = (val >> 24) & 255; f[7] = 0;
	if (net_sock < 0) return -1;
	int off = 0, tries = 0;
	while (off < 8 && tries++ < 50) {
		int r = net_plat_send(net_sock, f + off, 8 - off);
		if (r > 0) off += r;
	}
	return off == 8 ? 0 : -1;
#else
	(void)type; (void)tick; (void)val; return -1;
#endif
}

// reads whatever is available; returns 1 and fills f when a full frame is ready
static int net_read_frame(uint8_t f[8]) {
#if NET_SUPPORTED
	if (net_sock < 0) return -1;
	while (net_rx_len < 8) {
		int r = net_plat_recv(net_sock, net_rx + net_rx_len, 8 - net_rx_len);
		if (r < 0) return -1;
		if (r == 0) return 0;
		net_rx_len += r;
	}
	memcpy(f, net_rx, 8);
	net_rx_len = 0;
	return 1;
#else
	(void)f; return -1;
#endif
}

// ---------------------------------------------------------------- codes
// 16 chars (base32, no I/O/0/1) = 10 bytes = scrambled[ip4, port2, room3] + check. Same code as relay.py.
static const char net_alpha[33] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

static uint8_t net_code_check(const uint8_t* p) {
	uint8_t c = 0x5A;
	for (int i = 0; i < 9; i++) c = (uint8_t)(((c << 1) | (c >> 7)) ^ p[i]);
	return (uint8_t)(c * 167 + 13);
}
static void net_code_stream(uint8_t chk, uint8_t* out, int n) {
	uint32_t s = (((uint32_t)chk << 8) | 0x9Du) + 0x1F123BB5u;
	for (int i = 0; i < n; i++) {
		s ^= s << 13; s ^= s >> 17; s ^= s << 5;
		out[i] = (uint8_t)(s & 255);
	}
}
// returns 0 and fills the outputs when the code is valid
static int net_code_decode(const char* code, uint32_t* ip_be, int* port, uint8_t room[3]) {
	uint8_t raw[10]; memset(raw, 0, sizeof raw);
	int n = 0;
	for (const char* c = code; *c; c++) {
		if (*c == '-' || *c == ' ') continue;
		char u = (*c >= 'a' && *c <= 'z') ? (char)(*c - 32) : *c;
		const char* p = strchr(net_alpha, u);
		if (!p || !u || n >= 16) return -1;
		int v = (int)(p - net_alpha);
		for (int k = 0; k < 5; k++) {
			int bit = (v >> (4 - k)) & 1, pos = n * 5 + k;
			raw[pos / 8] |= (uint8_t)(bit << (7 - pos % 8));
		}
		n++;
	}
	if (n != 16) return -1;
	uint8_t chk = raw[9], ks[9], pl[9];
	net_code_stream(chk, ks, 9);
	for (int i = 0; i < 9; i++) pl[i] = raw[i] ^ ks[i];
	if (net_code_check(pl) != chk) return -1;
	memcpy(ip_be, pl, 4);
	*port = (pl[4] << 8) | pl[5];
	memcpy(room, pl + 6, 3);
	return *port > 0 ? 0 : -1;
}

// ---------------------------------------------------------------- saved IP (ccleste-net.cfg)
// ip=a.b.c.d  (last IP typed by the host)   port=7777 (optional: port of the relay on the phone)
static void net_cfg_load(const char* dir, int ip[4]) {
	char path[600], line[128];
	ip[0] = 192; ip[1] = 168; ip[2] = 0; ip[3] = 1;
	net_cfg_port = NET_DEFAULT_PORT;
	snprintf(path, sizeof path, "%s/ccleste-net.cfg", dir && *dir ? dir : ".");
	FILE* f = fopen(path, "r");
	if (!f) return;
	while (fgets(line, sizeof line, f)) {
		int a, b, c, d;
		if (sscanf(line, "ip=%d.%d.%d.%d", &a, &b, &c, &d) == 4 && a >= 0 && a < 256 && b >= 0 && b < 256 && c >= 0 && c < 256 && d >= 0 && d < 256)
			ip[0] = a, ip[1] = b, ip[2] = c, ip[3] = d;
		else if (sscanf(line, "port=%d", &a) == 1 && a > 0 && a < 65536) net_cfg_port = a;
	}
	fclose(f);
}
static void net_cfg_save(const char* dir, const int ip[4]) {
	char path[600];
	snprintf(path, sizeof path, "%s/ccleste-net.cfg", dir && *dir ? dir : ".");
	FILE* f = fopen(path, "w");
	if (!f) return;
	fprintf(f, "ip=%d.%d.%d.%d\nport=%d\n", ip[0], ip[1], ip[2], ip[3], net_cfg_port);
	fclose(f);
}

// ---------------------------------------------------------------- connection
static void net_close(void) {
#if NET_SUPPORTED
	if (net_sock >= 0) {
		if (net_active_v) net_send_frame('Q', 0, 0);
		net_plat_close(net_sock);
	}
#endif
	net_sock = -1;
	net_active_v = 0;
	net_rx_len = 0;
}

static void net_cancel(void) { net_close(); net_st = NET_ST_IDLE; }

static void net_begin_common(void) {
	net_close();
	net_desync_v = 0; net_stalling_v = 0;
	net_code[0] = 0; net_code_parts = 0; memset(net_code_raw, 0, sizeof net_code_raw);
	net_connect_delay = 2;   // lets the screen draw "connecting" before the (blocking) connect
}

// HOST: connect to the relay at this IP (the phone). The relay answers with the code.
static void net_begin_host(const int ip[4], int port) {
	net_begin_common();
#if NET_SUPPORTED
	uint8_t b[4] = { (uint8_t)ip[0], (uint8_t)ip[1], (uint8_t)ip[2], (uint8_t)ip[3] };
	memcpy(&net_target_ip, b, 4);
	net_target_port = port > 0 ? port : NET_DEFAULT_PORT;
	net_mode = 0;
	net_st = NET_ST_CONNECTING;
#else
	(void)ip; (void)port; net_st = NET_ST_ERR_UNSUPPORTED;
#endif
}

// GUEST: decode the code into relay address + room and connect
static void net_begin_join(const char* code) {
	net_begin_common();
#if NET_SUPPORTED
	if (net_code_decode(code, &net_target_ip, &net_target_port, net_join_room) != 0) { net_st = NET_ST_ERR_CODE; return; }
	net_mode = 1;
	net_st = NET_ST_CONNECTING;
#else
	(void)code; net_st = NET_ST_ERR_UNSUPPORTED;
#endif
}

static void net_lockstep_reset(void) {
	memset(net_in_local, 0, sizeof net_in_local);
	memset(net_in_remote, 0, sizeof net_in_remote);
	memset(net_have_remote, 0, sizeof net_have_remote);
	for (int i = 0; i < NET_DELAY; i++) net_have_remote[i] = 1;   // both sides know: zeros
	net_tick = 0; net_next_send = NET_DELAY;
	net_stall_calls = 0; net_stalling_v = 0;
	memset(net_hmine, 0, sizeof net_hmine); memset(net_hpeer, 0, sizeof net_hpeer);
	net_hmine_n = net_hpeer_n = 0;
	net_desync_v = 0;
}

// call once per frame while the "online" screen is open; returns the NET_ST_* state
static int net_menu_poll(void) {
#if NET_SUPPORTED
	if (net_st == NET_ST_CONNECTING) {
		if (net_connect_delay-- > 0) return net_st;
		if (net_plat_init() != 0) { net_st = NET_ST_ERR_CONNECT; return net_st; }
		int s = net_plat_socket();
		if (s < 0) { net_st = NET_ST_ERR_CONNECT; return net_st; }
		net_plat_timeouts(s);
		if (net_plat_connect(s, net_target_ip, net_target_port) != 0) { net_plat_close(s); net_st = NET_ST_ERR_CONNECT; return net_st; }
		net_plat_nonblock(s);
		net_sock = s;
		uint8_t hello[8] = { 'C', 'L', 'N', '2', (uint8_t)(net_mode ? 'J' : 'H'), 0, 0, 0 };
		if (net_mode) memcpy(hello + 5, net_join_room, 3);
		int off = 0, tries = 0;
		while (off < 8 && tries++ < 50) { int r = net_plat_send(s, hello + off, 8 - off); if (r > 0) off += r; }
		if (off < 8) { net_close(); net_st = NET_ST_ERR_CONNECT; return net_st; }
		net_rx_len = 0;
		net_st = NET_ST_WAITING;
		net_stall_calls = 0;
	} else if (net_st == NET_ST_WAITING) {
		uint8_t f[8];
		for (;;) {
			int r = net_read_frame(f);
			if (r < 0) { net_close(); net_st = NET_ST_ERR_LOST; break; }
			if (r == 0) break;
			if (f[0] == 'K' && f[1] < 3) {            // the code, 6 characters per frame
				for (int j = 0; j < 6; j++) if (f[1] * 6 + j < 16) net_code_raw[f[1] * 6 + j] = (char)f[2 + j];
				net_code_parts |= 1 << f[1];
				if (net_code_parts == 7) {
					int o = 0;
					for (int i = 0; i < 16; i++) { if (i && i % 4 == 0) net_code[o++] = '-'; net_code[o++] = net_code_raw[i]; }
					net_code[o] = 0;
				}
			} else if (f[0] == 'X') {                 // join: the relay does not know this room
				net_close(); net_st = NET_ST_ERR_ROOM; break;
			} else if (f[0] == 'P') {
				net_role_v = f[1] ? 1 : 0;
				net_seed_v = (unsigned)f[2] | ((unsigned)f[3] << 8) | ((unsigned)f[4] << 16) | ((unsigned)f[5] << 24);
				net_lockstep_reset();
				net_active_v = 1;
				net_st = NET_ST_READY;
				break;
			}
		}
		// waiting for the other player can take a long time: no timeout here (B cancels)
	}
#endif
	return net_st;
}

// ---------------------------------------------------------------- lockstep
static int net_online_active(void) { return net_active_v; }
static int net_role(void) { return net_role_v; }
static unsigned net_seed(void) { return net_seed_v; }
static int net_stalling(void) { return net_stalling_v; }
static int net_is_desync(void) { return net_desync_v; }
static const char* net_code_text(void) { return net_code_parts == 7 ? net_code : ""; }   // host: valid once the relay answered
static int net_is_host(void) { return net_mode == 0; }

static void net_check_hashes(void) {
	for (int i = 0; i < 8; i++) {
		if (!net_hpeer[i].valid) continue;
		for (int j = 0; j < 8; j++) {
			if (net_hmine[j].valid && net_hmine[j].tick == net_hpeer[i].tick) {
				if (net_hmine[j].hash != net_hpeer[i].hash && !net_desync_v) {
					net_desync_v = 1; net_desync_tick = net_hpeer[i].tick;
				}
				net_hpeer[i].valid = 0; net_hmine[j].valid = 0;
				break;
			}
		}
	}
}

static void net_pump(void) {
	uint8_t f[8];
	for (;;) {
		int r = net_read_frame(f);
		if (r < 0) { net_active_v = 0; net_st = NET_ST_ERR_LOST; return; }
		if (r == 0) return;
		uint16_t tk = (uint16_t)(f[1] | (f[2] << 8));
		uint32_t val = (uint32_t)f[3] | ((uint32_t)f[4] << 8) | ((uint32_t)f[5] << 16) | ((uint32_t)f[6] << 24);
		if (f[0] == 'I') {
			uint16_t ahead = (uint16_t)(tk - (uint16_t)net_tick);
			if (ahead < 2 * NET_DELAY + 4) {
				net_in_remote[tk % NET_RING] = (uint16_t)val;
				net_have_remote[tk % NET_RING] = 1;
			}
		} else if (f[0] == 'H') {
			net_hpeer[net_hpeer_n & 7].tick = tk; net_hpeer[net_hpeer_n & 7].hash = val; net_hpeer[net_hpeer_n & 7].valid = 1;
			net_hpeer_n++;
			net_check_hashes();
		} else if (f[0] == 'Q') {
			net_active_v = 0; net_st = NET_ST_ERR_LOST; return;
		}
	}
}

// Called once per game tick with this console's input (bits 0..5 = left,right,up,down,jump,
// dash; bit 6 = merge; bit 7 = wall grab).
// Returns 1: the tick may run, host_in / guest_in are the inputs of player 1 / player 2
//         0: waiting for the other console (do not update the game this time)
//        -1: the connection was lost
static int net_step(unsigned local, unsigned* host_in, unsigned* guest_in) {
	if (!net_active_v) return -1;
	if (net_next_send <= net_tick + NET_DELAY) {          // send this tick's input once
		net_in_local[net_next_send % NET_RING] = (uint16_t)local;
		if (net_send_frame('I', (uint16_t)net_next_send, local) != 0) { /* a dead link shows up as a stall */ }
		net_next_send++;
	}
	net_pump();
	if (!net_active_v) return -1;
	if (!net_have_remote[net_tick % NET_RING]) {
		net_stalling_v = 1;
		if (++net_stall_calls > NET_STALL_LIMIT) { net_active_v = 0; net_st = NET_ST_ERR_LOST; return -1; }
		return 0;
	}
	net_stalling_v = 0; net_stall_calls = 0;
	unsigned mine = net_in_local[net_tick % NET_RING];
	unsigned theirs = net_in_remote[net_tick % NET_RING];
	net_have_remote[net_tick % NET_RING] = 0;
	if (net_role_v == 0) { *host_in = mine;   *guest_in = theirs; }
	else                 { *host_in = theirs; *guest_in = mine; }
	if (net_tick == 0) *host_in |= (1u << 4);              // the "play" press that starts the game, on both sides
	net_tick++;
	return 1;
}

// Call right after the game update of a tick that net_step() allowed, with a hash of the game state
static void net_after_tick(unsigned hash) {
	if (net_tick % NET_HASH_EVERY != 0) return;
	net_hmine[net_hmine_n & 7].tick = (uint16_t)net_tick; net_hmine[net_hmine_n & 7].hash = hash; net_hmine[net_hmine_n & 7].valid = 1;
	net_hmine_n++;
	net_send_frame('H', (uint16_t)net_tick, hash);
	net_check_hashes();
}

#endif // CCLESTE_NET_INC_C
