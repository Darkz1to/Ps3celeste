// altar.inc.c -- included by celeste.c (after celeste2.inc.c)
//
// The altar at the end of chapter 1 (the flag of the last room): while Madeline stands on it a prompt asks to
// HOLD UP. When the button has been held long enough an ascension animation plays (a pillar of light, sparkles,
// rings, a white flash fading to black) and chapter 2 (Celeste 2) starts in its first level.
//
// State: altar_hold / altar_anim / altar_x0 / altar_y0 (declared in celeste.c, part of the saved state).
// The logic runs in altar_update() (30 ticks per second), altar_draw() only reads it.

#define ALTAR_HOLD 40      // ticks the up button has to be held
#define ALTAR_ANIM 108     // ticks of the ascension (3.6 s)

static OBJ* altar_find(OBJTYPE type) {
	for (int i = 0; i < MAX_OBJECTS; i++)
		if (objects[i].active && objects[i].type == type) return &objects[i];
	return NULL;
}

//Madeline is standing on the altar (and has already touched it: the score box is showing)
static bool altar_ready(OBJ* flag, OBJ* player) {
	return flag && player && flag->show && OBJ_check(flag, OBJ_PLAYER, 0, 0);
}

static float altar_ease(float t) { t = t < 0 ? 0 : (t > 1 ? 1 : t); return t * t * (3 - 2 * t); }

static void altar_update(void) {
	if (c2_active || tut_active || level_index() != 30) { altar_hold = 0; altar_anim = 0; return; }
	OBJ* flag = altar_find(OBJ_FLAG);
	OBJ* player = altar_find(OBJ_PLAYER);

	if (altar_anim > 0) {
		altar_anim -= 1;
		const float t = 1.0f - (float)altar_anim / ALTAR_ANIM;
		if (player) {                                  // Madeline floats up in the light
			player->spd.x = player->spd.y = 0;
			player->x = altar_x0;
			player->y = altar_y0 - 16.0f * altar_ease(t / 0.7f) + P8sin(t * 3.0f) * 1.5f * altar_ease(t / 0.4f);
		}
		if (altar_anim == ALTAR_ANIM * 45 / 100) P8sfx(38);
		if (altar_anim == 0) {
			pause_player = false;
			altar_hold = 0;
			c2_begin();                                // chapter 2, first level
		}
		return;
	}

	if (altar_ready(flag, player)) {
		if (P8btn(k_up)) {
			altar_hold += 1;
			if (altar_hold >= ALTAR_HOLD) {
				altar_anim = ALTAR_ANIM;
				altar_x0 = player->x; altar_y0 = player->y;
				pause_player = true;                   // Madeline stops answering the controller
				player->spd.x = player->spd.y = 0;
				P8music(-1, 600, 0);
				P8sfx(55);
			}
		} else if (altar_hold > 0) {
			altar_hold = altar_hold > 3 ? altar_hold - 3 : 0;   // the charge drains if the button is released
		}
	} else {
		altar_hold = 0;
	}
}

// ---- drawing ----------------------------------------------------------------------------------------
static void altar_px(int x, int y, int c) { P8rectfill(x, y, x, y, c); }

//a d-pad with the UP arm highlighted
static void altar_dpad_up(int x, int y, bool pressed) {
	P8rectfill(x + 4, y, x + 6, y + 10, 6);
	P8rectfill(x, y + 4, x + 10, y + 6, 6);
	P8rectfill(x + 5, y + 5, x + 5, y + 5, 5);
	P8rectfill(x + 4, y + 11, x + 6, y + 11, 5);                 // shadow
	P8rectfill(x + 11, y + 4, x + 11, y + 6, 5);
	const int hi = pressed ? 7 : ((frames / 5) % 2 ? 10 : 9);
	P8rectfill(x + 4, y, x + 6, y + 3, hi);
	altar_px(x + 5, y + 1, 0); altar_px(x + 4, y + 2, 0); altar_px(x + 6, y + 2, 0);   // the arrow
}

static void altar_draw_prompt(OBJ* flag, OBJ* player) {
	const char* txt = lang_pt ? "segure" : "hold";
	const int tw = (int)strlen(txt) * 4 - 1, iw = 12, gap = 5;
	const int total = tw + gap + iw;
	const int px = 64 - total / 2 - 8, pw = total + 16;
	const int py = 36;
	const bool pressed = altar_hold > 0;
	const float f = (float)altar_hold / ALTAR_HOLD;

	P8rectfill(px + 1, py + 1, px + pw, py + 29, 1);                 // drop shadow
	P8rectfill(px, py, px + pw - 1, py + 27, 0);
	const int bc = pressed ? (frames % 6 < 3 ? 7 : 12) : 5;
	P8rectfill(px, py, px + pw - 1, py, bc); P8rectfill(px, py + 27, px + pw - 1, py + 27, bc);
	P8rectfill(px, py, px, py + 27, bc);     P8rectfill(px + pw - 1, py, px + pw - 1, py + 27, bc);

	const int bob = pressed ? 0 : ((frames / 8) % 2);               // the icon calls attention while idle
	P8print(txt, px + 8, py + 6, 7);
	altar_dpad_up(px + 8 + tw + gap, py + 3 - bob, pressed);

	const int bx = px + 8, bw = pw - 16, by = py + 19;               // charge bar
	P8rectfill(bx, by, bx + bw - 1, by + 3, 5);
	P8rectfill(bx + 1, by + 1, bx + bw - 2, by + 2, 1);
	const int fw = (int)((float)(bw - 2) * f);
	if (fw > 0) {
		P8rectfill(bx + 1, by + 1, bx + fw, by + 2, f > 0.66f ? 7 : (f > 0.33f ? 12 : 13));
		P8rectfill(bx + 1, by + 1, bx + fw, by + 1, 7);
	}

	// sparks rising from the altar while charging
	if (altar_hold > 0) {
		const int n = 2 + altar_hold * 8 / ALTAR_HOLD;
		const float cx = flag->x + 4, fy = flag->y + 6;
		for (int i = 0; i < n; i++) {
			const float ph = (float)((frames * 2 + i * 11) % 30) / 30.0f;
			const float sx = cx + P8sin(ph * 0.6f + (float)i * 0.37f) * (4 + (i % 3) * 3);
			const float sy = fy - ph * (14 + f * 22);
			altar_px((int)sx, (int)sy, ph > 0.7f ? 12 : (i % 2 ? 7 : 10));
		}
	}
	(void)player;
}

static void altar_draw_ascension(OBJ* player) {
	const float t = 1.0f - (float)altar_anim / ALTAR_ANIM;
	const int x0 = -wide_pad - 8, x1 = 136 + wide_pad;
	const int cx = (int)(altar_x0 + 4), cy = (int)(player->y + 4), fy = (int)(altar_y0 + 8);

	// the pillar of light: columns that skip the player, so Madeline stays visible inside it
	if (t < 0.88f) {
		const float g = altar_ease(t / 0.45f);
		const int hw = 2 + (int)(11.0f * g);
		for (int xx = cx - hw; xx <= cx + hw; xx += 2) {
			const int d = xx > cx ? xx - cx : cx - xx;
			int col = (d > hw - 3) ? 12 : (((xx + frames) % 4 < 2) ? 7 : 6);
			if (d > hw - 1) col = 13;
			const int ybot = d <= 4 ? cy - 10 : fy;
			if (ybot > 0) P8rectfill(xx, 0, xx, ybot, col);
		}
	}

	// sparkles spiral around Madeline and close in on her
	for (int i = 0; i < 12; i++) {
		const float a = t * 2.2f + (float)i / 12.0f;
		const float r = 20.0f * (1.0f - 0.65f * altar_ease(t)) + (float)(i % 3) * 2;
		const int sx = cx + (int)(-P8cos(a) * r);
		const int sy = cy - 2 + (int)(P8sin(a) * r * 0.55f) - (int)((float)i * 0.8f * t * 4);
		const int c = (i % 3 == 0) ? 7 : ((i % 3 == 1) ? 10 : 12);
		P8rectfill(sx, sy, sx + (i % 4 == 0 ? 1 : 0), sy + (i % 4 == 0 ? 1 : 0), c);
	}

	// expanding rings
	for (int k = 0; k < 3; k++) {
		const float u = t - 0.38f - 0.07f * (float)k;
		if (u <= 0 || u > 0.5f) continue;
		const float rr = u * 190.0f;
		const int c = k == 0 ? 7 : (k == 1 ? 12 : 13);
		for (int j = 0; j < 40; j++) {
			const float a = (float)j / 40.0f;
			altar_px(cx + (int)(P8cos(a) * rr), cy + (int)(P8sin(a) * rr * 0.8f), c);
		}
	}

	// white flash, then it fades to black (chapter 2 fades in from black)
	if (t > 0.8f) {
		static const unsigned char fade[10] = { 7, 7, 7, 7, 6, 6, 13, 5, 1, 0 };
		const float u = (t - 0.8f) / 0.2f;
		int idx = (int)(u * 10.0f);
		if (idx > 9) idx = 9;
		P8rectfill(x0, -8, x1, 136, fade[idx]);
	}
}

static void altar_draw(void) {
	if (c2_active || tut_active || level_index() != 30) return;
	OBJ* flag = altar_find(OBJ_FLAG);
	OBJ* player = altar_find(OBJ_PLAYER);
	if (!flag || !player) return;
	if (altar_anim > 0) { altar_draw_ascension(player); return; }
	if (altar_ready(flag, player)) altar_draw_prompt(flag, player);
}

int Celeste_P8_altar_busy(void) { return altar_anim > 0 ? 1 : 0; }
