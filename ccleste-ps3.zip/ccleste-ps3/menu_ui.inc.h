// Text (baked Roboto, with Portuguese accents) and the dark rounded buttons of the title menu.
// SDL free, like menu_scene.inc.h: it works on the same 32-bit 0x00RRGGBB buffer (456x256 in HD).
//   int  mui_font_load(const char* path);                  // data/menu_font.bin (tools/gen_menu_font.py) ; 0 = ok
//   int  mui_text_width(const char* utf8);
//   void mui_text(px, pitch, W, H, x, baseline_y, utf8, rgb, alpha256);
//   void mui_main_buttons(px, pitch, W, H, labels, n, sel_amount[], t, &first_y);   // the 5 (or 4) entries of the title menu
#ifndef MENU_UI_INC_H_
#define MENU_UI_INC_H_

#include "menu_scene.inc.h"

#define MUI_BTN_W 108
#define MUI_BTN_H 19
#define MUI_BTN_PITCH 21
#define MUI_BTN_Y0 119          // top of the first button when there are 5 entries
#define MUI_BTN_X ((MS_W - MUI_BTN_W) / 2)

typedef struct { uint16_t cp; uint8_t w, h; int8_t xo, yo; uint8_t adv; const uint8_t* a; } mui_glyph_t;
static mui_glyph_t* mui_glyphs = NULL;
static int mui_nglyph = 0, mui_line = 17, mui_asc = 13;
static int16_t mui_idx[256];
static uint8_t* mui_fontbuf = NULL;

static int mui_font_load(const char* path) {
	FILE* f = fopen(path, "rb");
	if (!f) return -1;
	fseek(f, 0, SEEK_END); long len = ftell(f); fseek(f, 0, SEEK_SET);
	if (len < 8) { fclose(f); return -2; }
	uint8_t* b = (uint8_t*)malloc((size_t)len);
	if (!b || fread(b, 1, (size_t)len, f) != (size_t)len) { fclose(f); free(b); return -3; }
	fclose(f);
	if (memcmp(b, "MFN1", 4) != 0) { free(b); return -4; }
	mui_line = b[4]; mui_asc = b[5];
	const int n = b[6] | (b[7] << 8);
	mui_glyph_t* g = (mui_glyph_t*)malloc(sizeof(mui_glyph_t) * n);
	if (!g || 8 + 12 * n > len) { free(b); free(g); return -5; }
	for (int i = 0; i < n; i++) {
		const uint8_t* e = b + 8 + 12 * i;
		g[i].cp = (uint16_t)(e[0] | (e[1] << 8)); g[i].w = e[2]; g[i].h = e[3];
		g[i].xo = (int8_t)e[4]; g[i].yo = (int8_t)e[5]; g[i].adv = e[6];
		const uint32_t off = e[8] | (e[9] << 8) | (e[10] << 16) | ((uint32_t)e[11] << 24);
		g[i].a = (off + (uint32_t)g[i].w * g[i].h <= (uint32_t)len) ? b + off : NULL;
	}
	free(mui_fontbuf); free(mui_glyphs);
	mui_fontbuf = b; mui_glyphs = g; mui_nglyph = n;
	for (int i = 0; i < 256; i++) mui_idx[i] = -1;
	for (int i = 0; i < n; i++) if (g[i].cp < 256) mui_idx[g[i].cp] = (int16_t)i;
	return 0;
}

static const mui_glyph_t* mui_find(unsigned cp) {
	if (!mui_glyphs) return NULL;
	if (cp < 256) { const int i = mui_idx[cp]; if (i >= 0) return &mui_glyphs[i]; }
	else for (int i = 0; i < mui_nglyph; i++) if (mui_glyphs[i].cp == cp) return &mui_glyphs[i];
	return cp == '?' ? NULL : mui_find('?');
}

// next code point of a UTF-8 string
static unsigned mui_next(const char** s) {
	const unsigned char* p = (const unsigned char*)*s;
	unsigned c = *p++;
	if (c >= 0xf0 && p[0] && p[1] && p[2]) { c = ((c & 7) << 18) | ((p[0] & 63) << 12) | ((p[1] & 63) << 6) | (p[2] & 63); p += 3; }
	else if (c >= 0xe0 && p[0] && p[1]) { c = ((c & 15) << 12) | ((p[0] & 63) << 6) | (p[1] & 63); p += 2; }
	else if (c >= 0xc0 && p[0]) { c = ((c & 31) << 6) | (p[0] & 63); p += 1; }
	*s = (const char*)p;
	return c;
}

static int mui_text_width(const char* s) {
	int w = 0;
	while (*s) { const mui_glyph_t* g = mui_find(mui_next(&s)); if (g) w += g->adv; }
	return w;
}

static void mui_text(uint32_t* px, int pitch, int W, int H, int x, int base, const char* s, uint32_t rgb, int alpha) {
	while (*s) {
		const mui_glyph_t* g = mui_find(mui_next(&s));
		if (!g) continue;
		if (g->a) for (int yy = 0; yy < g->h; yy++) {
			const int Y = base + g->yo + yy; if ((unsigned)Y >= (unsigned)H) continue;
			for (int xx = 0; xx < g->w; xx++) {
				const int a = g->a[yy * g->w + xx]; if (!a) continue;
				const int X = x + g->xo + xx; if ((unsigned)X >= (unsigned)W) continue;
				uint32_t* p = px + (size_t)Y * pitch + X;
				*p = ms_mix(*p, rgb, (a * alpha) >> 8);
			}
		}
		x += g->adv;
	}
}

static inline int mui_rr_inside(int x, int y, int w, int h, int r) {
	if (x < 0 || y < 0 || x >= w || y >= h) return 0;
	const int dx = x < r ? r - 1 - x : x >= w - r ? x - (w - r) : -1;
	const int dy = y < r ? r - 1 - y : y >= h - r ? y - (h - r) : -1;
	if (dx < 0 || dy < 0) return 1;
	return dx * dx + dy * dy <= (r - 1) * (r - 1) + 2;
}

// the button shape is computed once: 0 outside, 1 border, 2 fill; plus the three outline rings of the halo (value k = ring)
#define MUI_HALO 3
#define MUI_HW (MUI_BTN_W + 2 * MUI_HALO)
#define MUI_HH (MUI_BTN_H + 2 * MUI_HALO)
static uint8_t mui_shape[MUI_BTN_H][MUI_BTN_W];
static uint8_t mui_halo[MUI_HH][MUI_HW];
static int mui_shape_ready = 0;
static void mui_shape_build(void) {
	const int r = 4;
	for (int y = 0; y < MUI_BTN_H; y++) for (int x = 0; x < MUI_BTN_W; x++) {
		const int in = mui_rr_inside(x, y, MUI_BTN_W, MUI_BTN_H, r);
		const int edge = in && (!mui_rr_inside(x - 1, y, MUI_BTN_W, MUI_BTN_H, r) || !mui_rr_inside(x + 1, y, MUI_BTN_W, MUI_BTN_H, r) ||
		                        !mui_rr_inside(x, y - 1, MUI_BTN_W, MUI_BTN_H, r) || !mui_rr_inside(x, y + 1, MUI_BTN_W, MUI_BTN_H, r));
		mui_shape[y][x] = in ? (edge ? 1 : 2) : 0;
	}
	memset(mui_halo, 0, sizeof mui_halo);
	for (int k = MUI_HALO; k >= 1; k--) {                       // ring k = outline of the rounded rect grown by k px
		const int w = MUI_BTN_W + 2 * k, h = MUI_BTN_H + 2 * k, ox = MUI_HALO - k, oy = MUI_HALO - k;
		for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
			const int in = mui_rr_inside(x, y, w, h, r + k);
			const int edge = in && (!mui_rr_inside(x - 1, y, w, h, r + k) || !mui_rr_inside(x + 1, y, w, h, r + k) ||
			                        !mui_rr_inside(x, y - 1, w, h, r + k) || !mui_rr_inside(x, y + 1, w, h, r + k));
			if (edge) mui_halo[oy + y][ox + x] = (uint8_t)k;
		}
	}
	mui_shape_ready = 1;
}

// one button. sel = 0..256 (how selected it is), appear = 0..256 (fade-in)
static void mui_button(uint32_t* px, int pitch, int W, int H, int x, int y, const char* label, int sel, int appear, float t) {
	if (appear <= 0) return;
	if (!mui_shape_ready) mui_shape_build();
	const uint32_t fill = ms_mix(0x0c0a26, 0x3a1a42, sel), border = ms_mix(0x5a4484, 0xf0c896, sel);
	const int fa = (200 + (sel >> 3)) * appear >> 8, ba = (200 + (sel >> 2)) * appear >> 8;
	if (sel > 8) {                                              // soft halo around the selected one
		const int pulse = 18 + (int)(7.0f * sinf(t * 3.2f));
		int ha[MUI_HALO + 1];
		for (int k = 1; k <= MUI_HALO; k++) ha[k] = (pulse * sel >> 8) * appear / 256 / (k + 1);
		for (int yy = 0; yy < MUI_HH; yy++) {
			const int Y = y - MUI_HALO + yy; if ((unsigned)Y >= (unsigned)H) continue;
			for (int xx = 0; xx < MUI_HW; xx++) {
				const int k = mui_halo[yy][xx]; if (!k) continue;
				const int X = x - MUI_HALO + xx; if ((unsigned)X >= (unsigned)W) continue;
				uint32_t* p = px + (size_t)Y * pitch + X; *p = ms_mix(*p, 0xff6ab8, ha[k]);
			}
		}
	}
	for (int yy = 0; yy < MUI_BTN_H; yy++) {
		const int Y = y + yy; if ((unsigned)Y >= (unsigned)H) continue;
		uint32_t* row = px + (size_t)Y * pitch;
		for (int xx = 0; xx < MUI_BTN_W; xx++) {
			const int m = mui_shape[yy][xx]; if (!m) continue;
			const int X = x + xx; if ((unsigned)X >= (unsigned)W) continue;
			row[X] = m == 1 ? ms_mix(row[X], border, ba) : ms_mix(row[X], fill, fa);
		}
	}
	const int tw = mui_text_width(label);
	const int tx = x + (MUI_BTN_W - tw) / 2, base = y + MUI_BTN_H / 2 + 5;
	const uint32_t col = ms_mix(0xd6cee2, 0xfff6ec, sel);
	mui_text(px, pitch, W, H, tx, base + 1, label, 0x000000, 150 * appear >> 8);
	mui_text(px, pitch, W, H, tx, base, label, col, appear);
}

// the entries of the title menu, centered on the same middle line whether there are 4 or 5
static int mui_main_y(int n, int i) { return MUI_BTN_Y0 + (5 - n) * MUI_BTN_PITCH / 2 + i * MUI_BTN_PITCH; }
static void mui_main_buttons(uint32_t* px, int pitch, int W, int H, const char* const* labels, int n, const int* sel, float t) {
	for (int i = 0; i < n; i++) {
		float u = (t - (0.85f + 0.09f * i)) / 0.35f; u = u < 0 ? 0 : u > 1 ? 1 : u;
		const float e = 1 - (1 - u) * (1 - u);
		mui_button(px, pitch, W, H, MUI_BTN_X, mui_main_y(n, i) + (int)((1 - e) * 7), labels[i], sel[i], (int)(e * 256), t);
	}
}

#endif
