// osk.inc.c - the native PS3 on-screen keyboard (sysutil OSK), used to type the online co-op code.
// Included by sdl12main.c before menu.inc.c. Everything that touches the PSL1GHT OSK API is in this file.
//
//   int  osk_open(title, initial)   starts the keyboard; 0 = opened, -1 = not available (use the pad fallback)
//   int  osk_poll(out, size)        0 = still open, 1 = text typed (copied to out), 2 = cancelled, -1 = not open
//   int  osk_busy(void)             1 while the keyboard is on screen
//
// The keyboard is drawn by the system over our frame buffers; the game keeps flipping frames and
// calling sysUtilCheckCallback() (ps3v_poll) as usual, which delivers the OSK events to osk_cb().
// If your PSL1GHT headers use other names and this file does not compile, build with -DNO_PS3_OSK:
// the code screen then falls back to the old letter picker.
#ifndef CCLESTE_OSK_INC_C
#define CCLESTE_OSK_INC_C

#include <stdint.h>
#include <string.h>

#if defined(PLATFORM_PS3) && !defined(NO_PS3_OSK)

#include <sysutil/sysutil.h>
#include <sysutil/osk.h>
#include <sys/memory.h>

// event ids (same values as the Cell SDK; older headers may lack the names)
#ifndef SYSUTIL_OSK_LOADED
#define SYSUTIL_OSK_LOADED          0x0502
#endif
#ifndef SYSUTIL_OSK_FINISHED
#define SYSUTIL_OSK_FINISHED        0x0503
#endif
#ifndef SYSUTIL_OSK_UNLOADED
#define SYSUTIL_OSK_UNLOADED        0x0504
#endif
// panel / prohibit flags (Cell SDK values)
#ifdef OSK_PANEL_TYPE_ALPHABET
#define OSKX_PANEL_ALPHA OSK_PANEL_TYPE_ALPHABET
#else
#define OSKX_PANEL_ALPHA 0x01000000
#endif
#ifdef OSK_PANEL_TYPE_NUMERAL
#define OSKX_PANEL_NUM OSK_PANEL_TYPE_NUMERAL
#else
#define OSKX_PANEL_NUM 0x08000000
#endif
#ifdef OSK_PROHIBIT_RETURN
#define OSKX_NO_RETURN OSK_PROHIBIT_RETURN
#else
#define OSKX_NO_RETURN 0x00000002
#endif

#define OSK_CONT_SIZE  (4 * 1024 * 1024)
#define OSK_MAXLEN     24
#define OSK_SLOT       1              // sysutil callback slot (slot 0 is used by ps3video.c)

enum { OSK_IDLE, OSK_OPEN, OSK_GOT_TEXT, OSK_GOT_CANCEL };
static int osk_st = OSK_IDLE;
static int osk_cb_registered = 0, osk_cont_ok = 0;
static int osk_finished = 0, osk_wait = 0;
static sys_mem_container_t osk_cont;
static uint16_t osk_msg[64], osk_start[16], osk_buf[OSK_MAXLEN + 8];
static oskInputFieldInfo osk_field;
static oskParam osk_param;
static oskCallbackReturnParam osk_ret;

static void osk_free_cont(void) {
	if (osk_cont_ok) { sysMemContainerDestroy(osk_cont); osk_cont_ok = 0; }
}

// the dialog is gone: look at what the user did
static void osk_finish(void) {
	osk_free_cont();
	osk_finished = 0;
	osk_st = (osk_ret.res == 0 && osk_ret.len > 0 && osk_buf[0]) ? OSK_GOT_TEXT : OSK_GOT_CANCEL;
}

static void osk_cb(u64 status, u64 param, void* usrdata) {
	(void)param; (void)usrdata;
	switch (status) {
		case SYSUTIL_OSK_FINISHED:            // closed with Enter/Start or cancelled: collect the result
			osk_finished = 1; osk_wait = 0;
			oskUnloadAsync(&osk_ret);
			break;
		case SYSUTIL_OSK_UNLOADED:
			if (osk_st == OSK_OPEN) osk_finish();
			break;
		default: break;
	}
}

static void osk_to_u16(uint16_t* dst, const char* src, int max) {
	int i = 0;
	for (; src && src[i] && i < max - 1; i++) dst[i] = (uint8_t)src[i];
	dst[i] = 0;
}

static int osk_open(const char* title, const char* initial) {
	if (osk_st == OSK_OPEN) return 0;
	if (!osk_cb_registered) { sysUtilRegisterCallback(OSK_SLOT, osk_cb, NULL); osk_cb_registered = 1; }
	osk_free_cont();
	if (sysMemContainerCreate(&osk_cont, OSK_CONT_SIZE) != 0) return -1;
	osk_cont_ok = 1;

	osk_to_u16(osk_msg, title, 64);
	osk_to_u16(osk_start, initial, 16);
	memset(osk_buf, 0, sizeof osk_buf);

	osk_field.message = osk_msg;
	osk_field.startText = osk_start;
	osk_field.maxLength = OSK_MAXLEN;

	memset(&osk_param, 0, sizeof osk_param);
	// first field of the param = the allowed panels. Its name differs between SDK versions
	// (allowOskFlags / allowedPanels / ...), so it is written by position: the layout is the firmware's.
	{
		const uint32_t allowed = OSKX_PANEL_ALPHA | OSKX_PANEL_NUM;
		memcpy(&osk_param, &allowed, sizeof allowed);
	}
	osk_param.firstViewPanel = OSKX_PANEL_ALPHA;
	osk_param.controlPoint.x = 0.0f;
	osk_param.controlPoint.y = 0.0f;
	osk_param.prohibitFlags = OSKX_NO_RETURN;

	osk_ret.res = 0;
	osk_ret.len = OSK_MAXLEN;
	osk_ret.str = osk_buf;

	osk_finished = 0; osk_wait = 0;
	if (oskLoadAsync(osk_cont, &osk_param, &osk_field) != 0) { osk_free_cont(); return -1; }
	osk_st = OSK_OPEN;
	return 0;
}

static int osk_busy(void) { return osk_st == OSK_OPEN; }

static int osk_poll(char* out, int size) {
	if (osk_st == OSK_OPEN) {
		// FINISHED arrived but UNLOADED never did: do not wait forever
		if (osk_finished && ++osk_wait > 180) osk_finish();
		if (osk_st == OSK_OPEN) return 0;
	}
	if (osk_st == OSK_GOT_TEXT) {
		int n = 0;
		for (int i = 0; osk_buf[i] && i < OSK_MAXLEN && n < size - 1; i++) out[n++] = osk_buf[i] < 128 ? (char)osk_buf[i] : '?';
		out[n] = 0;
		osk_st = OSK_IDLE;
		return 1;
	}
	if (osk_st == OSK_GOT_CANCEL) { osk_st = OSK_IDLE; if (size > 0) out[0] = 0; return 2; }
	return -1;
}

#else   // no native keyboard here (PC build, or -DNO_PS3_OSK): the caller uses the pad fallback

static int osk_open(const char* title, const char* initial) { (void)title; (void)initial; return -1; }
static int osk_busy(void) { return 0; }
static int osk_poll(char* out, int size) { (void)out; (void)size; return -1; }

#endif
#endif // CCLESTE_OSK_INC_C
