# ccleste

![screenshot](https://raw.githubusercontent.com/lemon-sherbet/ccleste/master/screenshot.png)

This is a C source port of the [original celeste (Celeste classic)](https://www.lexaloffle.com/bbs/?tid=2145) for the PICO-8, designed to be portable. PC and 3DS are the main supported platforms, though other people are [maintaining ports to other platforms](https://github.com/lemon32767/ccleste/network/members).

Go to [the releases tab](https://github.com/lemon-sherbet/ccleste/releases) for the latest pre-built binaries.

An experimental web port is also available [here](https://lemon32767.github.io/ccleste.html).

celeste.c + celeste.h is where the game code is, translated from the pico 8 lua code by hand.
These files don't depend on anything other than the c standard library and don't perform any allocations (it uses its own internal global state).

sdl12main.c provides a "frontend" written in SDL (plus SDL mixer) which implements graphics and audio output. It can be compiled on unix-like platforms by running
```
make
```
By default, SDL2 will be used. Read the Makefile for more information.

3DS is also a supported platform. Compile to 3DS with:
```
make -f Makefile.3ds    # this will generate ccleste.3dsx
```
You will need devkitPro with these dkp packages installed:
```
3ds-sdl
3ds-sdl_mixer
libctru
devkitARM
```

# Controls

|PC                |3DS                |Action              |
|:----------------:|:-----------------:|-------------------:|
|LEFT              |LEFT               | Move left          |
|RIGHT             |RIGHT              | Move right         |
|DOWN              |DOWN               | Look down          |
|UP                |UP                 | Look up            |
|Z/C               |A                  | Jump               |
|X/V               |B/X                | Dash               |
|ESCAPE            |START              | Pause              |
|E                 |L+R                | Toggle screenshake |
|LEFT/RIGHT CTRL   |L / R (hold)       | Grab the wall      |
|SHIFT+D           |Y+L                | Load state         |
|SHIFT+S           |Y+R                | Save state         |
|Hold F9           |Hold SELECT+START+Y| Reset              |
|F11               |SELECT             | Fullscreen         |

Controller input is also supported on PC (SDL2 ver) and web version. The controller must be plugged in when opening the game.
The default mappings are: jump with A and dash with B (xbox360 controller layout), move with d-pad or the left stick, pause with start, save/load state with left/right shoulder, exit with guide (logo button).
You can change these mappings by modifying the `ccleste-input-cfg.txt` file that will be created when you first run the game.

You can make the game start up in fullscreen by setting the environment variable `CCLESTE_START_FULLSCREEN` to "1", or by creating the file `ccleste-start-fullscreen.txt` in the game directory (contents don't matter).

# TAS playback and the fixed point question

In order to playback a TAS, specify it as the first argument to the program when running it. On Windows you can drag the TAS file to the .exe to do this.
The format for the TAS should be a text file that looks like "0,0,3,5,1,34,0,", where each number is the input bitfield and each frame is ended by a comma.
The inputs in the TAS should start in the first loading frame of 100m (neglecting the title screen). When playing back a TAS the starting RNG seed will always be the same.

Most other Celeste Classic ports use floating point numbers, but PICO-8 actually uses 16.16 fixed point numbers.
For casual play and RTA speedrunning, the discrepancies are minor enough to be essentially negligible, however with TASing it might make a difference.
Defining the preprocessor macro `CELESTE_P8_FIXEDP` when compiling celeste.c will use a bunch of preprocessor hacks to replace the float type for all the
code of that file with a fixed point type that matches that of PICO-8. The use of this preprocessor macro requires compiling celeste.c with a C++ compiler, however (but not linking with the C++ standard library).

Using make you can compile this fixed point version with `make USE_FIXEDP=1`.

When playing back TASes made with other tools that work under the assumption of ideal RNG for balloons (since their hitbox depends on that), you can ensure that they do not desync by
defining the preprocessor macro `CELESTE_P8_HACKED_BALLOONS`, which will make balloons static and always expand their hitbox to their full range.

Using make you can turn on this feature with `make HACKED_BALLOONS=1`.

You can combine both of these with `make HACKED_BALLOONS=1 USE_FIXEDP=1`.

# credits

Sound wave files are taken from [https://github.com/JeffRuLz/Celeste-Classic-GBA/tree/master/maxmod_data](https://github.com/JeffRuLz/Celeste-Classic-GBA/tree/master/maxmod_data),
music ogg files were obtained by converting the .wav dumps from pico 8, which I did using audacity & ffmpeg.

All credit for the original game goes to the original developers (Maddy Thorson & Noel Berry).

# Title menu

The game now opens on a menu (Play / Config / Credits) on top of the original title screen.
Up/Down move, jump (X on PS3) confirms, dash (Circle/Square on PS3) goes back.
Config has music volume, sound volume and screenshake; it is saved to `ccleste.cfg` (PS3, next to the EBOOT) or `ccleste-menu.cfg`.
Resetting (hold the reset combo) goes back to the menu. Edit the credits text at the top of `menu.inc.c`.

# PS3 music

On the PS3 the music is played from `data/mus*.wav` (converted from the `.ogg` files) through the
normal sound-effect mixer, on a reserved channel, instead of SDL_mixer's OGG streamer. The OGG
streamer froze the game when a track reached its end/loop point.

# PS3 video, controls and log

The PS3 build does **not** use the SDL video subsystem any more: every earlier log froze inside
`SDL_RenderPresent` after about 256 frames. The frame now goes to the screen through PSL1GHT
directly (`ps3video.c`): two RSX frame buffers, a flip synchronised with the vsync, and the
controller is read with `ioPad`. SDL is only used for software surfaces and for the audio (SDL_mixer).

* The 128x128 game is scaled by the largest whole factor that fits (x5 at 720p, x8 at 1080p) and centered.
  Only the pixels that changed since the last time that buffer was drawn are written to the screen.
  720p looks sharper than 1080p because the factor divides the height better.
* The game logic is still the original 30 ticks per second; the loop runs at the 60 Hz screen refresh.
* If a flip does not finish within about 0.3 s the game goes on instead of freezing (counted as `flip_timeouts`).

| PS3 button            | Action                                  |
|:----------------------|:----------------------------------------|
| D-pad / left stick    | Move, menu navigation                   |
| X                     | Jump, menu confirm                      |
| Square / Circle       | Dash, menu back                         |
| START                 | Pause                                   |
| L1 + L2 / R1 + L2     | Load / save state                       |
| L1 or R1 (hold)       | Grab the wall (stamina, see below)      |
| Hold L2 + START + SELECT | Reset (back to the title menu)       |
| PS button (XMB)       | Quit the game                           |

The log is `ccleste.log` next to the EBOOT.BIN (or `/dev_hdd0/tmp/ccleste.log`). Once per second it gets a line like
`fps=60 game_fps=30 flips=60 flip_timeouts=0`. Build with `make -f Makefile.ps3 DEBUG_LOG=1` for per-frame breadcrumbs.


## PS3 additions

- **Savedata**: progress (room, deaths, time, double-jump upgrade, strawberries) is written as real
  XMB savedata (`CCLE00001-PROGRESS`, visible in *Game > Saved Data Utility*) every time you enter
  a new room or collect a strawberry. The title menu shows **continue** when a save exists
  (and **new game** replaces *play*). Code: `savedata.inc.c`.
- **Language**: config > language switches English / Portuguese (menu and in-game texts). The word
  "portugues" is shown in green. The PICO-8 font has no accents, so none are used.
- **16:9**: this build renders a 228x128 view (VIEW_W in `sdl12main.c`): the room stays in the
  middle and the neighbour rooms' tiles (dimmed) fill both sides. Gameplay is unchanged. It costs
  FPS on the PS3; set VIEW_W to 128 to go back to the square screen.
- **Volume**: music and sound levels use a squared curve and are applied to every sound/track.


# Wall grab (new)

Hold **L1 or R1** (PS3/3DS: L/R, PC: CTRL; player 2 in co-op: L1/R1 or R) next to a wall to grab it, like in the
original Celeste (not on ice). While grabbing: up/down climb, jump = wall jump, dash works as usual.
Stamina refills when you touch the ground. Holding costs little, climbing up costs a lot; when it gets low the
player flashes red, and when it reaches zero the player starts to slip down the wall. The values are the
`GRAB_*` defines at the top of `celeste.c`. Screenshake is toggled in the config menu (L1 + R1 are now the grab).

# Customize (new)

Title screen -> **Contents** (conteudos) -> **Customize** (customizar). Pick the character with left/right on the
first row (solo, coop 1, coop 2), then change each row with left/right (or X):

| Row        | Options |
|:-----------|:--------|
| Hair       | original, or red / blue / green / yellow / purple / pink / orange / white / grey (the "spent dash" color is picked automatically) |
| Outfit     | original green, or any of the colors above |
| Skin       | default, pale, rosy, golden, tan |
| Hat        | none, beanie, crown, top hat, cat ears, party hat, wizard hat, flower (+ a color row) |
| Scarf      | none or any color (the tails fly behind when you run and go up when you fall) |
| Cape       | none or any color (hangs, flies behind when running, lifts when falling) |
| Extra      | none, shades, blush, freckles |

The preview runs and stands still so you can see how the scarf and cape move, the three characters are shown side
by side, and the solo / co-op cards of the "play" screen show the customized characters. Everything is saved to
`ccleste.cfg` (one line per character after the usual settings line); old cfg files still load.

Code: the look is stored and drawn in `celeste.c` (`style_*` functions, `Celeste_P8_set_style()` in `celeste.h`);
accessories are small pixel bitmaps / rules there, so adding a hat is one line in `style_hats[]`.

# HD graphics (16-bit look, PS3)

The PS3 build now renders at 2x (456x256) with redrawn 16x16 sprites (`data/gfx_hd.bmp`, `data/font_hd.bmp`):
colour ramps with blue shadows and warm highlights, shaded sprites with rim light, round shaded hair, a sky gradient
with stars and parallax mountains, soft clouds, glowing particles, light around the player/strawberries/orbs, and a vignette.
The frame is scaled to fill the whole screen (720p/1080p).

* `make -f Makefile.ps3 CCLESTE_NO_HD=1`-style builds: add `-DCCLESTE_NO_HD` to CFLAGS to get the old 8-bit look.
* `python3 tools/gen_hd_assets.py` regenerates the HD sheets from `data/gfx8.bmp` / `font8.bmp` (the original 8-bit art).
* `python3 tools/hd_preview.py` renders sample rooms to /tmp/hdprev without a PS3 (needs gcc, numpy, Pillow).
* Renderer: `hdgfx.inc.h`; hooks in `celeste.c` use `CELESTE_P8_HD` (ignored by other frontends).
