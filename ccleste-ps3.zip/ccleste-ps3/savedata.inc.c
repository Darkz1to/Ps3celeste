// Savedata (progress) for ccleste.
// Included by sdl12main.c, after celeste.h / OSDset() and before menu.inc.c.
//
// What is stored: Celeste_P8_progress_t = room, deaths, time, double-jump upgrade and
// the strawberries collected, plus (since version 2) the unlocked trophies (bit mask). The game writes it by itself (autosave) whenever the
// player enters a new room or collects a strawberry, and the title menu shows
// "continue" when a valid save exists.
//
// PS3: real XMB savedata (sysSaveAutoSave2 / sysSaveAutoLoad2), directory
// "CCLE00001-PROGRESS", with title/subtitle/details and the game icon, so it shows up in
// Game > Saved Data Utility. The system calls run in their own thread (like the official
// PSL1GHT sample) so the game keeps drawing while the system saves.
// Other platforms: a plain file "ccleste-save.dat" next to the executable.
//
// API used by the rest of the code:
//   savedata_has / savedata_prog   a valid save was found (after savedata_start_load)
//   savedata_start_load()          look for a save (async on PS3)
//   savedata_poll()                call once per frame: finishes async work
//   savedata_request_save(p, lang) write the progress (async on PS3)
//   savedata_try_continue()        put the game in the saved room, 0 = ok

#include <stdlib.h>
#include <stddef.h>

#define SAVEDATA_MAGIC   0x43434C53u   /* 'CCLS' */
#define SAVEDATA_VERSION 2u            /* 1 = progress only, 2 = progress + trophies */
#define TROPHY_MAGIC     0x43435452u   /* 'CCTR' */
#define TROPHY_TOTAL     11            /* 10 trophies + platinum */
#define TROPHY_ALL_MASK  ((1u << TROPHY_TOTAL) - 1u)

typedef struct {
	unsigned magic;
	unsigned mask;         /* bit i = trophy i unlocked */
	unsigned reserved[6];
} savedata_trophy_t;

typedef struct {
	unsigned magic, version, size;
	Celeste_P8_progress_t prog;
	savedata_trophy_t trophy;   /* version 2 and later */
} savedata_file_t;

/* a version 1 file is the same struct without the trophy block */
#define SAVEDATA_V1_SIZE ((unsigned)offsetof(savedata_file_t, trophy))

static int savedata_has = 0;
static Celeste_P8_progress_t savedata_prog;
static unsigned trophy_mask = 0;   // unlocked trophies (loaded from / written to the save)

static int trophy_count(void) {
	int n = 0;
	for (int i = 0; i < TROPHY_TOTAL; i++) n += (trophy_mask >> i) & 1u;
	return n;
}

// n = number of bytes that were read from the file
static int savedata_validate(const savedata_file_t* f, unsigned n) {
	if (f->magic != SAVEDATA_MAGIC) return 0;
	if (f->version == 1u) return n == SAVEDATA_V1_SIZE && f->size == SAVEDATA_V1_SIZE;
	if (f->version == SAVEDATA_VERSION)
		return n == sizeof *f && f->size == sizeof *f && f->trophy.magic == TROPHY_MAGIC;
	return 0;
}

static void savedata_fill(savedata_file_t* f, const Celeste_P8_progress_t* p) {
	memset(f, 0, sizeof *f);
	f->magic = SAVEDATA_MAGIC; f->version = SAVEDATA_VERSION; f->size = sizeof *f;
	f->prog = *p;
	f->trophy.magic = TROPHY_MAGIC;
	f->trophy.mask = trophy_mask & TROPHY_ALL_MASK;
}

// a save was read: merge its trophies (never lose what was unlocked in the meantime)
static void savedata_apply_trophies(const savedata_file_t* f) {
	if (f->version >= 2u) trophy_mask |= f->trophy.mask & TROPHY_ALL_MASK;
}

static int savedata_berries(const Celeste_P8_progress_t* p) {
	int n = 0;
	for (int i = 0; i < CELESTE_P8_FRUITS; i++) n += p->got_fruit[i] != 0;
	return n;
}

static int savedata_try_continue(void) {
	if (!savedata_has) return -1;
	if (Celeste_P8_load_progress(&savedata_prog) != 0) { savedata_has = 0; return -1; }
	return 0;
}

#if defined(PLATFORM_PS3)
// ======================================================================= PS3
#include <sys/thread.h>
#include <sys/memory.h>
#include <sysutil/save.h>

#define SV_DIRNAME  "CCLE00001-PROGRESS"   // upper case, starts with the title id
#define SV_FILENAME "CCLESTE.DAT"          // max 12 chars
#define SV_STACK    (32*1024)
#define SV_MEMCONT  (5*1024*1024)

static struct {
	volatile int running;      // the thread is alive
	volatile int done;         // finished, result not consumed yet
	volatile int ok;           // the operation succeeded
	int op;                    // 1 = save, 2 = load
	int stage;                 // file callback step
	int file_ok;               // the file callback reached its end without errors
	unsigned fsize;
	int lang;
	savedata_file_t file;
	unsigned char* icon; unsigned icon_size;
	char title[SYS_SAVE_MAX_TITLE], subtitle[SYS_SAVE_MAX_SUBTITLE], detail[SYS_SAVE_MAX_DETAIL];
	sys_ppu_thread_t tid;
	int pending; Celeste_P8_progress_t pending_prog; int pending_lang;
} sv;

static void sv_status_cb(sysSaveCallbackResult* r, sysSaveStatusIn* in, sysSaveStatusOut* out) {
	r->result = SYS_SAVE_CALLBACK_RESULT_CONTINUE;
	out->setParam = &in->getParam;
	sv.stage = 0; sv.file_ok = 0;
	if (sv.op == 2) {
		out->recreateMode = SYS_SAVE_RECREATE_MODE_OVERWRITE_NOT_CORRUPTED; // never delete when loading
		sv.fsize = 0;
		if (!in->isNew) {
			for (u32 i = 0; i < in->numFiles; i++)
				if (in->fileList[i].fileType == SYS_SAVE_FILETYPE_STANDARD_FILE
						&& strcmp(in->fileList[i].filename, SV_FILENAME) == 0)
					sv.fsize = (unsigned)in->fileList[i].fileSize;
		}
		if (sv.fsize != sizeof sv.file && sv.fsize != SAVEDATA_V1_SIZE) r->result = SYS_SAVE_CALLBACK_RESULT_NOT_FOUND;
	} else {
		out->recreateMode = SYS_SAVE_RECREATE_MODE_DELETE; // rewrite everything
		if ((in->freeSpaceKB + in->sizeKB) < (256 + in->systemSizeKB)) {
			r->result = SYS_SAVE_CALLBACK_RESULT_NO_SPACE_LEFT;
			r->missingSpaceKB = (256 + in->systemSizeKB) - (in->freeSpaceKB + in->sizeKB);
			return;
		}
		strncpy(in->getParam.title, sv.title, SYS_SAVE_MAX_TITLE - 1);
		strncpy(in->getParam.subtitle, sv.subtitle, SYS_SAVE_MAX_SUBTITLE - 1);
		strncpy(in->getParam.detail, sv.detail, SYS_SAVE_MAX_DETAIL - 1);
		in->getParam.title[SYS_SAVE_MAX_TITLE - 1] = 0;
		in->getParam.subtitle[SYS_SAVE_MAX_SUBTITLE - 1] = 0;
		in->getParam.detail[SYS_SAVE_MAX_DETAIL - 1] = 0;
	}
}

static void sv_file_cb(sysSaveCallbackResult* r, sysSaveFileIn* in, sysSaveFileOut* out) {
	memset(out, 0, sizeof *out);
	r->result = SYS_SAVE_CALLBACK_RESULT_CONTINUE;
	if (sv.op == 1) {
		if (sv.stage == 0) {
			sv.stage = 1;
			if (sv.icon && sv.icon_size) {
				out->fileOperation = SYS_SAVE_FILE_OPERATION_WRITE;
				out->fileType = SYS_SAVE_FILETYPE_CONTENT_ICON0;
				out->size = out->bufferSize = sv.icon_size;
				out->buffer = sv.icon;
				r->incrementProgress = 20;
				return;
			}
		}
		if (sv.stage == 1) {
			sv.stage = 2;
			out->fileOperation = SYS_SAVE_FILE_OPERATION_WRITE;
			out->fileType = SYS_SAVE_FILETYPE_STANDARD_FILE;
			out->filename = (char*)SV_FILENAME;
			out->size = out->bufferSize = sizeof sv.file;
			out->buffer = &sv.file;
			r->incrementProgress = 100;
			return;
		}
		r->result = SYS_SAVE_CALLBACK_RESULT_DONE;
		sv.file_ok = 1;
	} else {
		if (sv.stage == 0) {
			sv.stage = 1;
			out->fileOperation = SYS_SAVE_FILE_OPERATION_READ;
			out->fileType = SYS_SAVE_FILETYPE_STANDARD_FILE;
			out->filename = (char*)SV_FILENAME;
			out->size = sv.fsize;                 // the real size of the file (v1 or v2)
			out->bufferSize = sizeof sv.file;
			out->buffer = &sv.file;
			r->incrementProgress = 100;
			return;
		}
		if (in->previousOperationResultSize == sv.fsize) {
			r->result = SYS_SAVE_CALLBACK_RESULT_DONE;
			sv.file_ok = 1;
		} else {
			r->result = SYS_SAVE_CALLBACK_RESULT_CORRUPTED;
		}
	}
}

static void sv_thread(void* arg) {
	(void)arg;
	sysSaveBufferSettings bs;
	sys_mem_container_t cont;
	s32 ret = -1;
	memset(&bs, 0, sizeof bs);
	bs.maxDirectories = 1;
	bs.maxFiles = 3; // icon + data (+ spare)
	bs.bufferSize = 3 * sizeof(sysSaveFileStatus);
	if (bs.bufferSize < sizeof(sysSaveDirectoryList)) bs.bufferSize = sizeof(sysSaveDirectoryList);
	bs.buffer = malloc(bs.bufferSize);
	if (bs.buffer && sysMemContainerCreate(&cont, SV_MEMCONT) == 0) {
		if (sv.op == 1)
			ret = sysSaveAutoSave2(SYS_SAVE_CURRENT_VERSION, SV_DIRNAME, SYS_SAVE_ERROR_DIALOG_SHOW,
					&bs, sv_status_cb, sv_file_cb, cont, NULL);
		else
			ret = sysSaveAutoLoad2(SYS_SAVE_CURRENT_VERSION, SV_DIRNAME, SYS_SAVE_ERROR_DIALOG_NONE,
					&bs, sv_status_cb, sv_file_cb, cont, NULL);
		sysMemContainerDestroy(cont);
	}
	free(bs.buffer);
	sv.ok = (ret == SYS_SAVE_RETURN_DONE && sv.file_ok);
	__sync_synchronize(); // the results above must be visible before the flag
	sv.done = 1;
	sv.running = 0;
	sysThreadExit(0);
}

// the 320x176 ICON0.PNG of the game is in the game folder, one level above USRDIR
static void sv_load_icon(void) {
	if (sv.icon) return;
	char path[700];
	snprintf(path, sizeof path, "%s/../ICON0.PNG", ps3_base_dir);
	FILE* f = fopen(path, "rb");
	if (!f) return;
	unsigned char hdr[24];
	long sz = 0;
	if (fread(hdr, 1, 24, f) == 24) {
		unsigned w = (hdr[16]<<24)|(hdr[17]<<16)|(hdr[18]<<8)|hdr[19];
		unsigned h = (hdr[20]<<24)|(hdr[21]<<16)|(hdr[22]<<8)|hdr[23];
		fseek(f, 0, SEEK_END); sz = ftell(f); fseek(f, 0, SEEK_SET);
		if (w == 320 && h == 176 && sz > 0 && sz < 1024*1024) { // the system rejects other sizes
			sv.icon = (unsigned char*)malloc((size_t)sz);
			if (sv.icon && fread(sv.icon, 1, (size_t)sz, f) == (size_t)sz) sv.icon_size = (unsigned)sz;
			else { free(sv.icon); sv.icon = NULL; sv.icon_size = 0; }
		}
	}
	fclose(f);
}

static int sv_launch(int op) {
	sv.op = op; sv.running = 1; sv.done = 0; sv.ok = 0;
	if (sysThreadCreate(&sv.tid, sv_thread, NULL, 1000, SV_STACK, 0, (char*)"ccleste_save") != 0) {
		sv.running = 0; sv.done = 1; sv.ok = 0;
		return -1;
	}
	return 0;
}

static void sv_describe(const Celeste_P8_progress_t* p, int pt) {
	const int idx = p->room_x + p->room_y*8;
	char lvl[40];
	if (idx == 11) snprintf(lvl, sizeof lvl, "%s", pt ? "Local antigo" : "Old site");
	else if (idx == 30) snprintf(lvl, sizeof lvl, "%s", pt ? "Topo" : "Summit");
	else snprintf(lvl, sizeof lvl, "%d m", (idx + 1) * 100);
	snprintf(sv.title, sizeof sv.title, "Celeste Classic");
	snprintf(sv.subtitle, sizeof sv.subtitle, "%s%s %s",
		(p->coop_tag == 0xC5 && p->coop) ? "Co-op " : "", pt ? "Nivel" : "Level", lvl);
	snprintf(sv.detail, sizeof sv.detail, "%s: %d\n%s: %02d:%02d:%02d\n%s: %d\n%s: %d/%d",
		pt ? "Mortes" : "Deaths", p->deaths,
		pt ? "Tempo" : "Time", p->minutes / 60, p->minutes % 60, p->seconds,
		pt ? "Morangos" : "Strawberries", savedata_berries(p),
		pt ? "Trofeus" : "Trophies", trophy_count(), TROPHY_TOTAL);
}

static void savedata_start_load(void) {
	if (sv.running) return;
	memset(&sv.file, 0, sizeof sv.file);
	sv_launch(2);
}

static void savedata_request_save(const Celeste_P8_progress_t* p, int pt) {
	if (sv.running) { sv.pending = 1; sv.pending_prog = *p; sv.pending_lang = pt; return; }
	sv_load_icon();
	sv_describe(p, pt);
	savedata_fill(&sv.file, p);
	sv.lang = pt;
	sv.pending = 0;
	// what we are writing is what "continue" will load from now on
	savedata_prog = *p; savedata_has = 1;
	sv_launch(1);
}

static void savedata_poll(void) {
	if (sv.done && !sv.running) {
		sv.done = 0;
		if (sv.op == 2) {
			if (sv.ok && savedata_validate(&sv.file, sv.fsize)) {
				savedata_prog = sv.file.prog;
				savedata_apply_trophies(&sv.file);
				savedata_has = 1;
				ps3_log("savedata: found room %d,%d deaths %d\n", savedata_prog.room_x, savedata_prog.room_y, savedata_prog.deaths);
			} else {
				ps3_log("savedata: no valid save found\n");
			}
		} else {
			ps3_log("savedata: save %s\n", sv.ok ? "ok" : "FAILED");
			if (sv.ok) OSDset(sv.lang ? "progresso salvo" : "progress saved");
			else OSDset(sv.lang ? "erro ao salvar" : "save failed");
		}
	}
	if (sv.pending && !sv.running) {
		Celeste_P8_progress_t p = sv.pending_prog;
		savedata_request_save(&p, sv.pending_lang);
	}
}

#elif defined(_3DS) || defined(EMSCRIPTEN)
// ================================================== platforms without a save file
static void savedata_start_load(void) {}
static void savedata_request_save(const Celeste_P8_progress_t* p, int pt) { (void)p; (void)pt; }
static void savedata_poll(void) {}

#else
// ===================================================================== desktop
#define SV_PATH "ccleste-save.dat"

static void savedata_start_load(void) {
	savedata_file_t f;
	memset(&f, 0, sizeof f);
	FILE* fp = fopen(SV_PATH, "rb");
	if (!fp) return;
	const size_t n = fread(&f, 1, sizeof f, fp);   // v1 files are shorter than v2
	if (savedata_validate(&f, (unsigned)n)) {
		savedata_prog = f.prog;
		savedata_apply_trophies(&f);
		savedata_has = 1;
	}
	fclose(fp);
}
static void savedata_request_save(const Celeste_P8_progress_t* p, int pt) {
	savedata_file_t f;
	savedata_fill(&f, p);
	FILE* fp = fopen(SV_PATH, "wb");
	if (!fp) { OSDset(pt ? "erro ao salvar" : "save failed"); return; }
	fwrite(&f, sizeof f, 1, fp);
	fclose(fp);
	savedata_prog = *p; savedata_has = 1;
	OSDset(pt ? "progresso salvo" : "progress saved");
}
static void savedata_poll(void) {}
#endif
