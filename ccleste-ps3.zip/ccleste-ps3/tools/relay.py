#!/usr/bin/env python3
"""ccleste online co-op relay (protocol v2).

    python relay.py                       # LAN only: the code holds the phone's Wi-Fi IP
    python relay.py --bore                # starts a bore tunnel itself and puts its public address in the code
    python relay.py --public HOST:PORT    # you already have a tunnel (playit.gg, router port forward...)
    python relay.py 9000 --bore           # other local port (default 7777)

How it works
  * The HOST console connects (mode 'H'). The relay creates a room and sends back a 16-character CODE
    with the public address of this relay + the room. The code is also printed here (and shown with
    termux-toast / termux-notification when available).
  * The GUEST console types the code, decodes it into address + room and connects (mode 'J').
  * The relay pairs both (role 0 = host = player 1, role 1 = guest = player 2, same random seed) and
    forwards bytes untouched. A room works once.

The code is an encoding with a checksum, not strong encryption: treat it like a password.

Client -> relay (8 bytes): b"CLN2" + mode (b"H" or b"J") + room (3 bytes, only for J)
Relay -> client (8-byte frames):
    b"K", part (0..2), 6 chars   the code, 16 chars over 3 frames (host only)
    b"X", ...                    join refused: unknown room
    b"P", role, seed (u32 le), 2 pad bytes    pair complete, the game can start
"""
import argparse
import asyncio
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import time

ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
rooms = {}            # room bytes -> (reader, writer)
PUBLIC = {"ip": None, "port": None}


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


# ------------------------------------------------------------------ code (same as net.inc.c)
def _check(p):
    c = 0x5A
    for b in p:
        c = (((c << 1) | (c >> 7)) & 0xFF) ^ b
    return (c * 167 + 13) & 0xFF


def _stream(chk, n):
    s = (((chk << 8) | 0x9D) + 0x1F123BB5) & 0xFFFFFFFF
    out = []
    for _ in range(n):
        s ^= (s << 13) & 0xFFFFFFFF
        s ^= s >> 17
        s ^= (s << 5) & 0xFFFFFFFF
        out.append(s & 0xFF)
    return out


def encode_code(ip, port, room):
    """ip: dotted string, port: int, room: 3 bytes -> 16 chars (no dashes)"""
    payload = socket.inet_aton(ip) + struct.pack(">H", port) + bytes(room)
    chk = _check(payload)
    scr = bytes(a ^ b for a, b in zip(payload, _stream(chk, 9)))
    v = int.from_bytes(scr + bytes([chk]), "big")
    return "".join(ALPHA[(v >> (75 - 5 * i)) & 31] for i in range(16))


def pretty(code):
    return "-".join(code[i:i + 4] for i in range(0, 16, 4))


def notify(code):
    for cmd in (["termux-toast", f"ccleste code: {pretty(code)}"],
                ["termux-notification", "--title", "ccleste", "--content", f"code: {pretty(code)}"]):
        if shutil.which(cmd[0]):
            try:
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except OSError:
                pass


# ------------------------------------------------------------------ public address
def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def set_public(host, port):
    ip = socket.gethostbyname(host)
    PUBLIC["ip"], PUBLIC["port"] = ip, int(port)
    log(f"public address: {host}:{port} (ip {ip})")


async def start_bore(local_port):
    exe = shutil.which("bore") or os.path.expanduser("~/.cargo/bin/bore")
    if not exe or not os.path.exists(exe):
        sys.exit("bore not found. Install it in Termux: pkg install rust && cargo install bore-cli")
    proc = await asyncio.create_subprocess_exec(
        exe, "local", str(local_port), "--to", "bore.pub",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    ansi = re.compile(rb"\x1b\[[0-9;]*m")
    found = asyncio.get_event_loop().create_future()

    async def reader():
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            line = ansi.sub(b"", line)
            m = re.search(rb"listening at ([A-Za-z0-9.\-]+):(\d+)", line)
            if m and not found.done():
                found.set_result((m.group(1).decode(), int(m.group(2))))
            else:
                log("bore: " + line.decode(errors="replace").strip())

    asyncio.ensure_future(reader())
    try:
        host, port = await asyncio.wait_for(found, timeout=40)
    except asyncio.TimeoutError:
        proc.terminate()
        sys.exit("bore did not report an address in 40 s (no internet?)")
    set_public(host, port)
    return proc


# ------------------------------------------------------------------ relay
def alive(r, w):
    return not w.is_closing() and not r.at_eof()


async def pipe(src, dst):
    try:
        while True:
            data = await src.read(4096)
            if not data:
                break
            dst.write(data)
            await dst.drain()
    except (ConnectionError, OSError, asyncio.CancelledError):
        pass
    finally:
        try:
            dst.close()
        except Exception:
            pass


async def handle(reader, writer):
    peer = writer.get_extra_info("peername")
    sock = writer.get_extra_info("socket")
    if sock is not None:
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        except OSError:
            pass
    try:
        hello = await asyncio.wait_for(reader.readexactly(8), timeout=10)
    except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError):
        writer.close()
        return
    if hello[:4] != b"CLN2" or hello[4:5] not in (b"H", b"J"):
        log(f"{peer}: bad hello, dropped")
        writer.close()
        return

    if hello[4:5] == b"J":                       # ---- guest
        room = hello[5:8]
        other = rooms.pop(room, None)
        if other is None or not alive(*other):
            log(f"{peer}: join refused (unknown room)")
            try:
                writer.write(struct.pack("<BBIH", ord("X"), 0, 0, 0))
                await writer.drain()
            except (ConnectionError, OSError):
                pass
            writer.close()
            return
        r1, w1 = other
        seed = int.from_bytes(os.urandom(4), "little")
        try:
            w1.write(struct.pack("<BBIH", ord("P"), 0, seed, 0))
            writer.write(struct.pack("<BBIH", ord("P"), 1, seed, 0))
            await w1.drain()
            await writer.drain()
        except (ConnectionError, OSError):
            w1.close()
            writer.close()
            return
        log(f"paired {w1.get_extra_info('peername')} (host) + {peer} (guest)")
        t1 = asyncio.ensure_future(pipe(r1, writer))
        t2 = asyncio.ensure_future(pipe(reader, w1))
        await asyncio.wait([t1, t2], return_when=asyncio.FIRST_COMPLETED)
        for t in (t1, t2):
            t.cancel()
        w1.close()
        writer.close()
        log("game closed")
        return

    # ---- host: create a room and hand out the code
    room = os.urandom(3)
    while room in rooms:
        room = os.urandom(3)
    code = encode_code(PUBLIC["ip"], PUBLIC["port"], room)
    try:
        for i in range(3):
            chunk = code[i * 6:i * 6 + 6].encode().ljust(6, b"\0")
            writer.write(b"K" + bytes([i]) + chunk)
        await writer.drain()
    except (ConnectionError, OSError):
        writer.close()
        return
    rooms[room] = (reader, writer)
    log("=" * 44)
    log(f"HOST {peer} created a room. CODE: {pretty(code)}")
    log("=" * 44)
    notify(code)
    try:                                         # the guest's handler does the pairing
        while room in rooms and rooms[room][1] is writer and alive(reader, writer):
            await asyncio.sleep(1)
    finally:
        if room in rooms and rooms[room][1] is writer:
            del rooms[room]
            log(f"host {peer} left before anyone joined (code is no longer valid)")
            writer.close()


async def main(port, mode, public):
    bore = None
    if mode == "bore":
        bore = await start_bore(port)
    elif mode == "public":
        host, _, p = public.rpartition(":")
        set_public(host, p)
    else:
        PUBLIC["ip"], PUBLIC["port"] = lan_ip(), port
        log(f"LAN mode: the code points to {PUBLIC['ip']}:{port} (works on the same Wi-Fi only)")
    server = await asyncio.start_server(handle, "0.0.0.0", port)
    log(f"relay listening on port {port}. On the host console, type the IP of this phone.")
    try:
        async with server:
            await server.serve_forever()
    finally:
        if bore:
            bore.terminate()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("port", nargs="?", type=int, default=7777)
    ap.add_argument("--bore", action="store_true", help="start a bore tunnel (bore.pub) and use its address in the code")
    ap.add_argument("--public", metavar="HOST:PORT", help="public address of a tunnel you already run")
    a = ap.parse_args()
    mode = "bore" if a.bore else "public" if a.public else "lan"
    try:
        asyncio.run(main(a.port, mode, a.public))
    except KeyboardInterrupt:
        pass
