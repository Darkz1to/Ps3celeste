#!/usr/bin/env python3
"""Splits the AI-made title mockup (tools/menu_art/menu_mockup.gif, 640x360, 30 frames) into sprite layers
and packs them for the game:

  data/menu_art.bin     atlas (see menu_scene.inc.h for the format)
  menu_art.inc.h        star table + title sparkle positions
  tools/menu_art/layers/*.png   every sprite as an editable PNG (456x256 scene pixels)

Run:  python3 tools/gen_menu_art.py      (needs numpy, opencv-python, Pillow)
The polygons below were traced by hand on the mockup (640x360 coordinates)."""
import os, sys, struct
import numpy as np, cv2
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'tools', 'menu_art', 'menu_mockup.gif')
LAYERS = os.path.join(ROOT, 'tools', 'menu_art', 'layers')
W0, H0, W, H = 640, 360, 456, 256
os.makedirs(LAYERS, exist_ok=True)

# ------------------------------------------------------------------ frames
im = Image.open(SRC)
frames = []
for i in range(im.n_frames):
    im.seek(i); frames.append(np.array(im.convert('RGB')))
frames = np.stack(frames)
med = np.median(frames, axis=0).astype(np.uint8)
p80 = np.percentile(frames, 80, axis=0).astype(np.uint8)      # stars that twinkle are on in most of the frames

def lum(a): a = a.astype(np.float32); return 0.299*a[..., 0] + 0.587*a[..., 1] + 0.114*a[..., 2]
def poly(pts, shape=(H0, W0)):
    m = np.zeros(shape, np.uint8); cv2.fillPoly(m, [np.array(pts, np.int32)], 1); return m.astype(bool)
def rect(x0, y0, x1, y1):
    m = np.zeros((H0, W0), bool); m[y0:y1+1, x0:x1+1] = True; return m
def dil(m, r): return cv2.dilate(m.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*r+1, 2*r+1))).astype(bool)
def ero(m, r): return cv2.erode(m.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*r+1, 2*r+1))).astype(bool)

def nconv_fill(img, valid, sigmas=(1.5, 3)):
    """small holes: normalized convolution; big holes: harmonic (Laplace) fill solved at half resolution -> smooth, no contours"""
    img = img.astype(np.float32); v = valid.astype(np.float32)
    out = img.copy(); done = valid.copy()
    for s in sigmas:
        num = cv2.GaussianBlur(img * v[..., None], (0, 0), s)
        den = cv2.GaussianBlur(v, (0, 0), s)
        ok = (den > 0.5) & ~done
        out[ok] = num[ok] / den[ok][:, None]
        done |= ok
    if done.all(): return out
    h, w = img.shape[:2]; hs, ws = h // 2, w // 2
    vs = cv2.resize(v, (ws, hs), interpolation=cv2.INTER_AREA)
    known = vs > 0.99
    cs = cv2.resize(img * v[..., None], (ws, hs), interpolation=cv2.INTER_AREA) / np.maximum(vs, 1e-4)[..., None]
    # start from a blurred guess, then relax the unknown pixels towards the average of their neighbours
    guess = nconv_big(cs, known)
    cur = np.where(known[..., None], cs, guess)
    for it in range(2500):
        p = np.pad(cur, ((1, 1), (1, 1), (0, 0)), mode='edge')
        avg = 0.25 * (p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:])
        cur = np.where(known[..., None], cs, avg)
    up = cv2.resize(cur, (w, h), interpolation=cv2.INTER_CUBIC)
    out[~done] = up[~done]
    return out

def nconv_big(img, valid):
    v = valid.astype(np.float32); out = img.copy(); done = valid.copy()
    for s in (4, 12, 40, 120):
        num = cv2.GaussianBlur(img * v[..., None], (0, 0), s); den = cv2.GaussianBlur(v, (0, 0), s)
        ok = (den > 0.02) & ~done
        out[ok] = num[ok] / den[ok][:, None]; done |= ok
    return out

# ------------------------------------------------------------------ regions (640x360 coordinates)
BTN = [rect(255, 166, 388, 197), rect(255, 197, 388, 227), rect(255, 227, 388, 257), rect(255, 257, 388, 287), rect(255, 287, 388, 319)]
U = np.zeros((H0, W0), bool)
for b in BTN: U |= b
U |= rect(228, 170, 253, 196)       # strawberry cursor
U |= rect(262, 283, 338, 292)       # selection underline
U = dil(U, 2)
FPS = dil(rect(270, 0, 370, 22), 2)
TITLE_BOX = (184, 62, 452, 166)

MOUNT_RIDGE = [(395,283),(410,273),(425,262),(440,250),(452,242),(468,230),(478,221),(490,214),(503,207),(515,198),(522,190),(528,180),
               (534,172),(542,160),(548,152),(553,148),(560,148),(566,153),(572,160),(580,168),(590,178),(600,186),(610,196),(618,204),
               (626,210),(634,218),(640,222)]
MOUNT = poly(MOUNT_RIDGE + [(640,360),(236,360),(236,331),(255,326)])          # the left foot hides under the buttons
MOUNT_POLY = MOUNT.copy()
LEFT_GROUND = poly([(0,263),(60,262),(140,258),(150,254),(186,254),(194,262),(199,290),(200,360),(0,360)])

TREES = {   # name: (polygon, core erosion, pivot = trunk base)
    'tree0': ([(46,48),(52,56),(64,62),(60,70),(76,78),(68,86),(80,92),(72,98),(80,104),(68,112),(88,122),(76,130),(90,140),(78,150),(92,160),
               (84,168),(94,178),(86,188),(100,204),(92,212),(106,226),(96,238),(54,242),(52,268),(30,268),(30,242),(0,238),(0,110),(14,100),
               (22,94),(32,87),(40,80),(34,72),(42,62),(40,54)], 6, (42, 266)),
    'tree1': ([(122,146),(128,156),(135,165),(131,171),(144,178),(138,186),(150,196),(142,204),(158,214),(148,222),(156,232),(130,238),(128,264),
               (116,264),(115,238),(96,238),(96,226),(90,222),(98,212),(94,202),(102,194),(98,186),(106,180),(110,172),(108,166),(116,159)], 5, (121, 263)),
    'tree2': ([(172,218),(178,230),(176,238),(185,246),(182,250),(192,257),(182,262),(164,262),(153,257),(162,250),(159,246),(167,238),(165,230)], 3, (172, 261)),
}

# ------------------------------------------------------------------ stars / sparkles
def components(mask):
    n, lab, st, cen = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    return [(lab == i, st[i], cen[i]) for i in range(1, n)]

Lp = lum(p80)
white = (Lp > 100) & (p80[..., 2] > 120)
star_blobs, sparks, removal = [], [], np.zeros((H0, W0), bool)
for m, st, cen in components(white):
    x, y, w, h, area = st
    cx, cy = int(round(cen[0])), int(round(cen[1]))
    if U[cy, cx] or FPS[cy, cx]: continue
    inbox = TITLE_BOX[0] <= cx <= TITLE_BOX[2] and TITLE_BOX[1] <= cy <= TITLE_BOX[3]
    if max(w, h) > 24 or area > 160: continue                       # snow, nebula, letters
    if inbox and abs(cx - 391) <= 8 and abs(cy - 89) <= 8: continue         # the dot of the 'i' is part of the logo
    if inbox and max(w, h) >= 9 and area < 140:
        sparks.append((cx, cy, max(w, h))); removal |= dil(m, 2); continue
    if inbox: continue
    if max(w, h) > 12: continue
    star_blobs.append((cx, cy, w, h, area, m))
print('stars found', len(star_blobs), 'sparks', len(sparks))

# ------------------------------------------------------------------ foreground masks
star_mask = np.zeros((H0, W0), bool)
for *_, m in star_blobs: star_mask |= dil(m, 1)
base = nconv_fill(med, ~(star_mask | removal))                         # median frame without stars / sparkles
base = np.clip(base, 0, 255).astype(np.float32)
r, g, b = base[..., 0], base[..., 1], base[..., 2]
yy_, xx_ = np.mgrid[0:H0, 0:W0]

# the bright snow cap pokes out of the hand-traced ridge here and there: add every large bright blob around the peak
Lb = lum(base)
snow = (Lb > 110) & (b > 150) & (xx_ >= 430) & (yy_ >= 140) & (yy_ <= 262)
for m_, st_, cen_ in components(snow):
    if st_[4] > 200: MOUNT = MOUNT | dil(m_, 1)
glow = (b > 105) | (r > 38)
yy, xx = np.mgrid[0:H0, 0:W0]
lower_center = (xx >= 190) & (xx < 250) & (yy >= 240) & ~glow
fg_static = MOUNT | LEFT_GROUND | lower_center
fg_dark_tops = dil(lower_center, 3)
fg_static = cv2.morphologyEx(fg_static.astype(np.uint8), cv2.MORPH_OPEN, np.ones((2, 2), np.uint8)).astype(bool)
fg_static |= ero(MOUNT, 1) & False

tree_mask = {}
for name, (pts, er, piv) in TREES.items():
    P = poly(pts); core = ero(P, er)
    treelike = ((g - r >= 3) | ((r < 42) & (b < 78))) & (r < 45)
    m = P & (core | treelike)
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8)).astype(bool)
    tree_mask[name] = m & ~fg_static
fg_all = fg_static.copy()
for m in tree_mask.values(): fg_all |= m
tree_poly_all = np.zeros((H0, W0), bool)
for pts, er, piv in TREES.values(): tree_poly_all |= poly(pts)

# ------------------------------------------------------------------ colours behind the buttons
fg_valid = fg_static & ~U
fg_color = nconv_fill(base, fg_valid | ~fg_static)                       # (only used where fg_static & U)
fg_img = np.where((fg_static & U)[..., None], fg_color, base)

# ------------------------------------------------------------------ title (needs a first sky to diff against)
tx0, ty0, tx1, ty1 = TITLE_BOX
tbox = rect(tx0, ty0, tx1, ty1)
t_rough = tbox & (base[..., 0] >= 46)
t_rough = dil(cv2.morphologyEx(t_rough.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)).astype(bool), 4)
sky_valid = ~(dil(fg_all, 3) | dil(MOUNT, 5) | fg_dark_tops | dil(tree_poly_all, 5) | dil(U, 2) | FPS | t_rough | star_mask | removal)
sky = nconv_fill(base, sky_valid)
sky = np.clip(sky, 0, 255)
# a little grain so the filled areas do not look flat next to the dithered original
rng = np.random.RandomState(7)
grain = (rng.rand(H0, W0, 1) - 0.5) * 3.0
filled = ~sky_valid
sky = np.where(filled[..., None], sky + grain, sky)
sky = np.clip(sky, 0, 255)

d = np.abs(base - sky).max(axis=2)
a_t = np.clip((d - 22.0) / 48.0, 0, 1) * tbox
a_t = np.where(a_t < 0.12, 0, a_t)
a_t = np.where(t_rough, a_t, 0)
a_safe = np.maximum(a_t, 1e-3)[..., None]
t_rgb = np.clip((base - (1 - a_t[..., None]) * sky) / a_safe, 0, 255)

# ------------------------------------------------------------------ pack sprites at 456x256
def to_scene(rgb, alpha):
    """640x360 straight-alpha layer -> 456x256 straight-alpha layer (area filter on premultiplied colour)"""
    a = alpha.astype(np.float32)
    pm = rgb.astype(np.float32) * a[..., None]
    pm = cv2.resize(pm, (W, H), interpolation=cv2.INTER_AREA)
    a2 = cv2.resize(a, (W, H), interpolation=cv2.INTER_AREA)
    c = np.where(a2[..., None] > 1e-4, pm / np.maximum(a2, 1e-4)[..., None], 0)
    return np.clip(c, 0, 255).astype(np.uint8), np.clip(a2 * 255 + 0.5, 0, 255).astype(np.uint8)

sprites = []     # (name, x, y, w, h, px, py, rgba)
def add(name, rgb, alpha, pivot=None, opaque=False):
    c, a = to_scene(rgb, alpha)
    if opaque: a[:] = 255; x0, y0, x1, y1 = 0, 0, W, H
    else:
        ys, xs = np.where(a > 8)
        if len(xs) == 0: print('empty', name); return
        x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    rgba = np.dstack([c, a])[y0:y1, x0:x1]
    if pivot: px, py = int(round(pivot[0] * W / W0)) - x0, int(round(pivot[1] * H / H0)) - y0
    else: px = py = 0
    sprites.append((name, x0, y0, x1 - x0, y1 - y0, px, py, np.ascontiguousarray(rgba)))
    Image.fromarray(rgba, 'RGBA').save(os.path.join(LAYERS, name + '.png'))

# sky: gradient + nebula, no stars
sky_u8 = sky.astype(np.uint8)
add('sky', sky_u8, np.ones((H0, W0)), opaque=True)
add('mountain', fg_img, (fg_static & (xx >= 330)).astype(np.float32))
add('cliff', fg_img, (fg_static & (xx < 330)).astype(np.float32))
for name, (pts, er, piv) in TREES.items():
    add(name, base, tree_mask[name].astype(np.float32), pivot=piv)
add('title', t_rgb, a_t)

# four-point sparkle (17x17), white core, bluish arms
S = 17; c = S // 2
sp = np.zeros((S, S, 4), np.float32)
for y in range(S):
    for x in range(S):
        dx, dy = abs(x - c), abs(y - c)
        arm = max(0.0, 1 - max(dx, dy) / (c + 0.5)) * (1.0 if min(dx, dy) == 0 else max(0.0, 1 - min(dx, dy) / 1.6) * 0.8)
        core = max(0.0, 1 - (dx*dx + dy*dy) ** 0.5 / 3.0)
        a = min(1.0, arm + core * 0.8)
        sp[y, x] = (235, 242, 255, a * 255)
sp8 = np.clip(sp, 0, 255).astype(np.uint8)
sprites.append(('spark', 0, 0, S, S, c, c, sp8))
Image.fromarray(sp8, 'RGBA').save(os.path.join(LAYERS, 'spark.png'))

# ------------------------------------------------------------------ atlas + header
out = bytearray(b'MNA1' + struct.pack('<H', len(sprites)))
off = 6 + 40 * len(sprites)
data = bytearray()
for name, x, y, w, h, px, py, rgba in sprites:
    out += name.encode().ljust(24, b'\0') + struct.pack('<hhHHhhI', x, y, w, h, px, py, off + len(data))
    data += rgba.tobytes()
os.makedirs(os.path.join(ROOT, 'data'), exist_ok=True)
with open(os.path.join(ROOT, 'data', 'menu_art.bin'), 'wb') as f: f.write(out + data)

sx, sy = W / W0, H / H0
stars = []
for cx, cy, w, h, area, m in star_blobs:
    ys, xs = np.where(m)
    k = np.argmax(Lp[ys, xs])
    col = p80[ys[k], xs[k]]
    sz = 0 if area <= 3 else 1 if area <= 12 else 2
    X, Y = int(round(cx * sx)), int(round(cy * sy))
    if fg_all[min(cy, H0-1), min(cx, W0-1)] or U[cy, cx]: continue
    stars.append((X, Y, int(col[0]), int(col[1]), int(col[2]), sz))
with open(os.path.join(ROOT, 'menu_art.inc.h'), 'w') as f:
    f.write('// generated by tools/gen_menu_art.py -- do not edit\n#ifndef MENU_ART_INC_H_\n#define MENU_ART_INC_H_\n#include <stdint.h>\n')
    f.write('typedef struct { int16_t x, y; uint8_t r, g, b, sz; } menu_star_t;\n')
    f.write('#define MENU_STAR_COUNT %d\nstatic const menu_star_t menu_stars[MENU_STAR_COUNT] = {\n' % len(stars))
    for i in range(0, len(stars), 4):
        f.write('\t' + ' '.join('{%d,%d,%d,%d,%d,%d},' % s for s in stars[i:i+4]) + '\n')
    f.write('};\n')
    f.write('#define MENU_TITLE_SPARK_COUNT %d\nstatic const int16_t menu_title_sparks[MENU_TITLE_SPARK_COUNT][3] = {\n' % len(sparks))
    for cx, cy, s in sparks:
        f.write('\t{%d,%d,%d},\n' % (int(round(cx*sx)), int(round(cy*sy)), (int(s*sx) | 1)))
    f.write('};\n#endif\n')

# ------------------------------------------------------------------ preview (reassembled scene vs. the mockup)
def comp():
    canvas = np.zeros((H, W, 3), np.float32)
    for name in ['sky', 'tree2', 'tree1', 'mountain', 'cliff', 'tree0', 'title']:
        for n, x, y, w, h, px, py, rgba in sprites:
            if n != name: continue
            a = rgba[..., 3:4].astype(np.float32) / 255
            canvas[y:y+h, x:x+w] = canvas[y:y+h, x:x+w] * (1 - a) + rgba[..., :3] * a
    for X, Y, r_, g_, b_, sz in stars:
        if 0 <= X < W and 0 <= Y < H: canvas[Y, X] = (r_, g_, b_)
    return np.clip(canvas, 0, 255).astype(np.uint8)
prev = comp()
Image.fromarray(prev).save(os.path.join(ROOT, 'tools', 'menu_art', 'preview_reassembled.png'))
Image.fromarray(sky_u8).save(os.path.join(ROOT, 'tools', 'menu_art', 'preview_sky640.png'))
print('sprites:', [(s[0], s[3], s[4]) for s in sprites], 'stars', len(stars))
