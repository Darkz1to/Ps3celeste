#!/usr/bin/env python3
"""Builds tools/hd_preview.c and writes PNG screenshots of some rooms to /tmp/hdprev (run from the project folder).
    python3 tools/hd_preview.py [rx,ry,ticks ...]"""
import os, subprocess, sys
import numpy as np
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
out = '/tmp/hdprev'; os.makedirs(out, exist_ok=True)
for name in ('gfx_hd', 'font_hd'):
    a = np.array(Image.open('data/%s.bmp' % name)); open('%s/%s.raw' % (out, name), 'wb').write(a.astype(np.uint8).tobytes())
    if name == 'gfx_hd': g = a.shape
    else: f = a.shape
subprocess.check_call(['gcc', '-O1', '-w', '-I.', '-o', out + '/hd_preview', 'tools/hd_preview.c', 'celeste.c', '-lm'])
rooms = sys.argv[1:] or ['0,0,40', '1,0,40', '2,0,40', '3,1,40', '5,1,40']
subprocess.check_call([out + '/hd_preview', out + '/gfx_hd.raw', str(g[1]), str(g[0]), out + '/font_hd.raw', str(f[1]), str(f[0]), out + '/shot'] + rooms)
for r in rooms:
    rx, ry, _ = r.split(',')
    p = '%s/shot_%s_%s' % (out, rx, ry)
    Image.open(p + '.ppm').save(p + '.png'); os.remove(p + '.ppm')
    print(p + '.png')
