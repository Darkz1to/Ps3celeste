// Headless harness for the renderer work (not part of the game build).
//   build:  gcc -O2 -o hd_harness tools/hd_harness.c celeste.c -I. -lm
//   run:    ./hd_harness <mode> <out_prefix> [room_x room_y [ticks [keys]]]
// Mode "base" renders with the original 16 colour renderer (what the game looked like before).
// It writes <out_prefix>.ppm.   keys: letters L R U D J X G
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stddef.h>
#include "celeste.h"
#include "tilemap.h"

#define VW 228
#define VH 128
#define VOX 50
static unsigned char gfx[128*256], font[128*128];
static unsigned char fb[VW*VH];
static int pal[16];
static int cam_x = 0, cam_y = 0, scr_x = 0, scr_y = 0;
static unsigned keys1 = 0;

static const unsigned char base_pal[16][3] = {
	{0,0,0},{0x1d,0x2b,0x53},{0x7e,0x25,0x53},{0,0x87,0x51},{0xab,0x52,0x36},{0x5f,0x57,0x4f},{0xc2,0xc3,0xc7},{0xff,0xf1,0xe8},
	{0xff,0,0x4d},{0xff,0xa3,0},{0xff,0xec,0x27},{0,0xe4,0x36},{0x29,0xad,0xff},{0x83,0x76,0x9c},{0xff,0x77,0xa8},{0xff,0xcc,0xaa}};

static void px(int x, int y, int c) { if (x >= 0 && y >= 0 && x < VW && y < VH) fb[y*VW + x] = c; }
static void rectfill(int x0, int y0, int x1, int y1, int c) {
	for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) px(x - cam_x - scr_x, y - cam_y - scr_y, pal[c & 15]);
}
static void spr(int s, int x, int y, int flipx, int flipy) {
	if (s < 0) return;
	int sx = 8*(s%16), sy = 8*(s/16);
	for (int j = 0; j < 8; j++) for (int i = 0; i < 8; i++) {
		int c = gfx[(sy + (flipy ? 7-j : j))*128 + sx + (flipx ? 7-i : i)];
		if (c) px(x + i - cam_x - scr_x, y + j - cam_y - scr_y, pal[c]);
	}
}
static void print(const char* str, int x, int y, int col) {
	for (; *str; str++, x += 4) {
		int c = *str & 0x7f, sx = 8*(c%16), sy = 8*(c/16);
		for (int j = 0; j < 8; j++) for (int i = 0; i < 8; i++)
			if (font[(sy+j)*128 + sx+i]) px(x + i - cam_x - scr_x, y + j - cam_y - scr_y, pal[col & 15]);
	}
}
static int tileflag(int t, int f) { return t < (int)sizeof tile_flags && (tile_flags[t] & (1<<f)) != 0; }

static int cb(CELESTE_P8_CALLBACK_TYPE call, ...) {
	va_list a; va_start(a, call);
	int ret = 0;
	switch (call) {
		case CELESTE_P8_MUSIC: case CELESTE_P8_SFX: break;
		case CELESTE_P8_SPR: { int s = va_arg(a,int), x = va_arg(a,int), y = va_arg(a,int); va_arg(a,int); va_arg(a,int);
			int fx = va_arg(a,int), fy = va_arg(a,int); spr(s, x, y, fx, fy); } break;
		case CELESTE_P8_BTN: { int b = va_arg(a,int); ret = b == 7 ? 0 : (keys1 >> b) & 1; } break;
		case CELESTE_P8_PAL: { int p = va_arg(a,int), q = va_arg(a,int); if (p >= 0 && p < 16 && q >= 0 && q < 16) pal[p] = q; } break;
		case CELESTE_P8_PAL_RESET: for (int i = 0; i < 16; i++) pal[i] = i; break;
		case CELESTE_P8_CIRCFILL: { int cx = va_arg(a,int), cy = va_arg(a,int), r = va_arg(a,int), c = va_arg(a,int);
			for (int y = -r; y <= r; y++) for (int x = -r; x <= r; x++) if (x*x + y*y <= r*r + r/2) rectfill(cx+x, cy+y, cx+x, cy+y, c); } break;
		case CELESTE_P8_PRINT: { const char* s = va_arg(a,const char*); int x = va_arg(a,int), y = va_arg(a,int), c = va_arg(a,int); print(s, x, y, c); } break;
		case CELESTE_P8_RECTFILL: { int x0 = va_arg(a,int), y0 = va_arg(a,int), x1 = va_arg(a,int), y1 = va_arg(a,int), c = va_arg(a,int); rectfill(x0,y0,x1,y1,c); } break;
		case CELESTE_P8_LINE: { int x0 = va_arg(a,int), y0 = va_arg(a,int), x1 = va_arg(a,int), y1 = va_arg(a,int), c = va_arg(a,int);
			if (x0 == x1) for (int y = y0; y <= y1; y++) rectfill(x0,y,x0,y,c); else if (y0 == y1) for (int x = x0; x <= x1; x++) rectfill(x,y0,x,y0,c); } break;
		case CELESTE_P8_MGET: { int x = va_arg(a,int), y = va_arg(a,int); ret = tilemap_data[x + y*128]; } break;
		case CELESTE_P8_CAMERA: { cam_x = va_arg(a,int) - VOX; cam_y = va_arg(a,int); } break;
		case CELESTE_P8_SCROLL: { scr_x = va_arg(a,int); scr_y = va_arg(a,int); } break;
		case CELESTE_P8_FGET: { int t = va_arg(a,int), f = va_arg(a,int); ret = tileflag(t, f); } break;
		case CELESTE_P8_MAP: { int mx = va_arg(a,int), my = va_arg(a,int), tx = va_arg(a,int), ty = va_arg(a,int), mw = va_arg(a,int), mh = va_arg(a,int), mask = va_arg(a,int);
			for (int x = 0; x < mw; x++) for (int y = 0; y < mh; y++) {
				int t = tilemap_data[x+mx + (y+my)*128];
				if (mask == 0 || (mask == 4 && tile_flags[t] == 4) || tileflag(t, mask != 4 ? mask-1 : mask)) spr(t, tx + x*8, ty + y*8, 0, 0);
			} } break;
	}
	va_end(a);
	return ret;
}

static unsigned parse_keys(const char* s) {
	unsigned k = 0;
	for (; *s; s++) switch (*s) {
		case 'L': k |= 1; break; case 'R': k |= 2; break; case 'U': k |= 4; break; case 'D': k |= 8; break;
		case 'J': k |= 16; break; case 'X': k |= 32; break;
	}
	return k;
}

int main(int argc, char** argv) {
	if (argc < 3) { fprintf(stderr, "usage: %s base out [rx ry [ticks [keys]]]\n", argv[0]); return 1; }
	FILE* f = fopen("/home/claude/gfx.raw", "rb"); if (!f || fread(gfx, 1, sizeof gfx, f) == 0) return 2; fclose(f);
	f = fopen("/home/claude/font.raw", "rb"); if (!f || fread(font, 1, sizeof font, f) == 0) return 2; fclose(f);
	Celeste_P8_set_call_func(cb);
	Celeste_P8_set_wide_pad(VOX);
	Celeste_P8_set_rndseed(8);
	Celeste_P8_set_tutorial_enabled(0);
	Celeste_P8_init();
	Celeste_P8_set_menu_mode(0);
	int rx = argc > 3 ? atoi(argv[3]) : 0, ry = argc > 4 ? atoi(argv[4]) : 0;
	int ticks = argc > 5 ? atoi(argv[5]) : 60;
	unsigned keys = argc > 6 ? parse_keys(argv[6]) : 0;
	// start the game: press jump on the title screen
	for (int i = 0; i < 4; i++) { keys1 = 16; Celeste_P8_update(); keys1 = 0; Celeste_P8_update(); }
	for (int i = 0; i < 120; i++) Celeste_P8_update();
	if (argc > 4) {
		Celeste_P8_progress_t p; Celeste_P8_get_progress(&p);
		p.room_x = rx; p.room_y = ry;
		if (Celeste_P8_load_progress(&p) != 0) fprintf(stderr, "load_progress failed\n");
	}
	for (int i = 0; i < ticks; i++) { keys1 = (i > 30) ? keys : 0; Celeste_P8_update(); }
	for (int i = 0; i < 16; i++) pal[i] = i;
	cam_x = -VOX; cam_y = 0;
	Celeste_P8_draw();
	char name[256]; snprintf(name, sizeof name, "%s.ppm", argv[2]);
	f = fopen(name, "wb");
	fprintf(f, "P6\n%d %d\n255\n", VW, VH);
	for (int i = 0; i < VW*VH; i++) fwrite(base_pal[fb[i]], 1, 3, f);
	fclose(f);
	return 0;
}
