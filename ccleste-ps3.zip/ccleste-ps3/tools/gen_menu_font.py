#!/usr/bin/env python3
"""Bakes the font of the title menu (mixed case + Portuguese accents) into data/menu_font.bin.
   python3 tools/gen_menu_font.py [font.ttf] [size]      (default: Roboto Medium 14 px, anti-aliased alpha glyphs)
File: "MFN1", u8 line_height, u8 ascent, u16 count, count * { u16 cp; u8 w, h; i8 xoff, yoff; u8 adv, pad; u32 offset }, alpha bytes.
yoff is measured from the baseline to the top of the glyph (negative = above)."""
import os, sys, struct
from PIL import Image, ImageDraw, ImageFont
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
path = sys.argv[1] if len(sys.argv) > 1 else '/usr/share/fonts/truetype/google-fonts/ofl/roboto/Roboto[wdth,wght].ttf'
size = int(sys.argv[2]) if len(sys.argv) > 2 else 14
f = ImageFont.truetype(path, size)
try:
    f.set_variation_by_axes([500 if a['name'] in (b'Weight', 'Weight') else 100 if a['name'] in (b'Width', 'Width') else a['default'] for a in f.get_variation_axes()])
except Exception as e:
    print('no variable axes:', e)
asc, desc = f.getmetrics()
cps = list(range(32, 127)) + list(range(160, 256)) + [0x2026, 0x2019, 0x2013]
ents, data = [], bytearray()
for cp in cps:
    ch = chr(cp)
    adv = int(round(f.getlength(ch)))
    bb = f.getbbox(ch, anchor='ls')
    if ch == ' ' or bb[2] <= bb[0] or bb[3] <= bb[1]:
        ents.append((cp, 0, 0, 0, 0, adv, len(data))); continue
    w, h = bb[2] - bb[0], bb[3] - bb[1]
    im = Image.new('L', (w, h), 0)
    ImageDraw.Draw(im).text((-bb[0], -bb[1]), ch, font=f, fill=255, anchor='ls')
    ents.append((cp, w, h, bb[0], bb[1], adv, len(data)))
    data += im.tobytes()
hdr = b'MFN1' + struct.pack('<BBH', asc + desc, asc, len(ents))
off0 = len(hdr) + 12 * len(ents)
body = b''.join(struct.pack('<HBBbbBBI', cp, w, h, xo, yo, adv, 0, off0 + o) for cp, w, h, xo, yo, adv, o in ents)
open(os.path.join(ROOT, 'data', 'menu_font.bin'), 'wb').write(hdr + body + bytes(data))
print('font baked:', len(ents), 'glyphs, line', asc + desc, 'ascent', asc)
