#!/usr/bin/env python3
"""
Generates the extra tiles used by the tutorial level (grass theme) and writes them into
rows 8..15 of data/gfx.bmp (sprite ids 128..255).  The original 128x64 sheet (ids 0..127)
is copied unchanged from tools/gfx.orig.bmp, so this script can be re-run at any time.

    python3 tools/gen_tutorial_gfx.py

Colour indexes are the PICO-8 palette (0 is transparent in gfx.bmp):
 1 navy  2 plum  3 dark green  4 brown  5 dark grey  6 light grey  7 white  8 red
 9 orange  10 yellow  11 green  12 blue  13 lavender  14 pink  15 peach
"""
import os, random, sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

K, NAVY, PLUM, DG, BR, DGR, LG, WH, RED, ORG, YEL, GR, BL, LAV, PNK, PCH = range(16)

# --- tile ids (sprite index in the sheet, 16 per row) -------------------------------------------
T_DIRT = 128            # 128..143  autotile by neighbour mask  (1=N 2=E 4=S 8=W solid)
T_STONE = 144           # 144..159
T_DIRT_ALT = 160        # 160..163  interior variants of the dirt (mask 15)
T_STONE_ALT = 164       # 164..167  interior variants of the stone
T_GRASS_ALT = 168       # 168..171  variants of the flat grass top (mask 14)
T_STONE_TOP_ALT = 172   # 172..175  variants of the flat moss top of stone (mask 14)
D_TUFT_A, D_TUFT_B, D_FL_RED, D_FL_YEL, D_FL_WHT, D_FL_LAV, D_MUSH, D_BUSH_L = range(176, 184)
D_BUSH_R, D_SIGN, D_FENCE, D_ROCK, D_ROOTS_A, D_ROOTS_B, D_FERN, D_LEAF = range(184, 192)
T_CANOPY = 192          # 192..197  3x2 canopy
T_TRUNK = 198           # 198 trunk top, 199 trunk bottom
T_VINE = 200            # 200..203  gate: vine (mid x2, top, bottom)
T_PETAL = 204           # 204..207 falling petal frames (unused by the map, available for effects)
T_HILL = 208            # 208..


def blank(w=8, h=8):
    return [[K] * w for _ in range(h)]


def put(t, x, y, c):
    if 0 <= y < len(t) and 0 <= x < len(t[0]):
        t[y][x] = c


def draw_dirt(mask, var, stone=False):
    n, e, s, w = [bool(mask & b) for b in (1, 2, 4, 8)]
    r = random.Random(7000 + var * 131 + mask * 17 + (999 if stone else 0))
    t = blank()
    if not stone:
        for y in range(8):
            for x in range(8):
                t[y][x] = BR
        # soil texture
        for _ in range(3):
            put(t, r.randrange(1, 7), r.randrange(3, 7), PLUM)
        for _ in range(2):
            put(t, r.randrange(1, 7), r.randrange(3, 8), ORG)
        # a few darker flecks
        put(t, r.randrange(0, 8), r.randrange(4, 8), 2)
    else:
        # bricks: two rows of 4px, joints staggered
        for y in range(8):
            for x in range(8):
                t[y][x] = LG
        for x in range(8):
            t[3][x] = DGR           # mortar rows
            t[7][x] = DGR
        for y in range(0, 3):
            t[y][3] = DGR           # joints
        for y in range(4, 7):
            t[y][7] = DGR
            t[y][0] = DGR if False else t[y][0]
        # highlights / shading per brick
        for x in range(8):
            if t[0][x] == LG: t[0][x] = WH
            if t[4][x] == LG: t[4][x] = WH
            if t[2][x] == LG: t[2][x] = LAV
            if t[6][x] == LG: t[6][x] = LAV
        for _ in range(3):
            put(t, r.randrange(0, 8), r.choice([1, 2, 5, 6]), r.choice([LAV, DGR]))
    edge = PLUM if not stone else NAVY
    # outlines where the neighbour is empty
    if not s:
        for x in range(8): t[7][x] = edge
        for x in range(8): t[6][x] = t[6][x] if x % 2 else (PLUM if not stone else DGR)
    if not e:
        for y in range(8): t[y][7] = edge
    if not w:
        for y in range(8): t[y][0] = edge
    # round the corners
    if not s and not e: t[7][7] = K; t[7][6] = edge; t[6][7] = edge
    if not s and not w: t[7][0] = K; t[7][1] = edge; t[6][0] = edge
    if not n and not e: t[0][7] = K
    if not n and not w: t[0][0] = K
    if not n:
        # grass cap (stone gets moss: fewer blades, patchy)
        blades = r.sample(range(8), 4)
        for x in range(8):
            t[0][x] = GR if x in blades else K
            t[1][x] = GR
            t[2][x] = DG
        t[1][r.randrange(1, 7)] = YEL if not stone else GR
        t[1][r.randrange(1, 7)] = YEL if not stone else GR
        for x in r.sample(range(8), 3):
            t[3][x] = DG
        if stone:
            # moss only covers part of the stone: leave gaps in the cap
            for x in r.sample(range(1, 7), 2):
                t[2][x] = LG; t[3][x] = DGR if t[3][x] == DG else t[3][x]
        if not e: t[0][7] = K; t[1][7] = GR; t[2][7] = DG
        if not w: t[0][0] = K; t[1][0] = GR; t[2][0] = DG
        if not e and not s: t[7][7] = K
    return t


def draw_tuft(h, var):
    t = blank()
    r = random.Random(11 + var)
    xs = [1, 3, 4, 6] if var == 0 else [0, 2, 4, 5, 7]
    for i, x in enumerate(xs):
        hh = h - (i % 2) - (1 if i == 0 else 0)
        for k in range(hh):
            put(t, x + (1 if k == hh - 1 and i % 2 else 0), 7 - k, GR if k >= hh - 2 else DG)
    return t


def draw_flower(col, centre=YEL):
    t = blank()
    for y in range(4, 8):
        put(t, 3, y, DG)
    put(t, 4, 6, DG); put(t, 5, 5, GR); put(t, 2, 5, GR); put(t, 1, 4, GR)
    # bloom 3x3 plus centre
    for dx, dy in ((0, 1), (1, 0), (1, 1), (1, 2), (2, 1)):
        put(t, 2 + dx, 1 + dy - 0, col)
    put(t, 3, 2, centre)
    return t


def draw_mushroom():
    t = blank()
    for x in range(2, 6): put(t, x, 4, RED)
    for x in range(1, 7): put(t, x, 5, RED)
    put(t, 2, 4, WH); put(t, 4, 5, WH); put(t, 5, 4, RED); put(t, 1, 5, RED)
    for x in range(1, 7): put(t, x, 6, PLUM) if x in (1, 6) else None
    for y in (6, 7):
        put(t, 3, y, PCH); put(t, 4, y, PCH)
    put(t, 3, 7, PCH)
    return t


def draw_bush(side):
    t = blank()
    # 16px wide bush drawn as two tiles
    W = 16
    big = blank(16, 8)
    r = random.Random(5)
    for y in range(8):
        for x in range(16):
            # rounded top silhouette
            hgt = 5 + int(2.2 * __import__('math').sin(x / 15.0 * 3.14159 * 1.0)) - (0 if 2 <= x <= 13 else 1)
            if y >= 8 - hgt:
                c = DG
                if y == 8 - hgt or (y == 8 - hgt + 1 and (x % 3 == 0)):
                    c = GR
                big[y][x] = c
    for _ in range(6):
        put(big, r.randrange(2, 14), r.randrange(4, 8), GR if r.random() < .5 else 3)
    # berries
    for (x, y) in ((4, 5), (9, 4), (12, 6)):
        put(big, x, y, RED)
    return [row[side * 8:(side + 1) * 8] for row in big]


def draw_sign():
    t = blank()
    for x in range(1, 7):
        for y in range(1, 5):
            t[y][x] = PCH
    for x in range(1, 7):
        t[1][x] = WH if x % 2 else PCH
        t[4][x] = BR
    for y in range(1, 5):
        t[y][1] = BR; t[y][6] = BR
    put(t, 2, 2, BR); put(t, 3, 2, BR); put(t, 5, 3, BR); put(t, 4, 3, BR)
    for y in (5, 6, 7):
        put(t, 3, y, BR); put(t, 4, y, 9 if y == 5 else BR)
    return t


def draw_fence():
    t = blank()
    for y in range(2, 8):
        put(t, 1, y, BR); put(t, 6, y, BR)
        put(t, 2, y, 9) if y > 2 else None
        put(t, 5, y, 9) if y > 2 else None
    put(t, 1, 1, BR); put(t, 6, 1, BR)
    for x in range(0, 8):
        put(t, x, 3, PCH if x not in (1, 6) else BR); put(t, x, 5, PCH if x not in (1, 6) else BR)
    return t


def draw_rock():
    t = blank()
    shape = ["........", "........", "........", "..6666..", ".677766.", "66777666", "65555556", ".666666."]
    cm = {'.': K, '6': LG, '7': WH, '5': DGR}
    for y, row in enumerate(shape):
        for x, ch in enumerate(row):
            t[y][x] = cm[ch]
    return t


def draw_roots(var):
    """hangs under a floating grass strip: strands with leaves."""
    t = blank()
    r = random.Random(40 + var)
    xs = [1, 4, 6] if var == 0 else [2, 5]
    for x in xs:
        ln = r.randrange(4, 8)
        for y in range(ln):
            put(t, x, y, DG)
            if y % 2 == 1:
                put(t, x + (1 if (x + y) % 2 else -1), y, GR)
        put(t, x, ln, GR)
    return t


def draw_fern():
    t = blank()
    for y in range(3, 8):
        put(t, 3, y, DG)
    for i, y in enumerate(range(3, 8)):
        put(t, 3 - 1 - (i // 2), y, GR); put(t, 3 + 1 + (i // 2), y, GR)
    put(t, 3, 2, GR)
    return t


def draw_leaf():
    t = blank()
    for (x, y, c) in ((2, 3, GR), (3, 3, GR), (3, 4, DG), (4, 4, GR), (4, 5, DG), (5, 5, GR)):
        put(t, x, y, c)
    return t


def draw_vine(kind):
    """gate: a curtain of thorny vines. kind 0/1 = mid, 2 = top (hangs from the ceiling), 3 = bottom"""
    t = blank()
    r = random.Random(300 + kind)
    for y in range(8):
        for x in (1, 6):
            put(t, x + (1 if (y // 2) % 2 else 0), y, DG)
        put(t, 3 + ((y + kind) % 3 == 0), y, GR)
        put(t, 4, y, DG if y % 2 else GR)
    for y in range(8):
        put(t, 2, y, DG if (y + kind) % 3 else GR)
        put(t, 5, y, GR if (y + kind) % 3 else DG)
    for _ in range(4):
        put(t, r.randrange(0, 8), r.randrange(0, 8), GR)
    put(t, 0, 2 + kind, PLUM); put(t, 7, 5 - kind, PLUM)        # thorns
    put(t, 3, 4 + kind % 2, PNK); put(t, 4, 3 + kind % 2, PNK)   # flower buds
    if kind == 2:
        for x in range(8): put(t, x, 0, DG)
    return t


def paste(sheet, tid, tile):
    ox, oy = (tid % 16) * 8, (tid // 16) * 8
    for y in range(8):
        for x in range(8):
            sheet[oy + y][ox + x] = tile[y][x]


def draw_canopy(sheet):
    import math
    W, H = 24, 16
    big = blank(W, H)
    r = random.Random(77)
    # union of circles
    circles = [(6, 9, 6), (12, 7, 7), (18, 9, 6), (9, 5, 5), (15, 5, 5)]
    for y in range(H):
        for x in range(W):
            for (cx, cy, rr) in circles:
                if (x - cx) ** 2 + (y - cy) ** 2 <= rr * rr:
                    big[y][x] = DG
                    break
    # light from the top left, darker belly
    for y in range(H):
        for x in range(W):
            if big[y][x] == DG:
                up = big[y - 1][x] if y > 0 else K
                lf = big[y][x - 1] if x > 0 else K
                if up == K or lf == K:
                    big[y][x] = GR
                elif y > 10 and r.random() < .35:
                    big[y][x] = 3
                elif r.random() < .10:
                    big[y][x] = GR
    # bottom shadow row
    for y in range(H):
        for x in range(W):
            if big[y][x] != K and (y == H - 1 or big[y + 1][x] == K):
                big[y][x] = DG
    # sparkles and fruit
    for (x, y) in ((8, 6), (14, 9), (17, 5), (5, 10)):
        put(big, x, y, YEL if (x + y) % 2 else PNK)
    for j in range(2):
        for i in range(3):
            paste(sheet, T_CANOPY + j * 3 + i, [row[i * 8:(i + 1) * 8] for row in big[j * 8:(j + 1) * 8]])


def draw_trunk(sheet):
    top = blank(); bot = blank()
    for y in range(8):
        for x in range(3, 5 + 0):
            top[y][x] = BR
        top[y][3] = BR; top[y][4] = BR
        top[y][2] = PLUM if y % 3 else K
        top[y][5] = PLUM
    for y in range(8):
        for x in range(2, 6):
            bot[y][x] = BR
        bot[y][2] = PLUM; bot[y][5] = PLUM
        bot[y][3] = 9 if y % 3 == 0 else BR
    for x in (1, 6):
        bot[7][x] = BR
    bot[6][1] = BR; bot[6][6] = BR
    paste(sheet, T_TRUNK, top)
    paste(sheet, T_TRUNK + 1, bot)


def build(out_path):
    orig = Image.open(os.path.join(HERE, 'gfx.orig.bmp'))
    palette = orig.getpalette()
    sheet = [[K] * 128 for _ in range(128)]
    ow, oh = orig.size
    px = orig.load()
    for y in range(oh):
        for x in range(ow):
            sheet[y][x] = px[x, y]

    for m in range(16):
        paste(sheet, T_DIRT + m, draw_dirt(m, 0))
        paste(sheet, T_STONE + m, draw_dirt(m, 0, stone=True))
    for v in range(4):
        paste(sheet, T_DIRT_ALT + v, draw_dirt(15, v + 1))
        paste(sheet, T_STONE_ALT + v, draw_dirt(15, v + 1, stone=True))
        paste(sheet, T_GRASS_ALT + v, draw_dirt(14, v + 1))
        paste(sheet, T_STONE_TOP_ALT + v, draw_dirt(14, v + 1, stone=True))
    paste(sheet, D_TUFT_A, draw_tuft(3, 0)); paste(sheet, D_TUFT_B, draw_tuft(4, 1))
    paste(sheet, D_FL_RED, draw_flower(RED)); paste(sheet, D_FL_YEL, draw_flower(YEL, ORG))
    paste(sheet, D_FL_WHT, draw_flower(WH, YEL)); paste(sheet, D_FL_LAV, draw_flower(PNK, WH))
    paste(sheet, D_MUSH, draw_mushroom())
    paste(sheet, D_BUSH_L, draw_bush(0)); paste(sheet, D_BUSH_R, draw_bush(1))
    paste(sheet, D_SIGN, draw_sign()); paste(sheet, D_FENCE, draw_fence()); paste(sheet, D_ROCK, draw_rock())
    paste(sheet, D_ROOTS_A, draw_roots(0)); paste(sheet, D_ROOTS_B, draw_roots(1))
    paste(sheet, D_FERN, draw_fern()); paste(sheet, D_LEAF, draw_leaf())
    draw_canopy(sheet); draw_trunk(sheet)
    for k in range(4):
        paste(sheet, T_VINE + k, draw_vine(k))

    img = Image.new('P', (128, 128))
    img.putpalette(palette)
    img.putdata([c for row in sheet for c in row])
    img.save(out_path, format='BMP')
    return sheet, palette


if __name__ == '__main__':
    out = os.path.join(ROOT, 'data', 'gfx.bmp')
    sheet, pal = build(out)
    # preview with a sky blue background so transparent pixels are visible
    prev = Image.new('RGB', (128 * 6, 64 * 6), (41, 173, 255))
    pp = prev.load()
    for y in range(64, 128):
        for x in range(128):
            c = sheet[y][x]
            if c:
                rgb = tuple(pal[c * 3:c * 3 + 3])
                for dy in range(6):
                    for dx in range(6):
                        pp[x * 6 + dx, (y - 64) * 6 + dy] = rgb
    pdir = os.environ.get('PREVIEW_DIR')
    if pdir:
        prev.save(os.path.join(pdir, 'tiles_preview.png'))
    print('wrote', out)
