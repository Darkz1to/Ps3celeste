// Headless preview of the animated title scene (not part of the game build).
//   gcc -O2 -I. -o menu_preview tools/menu_preview.c -lm && ./menu_preview data/menu_art.bin outdir t0 t1 step flags
// writes outdir/fNNNN.ppm (456x256)
#include "menu_ui.inc.h"
int main(int argc, char** argv) {
	if (argc < 7) { fprintf(stderr, "usage: %s atlas outdir t0 t1 step flags\n", argv[0]); return 1; }
	if (mscene_load(argv[1]) != 0) { fprintf(stderr, "cannot load %s\n", argv[1]); return 2; }
	static uint32_t fb[MS_W * MS_H];
	char fp[600]; snprintf(fp, sizeof fp, "%.*smenu_font.bin", (int)(strrchr(argv[1], '/') ? strrchr(argv[1], '/') - argv[1] + 1 : 0), argv[1]);
	if (mui_font_load(fp) != 0) fprintf(stderr, "no font %s\n", fp);
	const float t0 = (float)atof(argv[3]), t1 = (float)atof(argv[4]), st = (float)atof(argv[5]);
	const int flags = atoi(argv[6]);
	int n = 0;
	for (float t = t0; t <= t1 + 1e-4f; t += st, n++) {
		mscene_draw(fb, MS_W, MS_W, MS_H, t, flags & 1);
		if (flags & 2) {   // the title menu buttons (Portuguese labels, the selection moves every 2 s)
			static const char* L[5] = { "Continuar", "Novo Jogo", "Conteúdos", "Configurações", "Créditos" };
			int sel[5]; const int cur = ((int)(t / 2.0f)) % 5;
			for (int i = 0; i < 5; i++) sel[i] = i == cur ? 256 : 0;
			mui_main_buttons(fb, MS_W, MS_W, MS_H, L, 5, sel, t);
		}
		char name[512]; snprintf(name, sizeof name, "%s/f%04d.ppm", argv[2], n);
		FILE* f = fopen(name, "wb"); fprintf(f, "P6\n%d %d\n255\n", MS_W, MS_H);
		for (int i = 0; i < MS_W * MS_H; i++) { unsigned char c[3] = { (fb[i] >> 16) & 255, (fb[i] >> 8) & 255, fb[i] & 255 }; fwrite(c, 1, 3, f); }
		fclose(f);
	}
	return 0;
}
