#!/usr/bin/env python3
"""Checks that every tutorial banner line fits (PS3 icons and keyboard key caps)."""
import re, sys
src = open(__file__.replace('tools/check_tutorial_text.py', 'tutorial.inc.c')).read()
block = src[src.index('static const char* const tut_txt'):src.index('// ---- state')]
AVAIL = 208
icon = {'j': 7, 'd': 15, 'g': 23, 'm': 7, 'p': 7}
key = {'j': 5, 'd': 5, 'g': 5, 'm': 5, 'p': 27}
bad = 0
for m in re.finditer(r'\{ "([^"]*)", "([^"]*)", "([^"]*)" \}', block):
    for i, s in enumerate(m.groups()):
        for name, tbl in (('pad', icon), ('kbd', key)):
            w = 0; j = 0
            while j < len(s):
                if s[j] == '[' and j + 2 < len(s) and s[j+2] == ']':
                    w += tbl[s[j+1]] + 1; j += 3
                else:
                    w += 4; j += 1
            lim = AVAIL - (60 if i == 0 else 0)
            if w > lim:
                print('TOO LONG (%s %dpx > %d): %s' % (name, w, lim, s)); bad += 1
print('ok' if not bad else '%d problems' % bad)
sys.exit(1 if bad else 0)
