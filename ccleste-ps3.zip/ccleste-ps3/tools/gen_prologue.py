"""
The prologue of chapter 2 ("level 0"): a short vertical tutorial room that teaches the grapple.
Used by gen_celeste2.py. Builds the tile map (40 x 72 tiles) and the 16x16 sprites of the old lady.

Layout, from the bottom to the top (rows):
  68..71  floor
  61..67  training room (cols 10..21), the old lady waits here. Right wall = practice wall for the hook.
  60      the GATE (cols 12..18): opens when the three lessons are done
  36..59  the shaft (cols 12..18), ledges on both sides: climb by hooking the walls. The camera only goes up.
  36      plateau on the right with the little cabin (door at col 27)
  0..15   inside of the cabin (reached through the door; the door closes behind Madeline)
"""
W, H = 40, 72

def build_tiles():
    g = [['.'] * W for _ in range(H)]
    def fill(c0, r0, c1, r1, ch='#'):
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                g[r][c] = ch
    fill(0, 68, W - 1, H - 1)                 # floor
    fill(0, 30, 11, 60)                       # left mass (top at row 30)
    fill(0, 61, 9, 67)                        # left wall of the training room
    fill(19, 36, W - 1, 60)                   # right wall of the shaft = plateau (top at row 36)
    fill(22, 61, W - 1, 67)                   # right wall of the training room
    fill(19, 64, 21, 67)                      # the practice block for the hook
    fill(12, 60, 18, 60, 'G')                 # the gate
    fill(12, 55, 13, 56)                      # ledges
    fill(17, 49, 18, 50)
    fill(12, 43, 13, 44)
    # the cabin interior (rows 0..15): floor, ceiling and walls (it is drawn by code, the tiles are the collision)
    fill(0, 0, W - 1, 2)
    fill(0, 14, W - 1, 15)
    fill(0, 3, 9, 13); fill(22, 3, W - 1, 13)
    fill(0, 16, W - 1, 23)                    # rock between the cabin interior and the outside

    def solid(c, r):
        if c < 0 or r < 0 or c >= W or r >= H: return True
        return g[r][c] in '#G'
    t = [[0] * W for _ in range(H)]
    for r in range(H):
        for c in range(W):
            ch = g[r][c]
            if ch == '.': continue
            if ch == 'G':
                t[r][c] = (43, 44, 45)[c % 3]; continue
            L, R = not solid(c - 1, r), not solid(c + 1, r)
            if not solid(c, r - 1):
                t[r][c] = 16 if L else (18 if R else 17)
            elif not solid(c, r + 1):
                t[r][c] = 48 if L else (50 if R else 49)
            else:
                t[r][c] = 32 if L else (34 if R else 33)
    # the cabin on the plateau (same tiles as the cabin at the end of level 1)
    for i, row in enumerate(((64, 65, 66, 67), (80, 81, 82, 83), (96, 97, 98, 99))):
        for j, v in enumerate(row): t[33 + i][26 + j] = v
    t[35][25] = 26                            # a little snow pile
    t[35][31] = 26
    t[67][11] = 2                             # Madeline starts here
    t[54][12] = 13                            # checkpoints (a small flag)
    t[35][21] = 13
    return t

def lady_sprites():
    idle = [
        "......WWWW......",
        "......WWWW......",
        ".....WWWWWW.....",
        "....WWWWWWWW....",
        "....WWSSSSWW....",
        "....WS1SS1SW....",
        "....WSSRRSSW....",
        "....WSSSSSSW....",
        ".....WSSSSW.....",
        "....PPPPPPPP....",
        "...PPPPYPPPPPB..",
        "...PPPPPPPPPPB..",
        "...DDDPPPPDDDB..",
        "...DDDDDDDDDDB..",
        "...DDDDDDDDDDB..",
        "....BB....BB.B..",
    ]
    talk = list(idle); talk[7] = "....WSS88SSW...."
    col = dict(W=7, S=15, H=6, P=13, D=2, B=4, Y=10, R=14, **{'1': 1, '8': 8, '.': 0})
    out = []
    for fr in (idle, talk):
        assert all(len(r) == 16 for r in fr), [len(r) for r in fr]
        out.append([[col[ch] for ch in r] for r in fr])
    return out        # 2 frames of 16x16 color indices

# generated header constants (pixels)
CONSTS = dict(
    PT_GATE_COL0=12, PT_GATE_COL1=18, PT_GATE_ROW=60,
    PT_CABIN_DOOR_X=27 * 8 + 4, PT_CABIN_DOOR_Y=36 * 8,        # the cabin door (feet of Madeline)
    PT_LADY1_X=122, PT_LADY1_Y=68 * 8,                         # the old lady of the training room (feet)
    PT_IN_SPAWN_X=11 * 8 + 4, PT_IN_SPAWN_Y=14 * 8,            # where Madeline appears inside the cabin
    PT_LADY2_X=17 * 8 + 4, PT_LADY2_Y=14 * 8,                  # the old lady inside the cabin, in front of the portal
    PT_PORTAL_X=20 * 8 + 4, PT_PORTAL_Y=14 * 8,                # the portal
    PT_PLATEAU_ROW=36, PT_INSIDE_ROWS=24,
)
