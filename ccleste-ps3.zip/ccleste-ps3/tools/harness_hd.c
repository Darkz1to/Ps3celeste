// PC test harness: renders frames of the game through hdgfx.c into a PPM (same calls as sdl12main.c)
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "celeste.h"
#include "tilemap.h"
#include "hdgfx.h"
#define S 5
#define VW 228
#define OX 50
static uint32_t* fb;
static uint32_t mapr(int r,int g,int b){return (r<<16)|(g<<8)|b;}
static int cb(CELESTE_P8_CALLBACK_TYPE c,...){va_list a;va_start(a,c);int r=0;
switch(c){
case CELESTE_P8_SPR:{int s=va_arg(a,int),x=va_arg(a,int),y=va_arg(a,int);va_arg(a,int);va_arg(a,int);int fx=va_arg(a,int),fy=va_arg(a,int);if(s>=0)hd_tile(s,(x+OX)*S,y*S,fx,fy);}break;
case CELESTE_P8_PAL:{int p=va_arg(a,int),q=va_arg(a,int);hd_pal(p,q);}break;
case CELESTE_P8_PAL_RESET:hd_pal_reset();break;
case CELESTE_P8_RECTFILL:{int x0=va_arg(a,int),y0=va_arg(a,int),x1=va_arg(a,int),y1=va_arg(a,int),col=va_arg(a,int);hd_rect((x0+OX)*S,y0*S,(x1+OX+1)*S-1,(y1+1)*S-1,col);}break;
case CELESTE_P8_CIRCFILL:{int x=va_arg(a,int),y=va_arg(a,int),rr=va_arg(a,int),col=va_arg(a,int);hd_circle((x+OX)*S+S/2,y*S+S/2,rr,col);}break;
case CELESTE_P8_MGET:{int x=va_arg(a,int),y=va_arg(a,int);r=tilemap_data[x+y*128];}break;
case CELESTE_P8_FGET:{int t=va_arg(a,int),f=va_arg(a,int);r=(tile_flags[t]&(1<<f))!=0;}break;
case CELESTE_P8_HDBG:{int rx=va_arg(a,int),ry=va_arg(a,int),fr=va_arg(a,int);hd_bg(rx,ry,fr,VW*S,128*S);r=1;}break;
case CELESTE_P8_HDDIM:{int on=va_arg(a,int);hd_dim(on);r=1;}break;
case CELESTE_P8_MAP:{int mx=va_arg(a,int),my=va_arg(a,int),tx=va_arg(a,int),ty=va_arg(a,int),mw=va_arg(a,int),mh=va_arg(a,int),mask=va_arg(a,int);
 for(int x=0;x<mw;x++)for(int y=0;y<mh;y++){int t=tilemap_data[x+mx+(y+my)*128];
  if(mask==0||(mask==4&&tile_flags[t]==4)||(t<sizeof tile_flags&&(tile_flags[t]&(1<<(mask!=4?mask-1:mask))))) hd_tile(t,(tx+x*8+OX)*S,(ty+y*8)*S,0,0);}}break;
default:break;}
va_end(a);return r;}
int main(int argc,char**argv){
 int rx=atoi(argv[1]),ry=atoi(argv[2]),n=atoi(argv[3]);
 fb=calloc(VW*S*128*S,4);
 hd_init(S,mapr);
 if(hd_load_atlas("data/gfx_hd.bin")){fprintf(stderr,"atlas load failed\n");return 1;}
 hd_target(fb,VW*S,128*S,VW*S);
 Celeste_P8_set_call_func(cb);Celeste_P8_set_rndseed(1);Celeste_P8_init();Celeste_P8_set_wide_pad(OX);
 Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=rx;p.room_y=ry;p.max_djump=1;
 Celeste_P8_load_progress(&p);
 for(int i=0;i<n;i++){Celeste_P8_update();Celeste_P8_draw();}
 printf("P6\n%d %d\n255\n",VW*S,128*S);
 for(int i=0;i<VW*S*128*S;i++){unsigned char c[3]={fb[i]>>16,fb[i]>>8,fb[i]};fwrite(c,1,3,stdout);}
 return 0;}
