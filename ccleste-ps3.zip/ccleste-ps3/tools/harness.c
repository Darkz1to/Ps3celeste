// Headless test harness for celeste.c (not part of the game build).
//   build:  gcc -O1 -o harness tools/harness.c celeste.c -I. -lm
//   run:    ./harness <gfx.raw> <font.raw> <solo|coop> <script>
// The script has one command per line:
//   hold <ticks> <keys>   keys: L R U D J(jump) X(dash) G(grab) T(merge), lower case = player 2
//   snap <file.ppm>       writes the current frame (228x128)
//   tp <player> <x> <y>   teleports a player (debug)
//   status                prints positions
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stddef.h>
#include "celeste.h"
#include "tilemap.h"

#define VW 228
#define VH 128
#define VOX 50
static unsigned char gfx[128*128], font[128*128];
static unsigned char fb[VW*VH];
static int pal[16];
static int cam_x = 0, cam_y = 0;
static unsigned keys1 = 0, keys2 = 0;     // bit0..5 = l r u d j x, bit 6 = merge, bit 7 = grab

static const unsigned char base_pal[16][3] = {
	{0,0,0},{0x1d,0x2b,0x53},{0x7e,0x25,0x53},{0,0x87,0x51},{0xab,0x52,0x36},{0x5f,0x57,0x4f},{0xc2,0xc3,0xc7},{0xff,0xf1,0xe8},
	{0xff,0,0x4d},{0xff,0xa3,0},{0xff,0xec,0x27},{0,0xe4,0x36},{0x29,0xad,0xff},{0x83,0x76,0x9c},{0xff,0x77,0xa8},{0xff,0xcc,0xaa}};

static void px(int x, int y, int c) { if (x >= 0 && y >= 0 && x < VW && y < VH) fb[y*VW + x] = c; }
static void rectfill(int x0, int y0, int x1, int y1, int c) {
	for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) px(x - cam_x, y - cam_y, pal[c & 15]);
}
static void spr(int s, int x, int y, int flipx, int flipy) {
	if (s < 0) return;
	int sx = 8*(s%16), sy = 8*(s/16);
	for (int j = 0; j < 8; j++) for (int i = 0; i < 8; i++) {
		int c = gfx[(sy + (flipy ? 7-j : j))*128 + sx + (flipx ? 7-i : i)];
		if (c) px(x + i - cam_x, y + j - cam_y, pal[c]);
	}
}
static void print(const char* str, int x, int y, int col) {
	for (; *str; str++, x += 4) {
		int c = *str & 0x7f, sx = 8*(c%16), sy = 8*(c/16);
		for (int j = 0; j < 8; j++) for (int i = 0; i < 8; i++)
			if (font[(sy+j)*128 + sx+i]) px(x + i - cam_x, y + j - cam_y, pal[col & 15]);
	}
}
static int tileflag(int t, int f) { return t < (int)sizeof tile_flags && (tile_flags[t] & (1<<f)) != 0; }

static int cb(CELESTE_P8_CALLBACK_TYPE call, ...) {
	va_list a; va_start(a, call);
	int ret = 0;
	switch (call) {
		case CELESTE_P8_MUSIC: case CELESTE_P8_SFX: break;
		case CELESTE_P8_SPR: { int s = va_arg(a,int), x = va_arg(a,int), y = va_arg(a,int); va_arg(a,int); va_arg(a,int);
			int fx = va_arg(a,int), fy = va_arg(a,int); spr(s, x, y, fx, fy); } break;
		case CELESTE_P8_BTN: { int b = va_arg(a,int); ret = b == 7 ? (keys1 >> 7) & 1 : (keys1 >> b) & 1; } break;
		case CELESTE_P8_PAL: { int p = va_arg(a,int), q = va_arg(a,int); if (p >= 0 && p < 16 && q >= 0 && q < 16) pal[p] = q; } break;
		case CELESTE_P8_PAL_RESET: for (int i = 0; i < 16; i++) pal[i] = i; break;
		case CELESTE_P8_CIRCFILL: { int cx = va_arg(a,int), cy = va_arg(a,int), r = va_arg(a,int), c = va_arg(a,int);
			for (int y = -r; y <= r; y++) for (int x = -r; x <= r; x++) if (x*x + y*y <= r*r + r/2) rectfill(cx+x, cy+y, cx+x, cy+y, c); } break;
		case CELESTE_P8_PRINT: { const char* s = va_arg(a,const char*); int x = va_arg(a,int), y = va_arg(a,int), c = va_arg(a,int); print(s, x, y, c); } break;
		case CELESTE_P8_RECTFILL: { int x0 = va_arg(a,int), y0 = va_arg(a,int), x1 = va_arg(a,int), y1 = va_arg(a,int), c = va_arg(a,int); rectfill(x0,y0,x1,y1,c); } break;
		case CELESTE_P8_LINE: { int x0 = va_arg(a,int), y0 = va_arg(a,int), x1 = va_arg(a,int), y1 = va_arg(a,int), c = va_arg(a,int);
			if (x0 == x1) for (int y = y0; y <= y1; y++) rectfill(x0,y,x0,y,c); else if (y0 == y1) for (int x = x0; x <= x1; x++) rectfill(x,y0,x,y0,c); } break;
		case CELESTE_P8_MGET: { int x = va_arg(a,int), y = va_arg(a,int); ret = tilemap_data[x + y*128]; } break;
		case CELESTE_P8_CAMERA: { cam_x = va_arg(a,int); cam_y = va_arg(a,int); } break;
		case CELESTE_P8_FGET: { int t = va_arg(a,int), f = va_arg(a,int); ret = tileflag(t, f); } break;
		case CELESTE_P8_MAP: { int mx = va_arg(a,int), my = va_arg(a,int), tx = va_arg(a,int), ty = va_arg(a,int), mw = va_arg(a,int), mh = va_arg(a,int), mask = va_arg(a,int);
			for (int x = 0; x < mw; x++) for (int y = 0; y < mh; y++) {
				int t = tilemap_data[x+mx + (y+my)*128];
				if (mask == 0 || (mask == 4 && tile_flags[t] == 4) || tileflag(t, mask != 4 ? mask-1 : mask)) spr(t, tx + x*8, ty + y*8, 0, 0);
			} } break;
	}
	va_end(a);
	return ret;
}

static void draw_frame(void) {
	cam_x = -VOX; cam_y = 0;
	for (int i = 0; i < 16; i++) pal[i] = i;
	// the game sets camera(0,0) only when shaking: emulate the frontend (camera_x = cam_ux - VIEW_OX)
	Celeste_P8_draw();
}
static void snap(const char* file) {
	draw_frame();
	FILE* f = fopen(file, "wb");
	fprintf(f, "P6\n%d %d\n255\n", VW, VH);
	for (int i = 0; i < VW*VH; i++) fwrite(base_pal[fb[i]], 1, 3, f);
	fclose(f);
}

static unsigned parse_keys(const char* s, int p2) {
	unsigned k = 0;
	for (; *s; s++) {
		char c = *s;
		if (p2 ? (c >= 'a' && c <= 'z') : (c >= 'A' && c <= 'Z')) {
			switch (c & ~32) {
				case 'L': k |= 1; break; case 'R': k |= 2; break; case 'U': k |= 4; break; case 'D': k |= 8; break;
				case 'J': k |= 16; break; case 'X': k |= 32; break; case 'T': k |= 64; break; case 'G': k |= 128; break;
			}
		}
	}
	return k;
}

int Celeste_H_player(int pid, float* v);
void Celeste_H_tp(int pid, float x, float y);
void Celeste_H_tut(int* st);

static void tick(void) {
	Celeste_P8_set_coop_input((keys1 >> 6) & 1, (keys2 & 0x3f) | (((keys2 >> 6) & 1) << 6) | (((keys2 >> 7) & 1) << 7));
	Celeste_P8_update();
}

// ---- planner: beam search over 4 tick macro actions with the game's own save/load state ----------
typedef struct { void* st; int parent, act; float score; unsigned long long key; } Node;
#define MACRO 4
extern int celeste_h_noballoon;
static int plan_nodash, plan_nograb, plan_stop = 99;
static unsigned act_keys(int a) {          // 72 actions
	static const unsigned dirs[3] = {0, 1, 2}, vert[3] = {0, 4, 8};
	unsigned k = dirs[a % 3]; a /= 3; k |= vert[a % 3]; a /= 3;
	if (a % 2) k |= 16; a /= 2;
	if (a % 2) k |= 32; a /= 2;
	if (a % 2) k |= 128;
	if (plan_nodash) k &= ~32u;
	if (plan_nograb) k &= ~128u;
	return k;
}
static float progress(const float* v, const int* t) {
	if (v[1] > 62) return (v[0] + 48.0f) + (v[0] > 100 ? (104 - v[1]) * 1.5f : 0);
	return 300 + (176 - v[0]);
}
static int plan(const char* outfile, int width, int maxsteps) {
	{ float v[9]; keys1 = keys2 = 0; for (int i = 0; i < 300 && !Celeste_H_player(0, v); i++) tick(); }
	if (getenv("PLAN_TP")) { float x, y; sscanf(getenv("PLAN_TP"), "%f,%f", &x, &y); Celeste_H_tp(0, x, y); }
	size_t sz = Celeste_P8_get_state_size();
	fprintf(stderr, "state size %zu\n", sz);
	static Node hist[400][2000]; static int hn[400];
	Node* cur = calloc(width, sizeof(Node)); int cn = 1;
	cur[0].st = malloc(sz); Celeste_P8_save_state(cur[0].st); cur[0].parent = -1;
	Node* nxt = calloc(width * 4, sizeof(Node));
	int done = -1, doneStep = -1;
	for (int step = 0; step < maxsteps && done < 0; step++) {
		int nn = 0;
		for (int i = 0; i < cn; i++) {
			for (int a = 0; a < 72; a++) {
				Celeste_P8_load_state(cur[i].st);
				keys1 = act_keys(a); keys2 = 0;
				int d0[16]; Celeste_H_tut(d0);
				int dead = 0;
				for (int k = 0; k < MACRO; k++) { Celeste_P8_set_coop_input(0, 0); Celeste_P8_update(); }
				int t[16]; Celeste_H_tut(t);
				if (t[2] != d0[2]) dead = 1;
				float v[9] = {0};
				if (dead) continue;
				if (t[0] && t[1] >= plan_stop) { v[0] = -48; v[1] = 0; t[0] = 0; }
				if (!t[0]) { v[0] = -48; v[1] = 0; }
				else if (!Celeste_H_player(0, v)) { continue; }
				float sc = t[0] ? progress(v, t) : 9999;
				unsigned long long key = ((unsigned long long)(int)(v[0]/2) * 1000003ull) ^ ((unsigned long long)(int)(v[1]/2) * 7919ull)
					^ ((unsigned long long)(int)(v[2]*2+8) * 131ull) ^ ((unsigned long long)(int)(v[3]*2+8) * 17ull) ^ ((unsigned long long)(int)v[4] * 3ull)
					^ ((unsigned long long)(int)(v[8]/20) * 977ull) ^ ((unsigned long long)(int)v[6] * 5ull);
				int dup = 0;
				for (int j = 0; j < nn; j++) if (nxt[j].key == key) { dup = 1; if (nxt[j].score < sc) { nxt[j].score = sc; nxt[j].parent = i; nxt[j].act = a; Celeste_P8_save_state(nxt[j].st); } break; }
				if (dup) continue;
				if (nn >= width * 4) continue;
				if (!nxt[nn].st) nxt[nn].st = malloc(sz);
				Celeste_P8_save_state(nxt[nn].st);
				nxt[nn].parent = i; nxt[nn].act = a; nxt[nn].score = sc; nxt[nn].key = key; nn++;
				if (!t[0]) { done = nn - 1; }
			}
		}
		if (nn == 0) { fprintf(stderr, "search died out at step %d\n", step); break; }
		// keep the best `width`
		for (int i = 0; i < nn; i++) for (int j = i + 1; j < nn && j < i + 1; j++) {}
		int idx[8000]; for (int i = 0; i < nn; i++) idx[i] = i;
		for (int i = 0; i < nn; i++) { int best = i; for (int j = i + 1; j < nn && i < width; j++) if (nxt[idx[j]].score > nxt[idx[best]].score) best = j; int tmp = idx[i]; idx[i] = idx[best]; idx[best] = tmp; if (i >= width) break; }
		int keep = nn < width ? nn : width;
		hn[step] = keep;
		Node* newcur = calloc(width, sizeof(Node));
		for (int i = 0; i < keep; i++) {
			newcur[i] = nxt[idx[i]];
			newcur[i].st = malloc(sz); memcpy(newcur[i].st, nxt[idx[i]].st, sz);
			hist[step][i] = newcur[i]; hist[step][i].st = NULL;
		}
		for (int i = 0; i < cn; i++) free(cur[i].st);
		free(cur); cur = newcur; cn = keep;
		if (done >= 0) { doneStep = step; break; }
		if (step % 20 == 0) { float v[9]; int t[16]; Celeste_H_tut(t); Celeste_P8_load_state(cur[0].st); Celeste_H_player(0, v); Celeste_H_tut(t); fprintf(stderr, "step %d best %.0f stage %d x %.0f y %.0f n=%d\n", step, cur[0].score, t[1], v[0], v[1], cn); }
	}
	if (doneStep < 0) {
		// best effort: report
		fprintf(stderr, "no solution found (best score %.0f)\n", cur[0].score);
		return 1;
	}
	// backtrack
	int path[400], pn = 0, idx = -1;
	for (int i = 0; i < hn[doneStep]; i++) if (hist[doneStep][i].key == 0 || 1) { /* find first with score best */ }
	// the node `done` was index in nxt before sorting: find it by tut_active == 0: it is hist with best score
	idx = 0; for (int i = 0; i < hn[doneStep]; i++) if (hist[doneStep][i].score >= hist[doneStep][idx].score) idx = i;
	for (int s = doneStep; s >= 0; s--) { path[pn++] = hist[s][idx].act; idx = hist[s][idx].parent; }
	FILE* f = fopen(outfile, "w");
	for (int i = pn - 1; i >= 0; i--) {
		unsigned k = act_keys(path[i]); char b[16]; int n = 0;
		if (k & 1) b[n++] = 'L'; if (k & 2) b[n++] = 'R'; if (k & 4) b[n++] = 'U'; if (k & 8) b[n++] = 'D';
		if (k & 16) b[n++] = 'J'; if (k & 32) b[n++] = 'X'; if (k & 128) b[n++] = 'G'; b[n] = 0;
		fprintf(f, "hold %d %s\n", MACRO, n ? b : "-");
	}
	fclose(f);
	fprintf(stderr, "solution: %d macro steps (%d ticks)\n", pn, pn * MACRO);
	return 0;
}

int main(int argc, char** argv) {
	plan_nodash = getenv("PLAN_NODASH") != NULL; plan_nograb = getenv("PLAN_NOGRAB") != NULL; celeste_h_noballoon = getenv("PLAN_NOBALLOON") != NULL;
	if (getenv("PLAN_STOP")) plan_stop = atoi(getenv("PLAN_STOP"));
	if (argc < 5) { fprintf(stderr, "usage\n"); return 1; }
	FILE* f = fopen(argv[1], "rb"); if (!f || fread(gfx, 1, 128*128, f) == 0) return 2; fclose(f);
	f = fopen(argv[2], "rb"); if (!f || fread(font, 1, 128*128, f) == 0) return 2; fclose(f);
	int coop = !strcmp(argv[3], "coop");
	Celeste_P8_set_call_func(cb);
	Celeste_P8_set_rndseed(12345);
	Celeste_P8_set_wide_pad(VOX);
	Celeste_P8_set_menu_mode(0);
	Celeste_P8_set_pad_icons(1);
	Celeste_P8_set_coop(coop);
	Celeste_P8_init();
	keys1 = 16; tick(); keys1 = 0;
	for (int i = 0; i < 300 && !Celeste_P8_in_tutorial(); i++) tick();
	if (!Celeste_P8_in_tutorial()) fprintf(stderr, "tutorial did not start\n");

	{ float v[9]; keys1 = keys2 = 0; for (int i = 0; i < 300 && !Celeste_H_player(0, v); i++) tick(); }
	if (!strcmp(argv[4], "plan")) return plan(argv[5], argc > 6 ? atoi(argv[6]) : 60, getenv("PLAN_STEPS") ? atoi(getenv("PLAN_STEPS")) : 150);
	FILE* sc = fopen(argv[4], "r");
	char line[512];
	while (sc && fgets(line, sizeof line, sc)) {
		char a[256], b[256]; int n, m;
		if (sscanf(line, "hold %d %255s", &n, a) >= 1) {
			char k1[64] = "", k2[64] = "";
			// keys: upper case for player 1, lower for player 2 in the same word
			keys1 = parse_keys(a, 0); keys2 = parse_keys(a, 1);
			(void)k1; (void)k2;
			for (int i = 0; i < n; i++) tick();
		} else if (sscanf(line, "wait %d", &n) == 1) {
			keys1 = keys2 = 0; for (int i = 0; i < n; i++) tick();
		} else if (sscanf(line, "tp %d %255s", &n, a) == 2) {
			int pid = n; float x = atof(a), y = 0; char* sp = strchr(line + 3, ' '); sp = sp ? strchr(sp + 1, ' ') : NULL; if (sp) y = atof(sp + 1);
			Celeste_H_tp(pid, x, y);
		} else if (!strncmp(line, "status", 6)) {
			float v[9]; int t[16]; Celeste_H_tut(t);
			printf("tut active=%d stage=%d deaths=%d rev=%d fuse=%d exit=%d cp=%d fusetimer=%d victim=%d\n", t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8]);
			for (int p = 0; p < 2; p++) if (Celeste_H_player(p, v)) printf(" p%d x=%.0f y=%.0f sx=%.2f sy=%.2f dj=%.0f bubble=%.0f\n", p, v[0], v[1], v[2], v[3], v[4], v[5]);
		} else if (sscanf(line, "snap %255s", b) == 1) {
			snap(b);
		}
		(void)m;
	}
	return 0;
}
