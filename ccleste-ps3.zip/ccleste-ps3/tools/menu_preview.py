#!/usr/bin/env python3
"""Builds tools/menu_preview.c, renders the animated scene and writes a GIF + contact sheet.
   python3 tools/menu_preview.py [outdir]"""
import os, sys, subprocess, glob
from PIL import Image
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = sys.argv[1] if len(sys.argv) > 1 else '/tmp/menuprev'
os.makedirs(out, exist_ok=True)
for f in glob.glob(out + '/f*.ppm'): os.remove(f)
subprocess.check_call(['gcc', '-O2', '-Wall', '-I' + root, '-o', out + '/menu_preview', os.path.join(root, 'tools/menu_preview.c'), '-lm'])
subprocess.check_call([out + '/menu_preview', os.path.join(root, 'data/menu_art.bin'), out, '0', '12', '0.0333333', '3'])
files = sorted(glob.glob(out + '/f*.ppm'))
frames = [Image.open(f).convert('RGB') for f in files]
frames[0].save(out + '/anim.gif', save_all=True, append_images=frames[::1][1:], duration=33, loop=0)
sheet = Image.new('RGB', (456 * 3, 256 * 3))
for i, k in enumerate([6, 20, 40, 75, 100, 140, 180, 230, 300]):
    sheet.paste(frames[min(k, len(frames) - 1)], ((i % 3) * 456, (i // 3) * 256))
sheet.save(out + '/sheet.png')
print(len(frames), 'frames ->', out)
