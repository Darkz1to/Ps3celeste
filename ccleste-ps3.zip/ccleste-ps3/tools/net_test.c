// Headless test of the online co-op lockstep (PC only, no SDL).
//
//   python3 tools/relay.py 17777 --public 127.0.0.1:17777 &
//   gcc -O1 -I. tools/net_test.c celeste.c -lm -o net_test && ./net_test 17777
//
// Forks two "consoles": the host connects to the relay and receives a CODE; the guest decodes that code
// and joins. Each one runs the REAL game (celeste.c) for
// TICKS ticks with random-looking inputs and random network jitter, and prints the final state
// hash. Both must print the same hash and no desync may be reported.
#define _GNU_SOURCE
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include "celeste.h"
#include "net.inc.c"
#include "tilemap.h"

#define TICKS 2400

static unsigned g_buttons;   // player 1 buttons for the current tick (btn())

static int cb(CELESTE_P8_CALLBACK_TYPE t, ...) {
	va_list ap; va_start(ap, t);
	int ret = 0;
	switch (t) {
		case CELESTE_P8_BTN: {
			int b = va_arg(ap, int);
			ret = b == 7 ? ((g_buttons >> 10) & 1) : ((g_buttons >> b) & 1);
		} break;
		case CELESTE_P8_MGET: {
			int tx = va_arg(ap, int), ty = va_arg(ap, int);
			ret = tilemap_data[tx + ty * 128];
		} break;
		case CELESTE_P8_FGET: {
			int tile = va_arg(ap, int), flag = va_arg(ap, int);
			ret = tile < (int)(sizeof tile_flags / sizeof *tile_flags) && (tile_flags[tile] & (1 << flag)) != 0;
		} break;
		default: break;
	}
	va_end(ap);
	return ret;
}

static unsigned rng_state;
static unsigned rnd(void) { rng_state = rng_state * 1664525u + 1013904223u; return rng_state >> 8; }

// host: connects to 127.0.0.1 and reports the code through code_fd; guest: joins with `code`
static int run_console(int port, int id, const char* code, int code_fd, int ticks, int jitter, unsigned* out_hash, int* out_desync, int* out_role) {
	if (code == NULL) {
		int ip[4] = { 127, 0, 0, 1 };
		net_begin_host(ip, port);
	} else {
		net_begin_join(code);
	}
	int st = net_st, sent_code = 0;
	for (int i = 0; i < 4000; i++) {
		st = net_menu_poll();
		if (code == NULL && !sent_code && net_code_text()[0]) {
			char buf[24] = {0};
			strncpy(buf, net_code_text(), 23);
			if (write(code_fd, buf, sizeof buf) != (ssize_t)sizeof buf) return 1;
			sent_code = 1;
		}
		if (st == NET_ST_READY) break;
		if (st >= NET_ST_FIRST_ERR) { fprintf(stderr, "console %d: net error %d\n", id, st); return 1; }
		usleep(5000);
	}
	if (st != NET_ST_READY) { fprintf(stderr, "console %d: never paired\n", id); return 1; }

	Celeste_P8_set_call_func(cb);
	Celeste_P8_set_rndseed(net_seed());
	Celeste_P8_init();
	Celeste_P8_set_coop(1);

	rng_state = 1234u + (unsigned)id * 777u;   // different "pad" on each console
	srand((unsigned)id * 99u + 5u);
	unsigned last_input = 0;
	int stalls = 0;
	for (int done = 0; done < ticks;) {
		// the pad changes now and then (like a human), always something different per console
		if (rnd() % 7 == 0) {
			last_input = 0;
			if (rnd() % 3) last_input |= (rnd() % 2) ? 1u : 2u;       // left / right
			if (rnd() % 5 == 0) last_input |= 4u;                      // up
			if (rnd() % 4 == 0) last_input |= 1u << 4;                 // jump
			if (rnd() % 6 == 0) last_input |= 1u << 5;                 // dash
			if (rnd() % 9 == 0) last_input |= 0x40u;                   // merge
			if (rnd() % 8 == 0) last_input |= 0x80u;                   // grab
		}
		unsigned in_host = 0, in_guest = 0;
		int r = net_step(last_input, &in_host, &in_guest);
		if (r < 0) { fprintf(stderr, "console %d: lost at tick %d\n", id, done); return 1; }
		if (r == 0) { stalls++; usleep(1000); continue; }
#ifdef CORRUPT
		if (id == 1 && done >= 500 && done < 800) { in_guest ^= 0xFF; in_host ^= 0x3F; }   // negative test: one console sees different inputs
#endif
		g_buttons = (in_host & 0x3F) | ((in_host & 0x80) ? (1u << 10) : 0u);
		Celeste_P8_set_coop_input((in_host >> 6) & 1, in_guest & 0xFF);
		Celeste_P8_update();
		Celeste_P8_draw();
		net_after_tick(Celeste_P8_sync_hash());
		done++;
		if (jitter && rnd() % 10 == 0) usleep(1000 + rnd() % 15000);   // up to 16 ms of "lag" now and then
	}
	// give the last hash frames time to cross
	for (int i = 0; i < 200; i++) { net_pump(); usleep(1000); }
	*out_hash = Celeste_P8_sync_hash();
	*out_desync = net_is_desync();
	*out_role = net_role();
	{ Celeste_P8_progress_t p; Celeste_P8_get_progress(&p);
	  fprintf(stderr, "console %d: role=%d stalls=%d room=%d,%d deaths=%d\n", id, net_role(), stalls, p.room_x, p.room_y, p.deaths); }
	net_close();
	return 0;
}

// joins with `code` and returns the final NET_ST_* state seen (used for the error cases)
static int try_join(const char* code) {
	net_begin_join(code);
	int st = net_st;
	for (int i = 0; i < 400 && st != NET_ST_READY && st < NET_ST_FIRST_ERR; i++) { st = net_menu_poll(); usleep(5000); }
	net_cancel();
	return st;
}

int main(int argc, char** argv) {
	int port = argc > 1 ? atoi(argv[1]) : 17777;
	int jitter = argc > 2 ? atoi(argv[2]) : 1;
	int cpipe[2], rpipe[2][2];
	if (pipe(cpipe) != 0 || pipe(rpipe[0]) != 0 || pipe(rpipe[1]) != 0) return 2;
	pid_t pids[2];

	// 1) host: connects, gets the code
	pids[0] = fork();
	if (pids[0] == 0) {
		unsigned h = 0; int ds = 0, role = -1;
		int rc = run_console(port, 0, NULL, cpipe[1], TICKS, 0, &h, &ds, &role);
		unsigned msg[4] = { (unsigned)rc, h, (unsigned)ds, (unsigned)role };
		if (write(rpipe[0][1], msg, sizeof msg) != (ssize_t)sizeof msg) _exit(3);
		_exit(0);
	}
	char code[24] = {0};
	if (read(cpipe[0], code, sizeof code) != (ssize_t)sizeof code) { printf("FAIL: host never got a code\n"); return 1; }
	printf("code from the relay: %s\n", code);

	// 2) a mistyped code must be refused locally, an unknown room by the relay
	char bad[24]; strcpy(bad, code); bad[2] = bad[2] == 'A' ? 'B' : 'A';
	int st_bad = try_join(bad);
	printf("mistyped code      -> state %d (expected %d = invalid code)\n", st_bad, NET_ST_ERR_CODE);

	// 3) guest joins with the real code
	pids[1] = fork();
	if (pids[1] == 0) {
		unsigned h = 0; int ds = 0, role = -1;
		int rc = run_console(port, 1, code, -1, TICKS, jitter, &h, &ds, &role);
		unsigned msg[4] = { (unsigned)rc, h, (unsigned)ds, (unsigned)role };
		if (write(rpipe[1][1], msg, sizeof msg) != (ssize_t)sizeof msg) _exit(3);
		_exit(0);
	}
	unsigned res[2][4];
	for (int i = 0; i < 2; i++) {
		if (read(rpipe[i][0], res[i], sizeof res[i]) != (ssize_t)sizeof res[i]) { printf("FAIL: console %d died\n", i); return 1; }
		int status; waitpid(pids[i], &status, 0);
	}
	// 4) the room worked once: the same code must not work again
	int st_reuse = try_join(code);
	printf("reused code        -> state %d (expected %d = room not valid)\n", st_reuse, NET_ST_ERR_ROOM);

	printf("console0: rc=%u hash=%08x desync=%u role=%u\n", res[0][0], res[0][1], res[0][2], res[0][3]);
	printf("console1: rc=%u hash=%08x desync=%u role=%u\n", res[1][0], res[1][1], res[1][2], res[1][3]);
	int ok = !res[0][0] && !res[1][0] && res[0][1] == res[1][1] && !res[0][2] && !res[1][2] && res[0][3] == 0 && res[1][3] == 1
		&& st_bad == NET_ST_ERR_CODE && st_reuse == NET_ST_ERR_ROOM;
	printf(ok ? "PASS: both consoles ended in the same state after %d ticks\n" : "FAIL\n", TICKS);
	return ok ? 0 : 1;
}
