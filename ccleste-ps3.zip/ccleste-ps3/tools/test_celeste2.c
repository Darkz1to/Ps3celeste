// headless test of the altar + chapter 2 (needs /home/claude/gfx.raw and font.raw: raw 8-bit pixels of data/gfx.bmp and font.bmp). build: gcc -fsanitize=address,undefined -I. tools/test_celeste2.c -lm
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include "celeste.c"
#include "tilemap.h"
#include <stdio.h>
#define VW 228
#define VH 128
#define VOX 50
static unsigned char gfx[128*192], font[128*128], fb[VW*VH];
static int palx[16], cam_ux=0, cam_uy=0, scr_x=0, scr_y=0;
static unsigned keys=0;
static const unsigned char bp[16][3]={{0,0,0},{0x1d,0x2b,0x53},{0x7e,0x25,0x53},{0,0x87,0x51},{0xab,0x52,0x36},{0x5f,0x57,0x4f},{0xc2,0xc3,0xc7},{0xff,0xf1,0xe8},{0xff,0,0x4d},{0xff,0xa3,0},{0xff,0xec,0x27},{0,0xe4,0x36},{0x29,0xad,0xff},{0x83,0x76,0x9c},{0xff,0x77,0xa8},{0xff,0xcc,0xaa}};
static int CX(void){return cam_ux+scr_x-VOX;} static int CY(void){return cam_uy+scr_y;}
static void px(int x,int y,int c){x-=CX();y-=CY(); if(x>=0&&y>=0&&x<VW&&y<VH) fb[y*VW+x]=c;}
static int sprdraws=0, badspr=0;
static void spr_(int s,int x,int y,int fx,int fy){ if(s<0)return; if(s>=384){badspr++;return;} sprdraws++; int sx=8*(s%16),sy=8*(s/16);
 for(int j=0;j<8;j++)for(int i=0;i<8;i++){int c=gfx[(sy+(fy?7-j:j))*128+sx+(fx?7-i:i)]; if(c)px(x+i,y+j,palx[c]);}}
static void rf(int x0,int y0,int x1,int y1,int c){for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++)px(x,y,palx[c&15]);}
static void pr(const char*s,int x,int y,int col){for(;*s;s++,x+=4){int c=*s&0x7f,sx=8*(c%16),sy=8*(c/16);for(int j=0;j<8;j++)for(int i=0;i<8;i++)if(font[(sy+j)*128+sx+i])px(x+i,y+j,palx[col&15]);}}
static int cbk(CELESTE_P8_CALLBACK_TYPE call,...){va_list a;va_start(a,call);int ret=0;
 switch(call){
 case CELESTE_P8_MUSIC:case CELESTE_P8_SFX:break;
 case CELESTE_P8_SPR:{int s=va_arg(a,int),x=va_arg(a,int),y=va_arg(a,int);va_arg(a,int);va_arg(a,int);int fx=va_arg(a,int),fy=va_arg(a,int);spr_(s,x,y,fx,fy);}break;
 case CELESTE_P8_BTN:{int b=va_arg(a,int);ret=(keys>>b)&1;}break;
 case CELESTE_P8_PAL:{int p=va_arg(a,int),q=va_arg(a,int);if(p>=0&&p<16&&q>=0&&q<16)palx[p]=q;}break;
 case CELESTE_P8_PAL_RESET:for(int i=0;i<16;i++)palx[i]=i;break;
 case CELESTE_P8_CIRCFILL:{int cx=va_arg(a,int),cy=va_arg(a,int),r=va_arg(a,int),c=va_arg(a,int);for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(x*x+y*y<=r*r+r/2)rf(cx+x,cy+y,cx+x,cy+y,c);}break;
 case CELESTE_P8_PRINT:{const char*s=va_arg(a,const char*);int x=va_arg(a,int),y=va_arg(a,int),c=va_arg(a,int);pr(s,x,y,c);}break;
 case CELESTE_P8_RECTFILL:{int x0=va_arg(a,int),y0=va_arg(a,int),x1=va_arg(a,int),y1=va_arg(a,int),c=va_arg(a,int);rf(x0,y0,x1,y1,c);}break;
 case CELESTE_P8_LINE:{int x0=va_arg(a,int),y0=va_arg(a,int),x1=va_arg(a,int),y1=va_arg(a,int),c=va_arg(a,int);
   int dx=abs(x1-x0),dy=-abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1,e=dx+dy;for(;;){rf(x0,y0,x0,y0,c);if(x0==x1&&y0==y1)break;int e2=2*e;if(e2>=dy){e+=dy;x0+=sx;}if(e2<=dx){e+=dx;y0+=sy;}}}break;
 case CELESTE_P8_MGET:{int x=va_arg(a,int),y=va_arg(a,int);ret=tilemap_data[x+y*128];}break;
 case CELESTE_P8_CAMERA:{cam_ux=va_arg(a,int);cam_uy=va_arg(a,int);}break;
 case CELESTE_P8_SCROLL:{scr_x=va_arg(a,int);scr_y=va_arg(a,int);}break;
 case CELESTE_P8_FGET:{int t=va_arg(a,int),f=va_arg(a,int);ret=t<(int)sizeof tile_flags&&(tile_flags[t]&(1<<f))!=0;}break;
 case CELESTE_P8_MAP:{int mx=va_arg(a,int),my=va_arg(a,int),tx=va_arg(a,int),ty=va_arg(a,int),mw=va_arg(a,int),mh=va_arg(a,int),mask=va_arg(a,int);
  for(int x=0;x<mw;x++)for(int y=0;y<mh;y++){int t=tilemap_data[x+mx+(y+my)*128];int fl=t<(int)sizeof tile_flags&&mask!=0&&(tile_flags[t]&(1<<(mask!=4?mask-1:mask)));
   if(mask==0||(mask==4&&tile_flags[t]==4)||fl)spr_(t,tx+x*8,ty+y*8,0,0);}}break;
 }
 va_end(a);return ret;}
static void snap(const char*f){for(int i=0;i<VW*VH;i++)fb[i]=0;scr_x=scr_y=0;cam_ux=cam_uy=0;for(int i=0;i<16;i++)palx[i]=i;
 // the frontend never clears: draw fills. emulate by black start
 Celeste_P8_draw();FILE*o=fopen(f,"wb");fprintf(o,"P6\n%d %d\n255\n",VW,VH);for(int i=0;i<VW*VH;i++)fwrite(bp[fb[i]],1,3,o);fclose(o);}
static void tk(int n){for(int i=0;i<n;i++)Celeste_P8_update();}
int main(int argc,char**argv){
 FILE*f=fopen("/home/claude/gfx.raw","rb");fread(gfx,1,sizeof gfx,f);fclose(f);f=fopen("/home/claude/font.raw","rb");fread(font,1,sizeof font,f);fclose(f);
 Celeste_P8_set_call_func(cbk);Celeste_P8_set_rndseed(1234);Celeste_P8_set_wide_pad(VOX);Celeste_P8_init();
 const char*mode=argc>1?argv[1]:"altar";
 if(!strcmp(mode,"altar")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);
  tk(60);
  OBJ*fl=altar_find(OBJ_FLAG);OBJ*pl=altar_find(OBJ_PLAYER);
  printf("flag=%p player=%p level_index=%d\n",(void*)fl,(void*)pl,level_index());
  if(!fl||!pl)return 1;
  printf("flag at %.0f,%.0f player at %.0f,%.0f\n",fl->x,fl->y,pl->x,pl->y);
  pl->x=fl->x;pl->y=fl->y;pl->spd.x=pl->spd.y=0;tk(3);
  snap("/tmp/a0_touch.ppm");
  printf("show=%d ready=%d\n",fl->show,altar_ready(fl,pl));
  keys=1<<2; tk(14); printf("hold=%d\n",altar_hold); snap("/tmp/a1_hold.ppm");
  {int g=0;while(altar_anim==0&&g<200){tk(1);g++;} printf("anim started after +%d ticks, hold=%d anim=%d\n",g,altar_hold,altar_anim);}
  int shots[]={10,25,45,60,75,90,100,104};int si=0;int n=0;
  while(altar_anim>0){tk(1);n++; if(si<8&&n==shots[si]){char nm[64];sprintf(nm,"/tmp/a2_anim%d.ppm",shots[si]);snap(nm);si++;}}
  printf("anim done after %d ticks, c2_active=%d level=%d\n",n,c2_active,c2s.level);
  keys=0;tk(2);snap("/tmp/a3_c2_start.ppm");tk(30);snap("/tmp/a4_c2_after.ppm");
  // release test
 } else if(!strcmp(mode,"intro")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin();c2_goto_level(3);tk(20);snap("/tmp/i_en.ppm");Celeste_P8_set_language(1);c2_goto_level(8);tk(20);snap("/tmp/i_pt8.ppm");c2_goto_level(5);tk(20);snap("/tmp/i_pt5.ppm");
 } else {
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin();
  for(int lv=1;lv<=8;lv++){
   c2_goto_level(lv); tk(130); // past intro card
   snap((char[]){'/','t','m','p','/','l','v',(char)('0'+lv),'.','p','p','m',0});
   // wander: alternate keys
   for(int t=0;t<900;t++){ keys=((t/40)%2?2:1)|(((t/15)%3==0)?(1<<4):0)|(((t/50)%4==3)?(1<<5):0)|(((t/70)%5==0)?4:0); tk(1); if(t%300==299)Celeste_P8_draw(); }
   keys=0; printf("level %d ok: player=%d dead? deaths=%d cam=(%d,%d)\n",lv,c2s.player,deaths,c2s.cam_x,c2s.cam_y);
  }
  printf("sprites drawn %d, out-of-range sprites %d\n",sprdraws,badspr);
 }
 return 0;}
