// headless test of the altar, the prologue and chapter 2 (modes: altar levels pt lessons climb film video). Needs /home/claude/gfx.raw and font.raw (raw 8-bit pixels of data/gfx.bmp and font.bmp). build: gcc -O2 -I. tools/test_celeste2.c -lm
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include "celeste.c"
#include "tilemap.h"
#include <stdio.h>
#define VW 228
#define VH 128
#define VOX 50
static unsigned char gfx[128*256], font[128*128], fb[VW*VH];
static int palx[16], cam_ux=0, cam_uy=0, scr_x=0, scr_y=0;
static unsigned keys=0;
static const unsigned char bp[16][3]={{0,0,0},{0x1d,0x2b,0x53},{0x7e,0x25,0x53},{0,0x87,0x51},{0xab,0x52,0x36},{0x5f,0x57,0x4f},{0xc2,0xc3,0xc7},{0xff,0xf1,0xe8},{0xff,0,0x4d},{0xff,0xa3,0},{0xff,0xec,0x27},{0,0xe4,0x36},{0x29,0xad,0xff},{0x83,0x76,0x9c},{0xff,0x77,0xa8},{0xff,0xcc,0xaa}};
static int CX(void){return cam_ux+scr_x-VOX;} static int CY(void){return cam_uy+scr_y;}
static void px(int x,int y,int c){x-=CX();y-=CY(); if(x>=0&&y>=0&&x<VW&&y<VH) fb[y*VW+x]=c;}
static int sprdraws=0, badspr=0;
static void spr_(int s,int x,int y,int fx,int fy,int cols,int rows){ if(s<0)return; if(s>=512){badspr++;return;} sprdraws++; int sx=8*(s%16),sy=8*(s/16);
 int W=8*cols,Hh=8*rows;
 for(int j=0;j<Hh;j++)for(int i=0;i<W;i++){int c=gfx[(sy+(fy?Hh-1-j:j))*128+sx+(fx?W-1-i:i)]; if(c)px(x+i,y+j,palx[c]);}}
static void rf(int x0,int y0,int x1,int y1,int c){for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++)px(x,y,palx[c&15]);}
static void pr(const char*s,int x,int y,int col){for(;*s;s++,x+=4){int c=*s&0x7f,sx=8*(c%16),sy=8*(c/16);for(int j=0;j<8;j++)for(int i=0;i<8;i++)if(font[(sy+j)*128+sx+i])px(x+i,y+j,palx[col&15]);}}
static int cbk(CELESTE_P8_CALLBACK_TYPE call,...){va_list a;va_start(a,call);int ret=0;
 switch(call){
 case CELESTE_P8_MUSIC:case CELESTE_P8_SFX:break;
 case CELESTE_P8_SPR:{int s=va_arg(a,int),x=va_arg(a,int),y=va_arg(a,int);int cc=va_arg(a,int),rr=va_arg(a,int);int fx=va_arg(a,int),fy=va_arg(a,int);spr_(s,x,y,fx,fy,cc,rr);}break;
 case CELESTE_P8_BTN:{int b=va_arg(a,int);ret=(keys>>b)&1;}break;
 case CELESTE_P8_PAL:{int p=va_arg(a,int),q=va_arg(a,int);if(p>=0&&p<16&&q>=0&&q<16)palx[p]=q;}break;
 case CELESTE_P8_PAL_RESET:for(int i=0;i<16;i++)palx[i]=i;break;
 case CELESTE_P8_CIRCFILL:{int cx=va_arg(a,int),cy=va_arg(a,int),r=va_arg(a,int),c=va_arg(a,int);for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(x*x+y*y<=r*r+r/2)rf(cx+x,cy+y,cx+x,cy+y,c);}break;
 case CELESTE_P8_PRINT:{const char*s=va_arg(a,const char*);int x=va_arg(a,int),y=va_arg(a,int),c=va_arg(a,int);pr(s,x,y,c);}break;
 case CELESTE_P8_RECTFILL:{int x0=va_arg(a,int),y0=va_arg(a,int),x1=va_arg(a,int),y1=va_arg(a,int),c=va_arg(a,int);rf(x0,y0,x1,y1,c);}break;
 case CELESTE_P8_LINE:{int x0=va_arg(a,int),y0=va_arg(a,int),x1=va_arg(a,int),y1=va_arg(a,int),c=va_arg(a,int);
   int dx=abs(x1-x0),dy=-abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1,e=dx+dy;for(;;){rf(x0,y0,x0,y0,c);if(x0==x1&&y0==y1)break;int e2=2*e;if(e2>=dy){e+=dy;x0+=sx;}if(e2<=dx){e+=dx;y0+=sy;}}}break;
 case CELESTE_P8_MGET:{int x=va_arg(a,int),y=va_arg(a,int);ret=tilemap_data[x+y*128];}break;
 case CELESTE_P8_CAMERA:{cam_ux=va_arg(a,int);cam_uy=va_arg(a,int);}break;
 case CELESTE_P8_SCROLL:{scr_x=va_arg(a,int);scr_y=va_arg(a,int);}break;
 case CELESTE_P8_FGET:{int t=va_arg(a,int),f=va_arg(a,int);ret=t<(int)sizeof tile_flags&&(tile_flags[t]&(1<<f))!=0;}break;
 case CELESTE_P8_MAP:{int mx=va_arg(a,int),my=va_arg(a,int),tx=va_arg(a,int),ty=va_arg(a,int),mw=va_arg(a,int),mh=va_arg(a,int),mask=va_arg(a,int);
  for(int x=0;x<mw;x++)for(int y=0;y<mh;y++){int t=tilemap_data[x+mx+(y+my)*128];int fl=t<(int)sizeof tile_flags&&mask!=0&&(tile_flags[t]&(1<<(mask!=4?mask-1:mask)));
   if(mask==0||(mask==4&&tile_flags[t]==4)||fl)spr_(t,tx+x*8,ty+y*8,0,0,1,1);}}break;
 }
 va_end(a);return ret;}
static void snap(const char*f){for(int i=0;i<VW*VH;i++)fb[i]=0;scr_x=scr_y=0;cam_ux=cam_uy=0;for(int i=0;i<16;i++)palx[i]=i;
 // the frontend never clears: draw fills. emulate by black start
 Celeste_P8_draw();FILE*o=fopen(f,"wb");fprintf(o,"P6\n%d %d\n255\n",VW,VH);for(int i=0;i<VW*VH;i++)fwrite(bp[fb[i]],1,3,o);fclose(o);}
static void tk(int n){for(int i=0;i<n;i++)Celeste_P8_update();}

typedef struct {C2STATE s; unsigned char*h; float sc;} BEAM;
static int goal_door(C2OBJ*p){return p->y<=PT_CABIN_DOOR_Y+1 && p->x>=PT_CABIN_DOOR_X-8 && p->grounded;}
static float score_climb(C2OBJ*p){return -2.0f*p->y+(p->y<300?p->x:0);}
// returns number of ticks of the solution (history in *out) or -1
static int beam_solve(const unsigned char*acts,int na,int maxt,int BWd,unsigned char**out){
  BEAM*cur=malloc(sizeof(BEAM)*BWd),*nxt=malloc(sizeof(BEAM)*BWd*na);
  static C2STATE s0; memcpy(&s0,&c2s,sizeof s0);
  memcpy(&cur[0].s,&c2s,sizeof s0); cur[0].h=calloc(maxt,1); int nc=1; unsigned char*best=NULL;int bestn=-1;
  static char seen[1024*600*2];
  for(int t=0;t<maxt&&!best;t++){
    int nn=0;
    for(int i=0;i<nc&&!best;i++)for(int a=0;a<na;a++){
      memcpy(&c2s,&cur[i].s,sizeof(C2STATE)); keys=acts[a]; Celeste_P8_update();
      C2OBJ*pl=&c2s.obj[c2s.player>=0?c2s.player:0];
      if(c2s.player<0||pl->state>=C2S_DEAD||c2s.pt_step!=8)continue;
      if(goal_door(pl)){best=malloc(maxt);memcpy(best,cur[i].h,maxt);best[t]=a;bestn=t+1;break;}
      memcpy(&nxt[nn].s,&c2s,sizeof(C2STATE)); nxt[nn].sc=score_climb(pl); nxt[nn].h=(unsigned char*)(size_t)(i*32+a); nn++;
    }
    if(best)break;
    int*idx=malloc(sizeof(int)*nn); for(int k=0;k<nn;k++)idx[k]=k;
    // partial sort desc
    for(int x=0;x<nn;x++){int m=x;for(int y=x+1;y<nn;y++)if(nxt[idx[y]].sc>nxt[idx[m]].sc)m=y;int tmp=idx[x];idx[x]=idx[m];idx[m]=tmp; if(x>BWd*8)break;}
    memset(seen,0,sizeof seen); BEAM*nc_=malloc(sizeof(BEAM)*BWd); int keep=0; static int rowc[600]; memset(rowc,0,sizeof rowc);
    for(int k=0;k<nn&&k<=BWd*8&&keep<BWd;k++){
      BEAM*e=&nxt[idx[k]]; C2OBJ*pl=&e->s.obj[e->s.player]; int bx=(int)pl->x/2,by=(int)pl->y/2; if(bx<0)bx=0;if(bx>1023)bx=1023;if(by<0)by=0;if(by>599)by=599;
      int key=(bx*600+by)*2+(pl->grounded?1:0); if(seen[key])continue; int rr=(int)pl->y/8; if(rr<0)rr=0; if(rr>599)rr=599; if(rowc[rr]>=BWd/18)continue; rowc[rr]++; seen[key]=1;
      size_t pa=(size_t)e->h; int pi=(int)(pa/32),ac=(int)(pa%32);
      memcpy(&nc_[keep].s,&e->s,sizeof(C2STATE)); nc_[keep].sc=e->sc; nc_[keep].h=malloc(maxt); memcpy(nc_[keep].h,cur[pi].h,maxt); nc_[keep].h[t]=ac; keep++;
    }
    free(idx); for(int i=0;i<nc;i++)free(cur[i].h); memcpy(cur,nc_,sizeof(BEAM)*keep); free(nc_); nc=keep;
    if(t%100==0&&nc){C2OBJ*pl=&cur[0].s.obj[cur[0].s.player];printf("  beam t=%d n=%d best x=%.0f y=%.0f\n",t,nc,pl->x,pl->y);fflush(stdout);}
    if(!nc)break;
  }
  memcpy(&c2s,&s0,sizeof s0);
  *out=best; return bestn;
}
int main(int argc,char**argv){
 FILE*f=fopen("/home/claude/gfx.raw","rb");fread(gfx,1,sizeof gfx,f);fclose(f);f=fopen("/home/claude/font.raw","rb");fread(font,1,sizeof font,f);fclose(f);
 Celeste_P8_set_call_func(cbk);Celeste_P8_set_rndseed(1234);Celeste_P8_set_wide_pad(VOX);Celeste_P8_init();
 const char*mode=argc>1?argv[1]:"altar";
 if(!strcmp(mode,"altar")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);
  tk(60);
  OBJ*fl=altar_find(OBJ_FLAG);OBJ*pl=altar_find(OBJ_PLAYER);
  printf("flag=%p player=%p level_index=%d\n",(void*)fl,(void*)pl,level_index());
  if(!fl||!pl)return 1;
  printf("flag at %.0f,%.0f player at %.0f,%.0f\n",fl->x,fl->y,pl->x,pl->y);
  pl->x=fl->x;pl->y=fl->y;pl->spd.x=pl->spd.y=0;tk(3);
  snap("/tmp/a0_touch.ppm");
  printf("show=%d ready=%d\n",fl->show,altar_ready(fl,pl));
  keys=1<<2; tk(14); printf("hold=%d\n",altar_hold); snap("/tmp/a1_hold.ppm");
  {int g=0;while(altar_anim==0&&g<200){tk(1);g++;} printf("anim started after +%d ticks, hold=%d anim=%d\n",g,altar_hold,altar_anim);}
  int shots[]={10,25,45,60,75,90,100,104};int si=0;int n=0;
  while(altar_anim>0){tk(1);n++; if(si<8&&n==shots[si]){char nm[64];sprintf(nm,"/tmp/a2_anim%d.ppm",shots[si]);snap(nm);si++;}}
  printf("anim done after %d ticks, c2_active=%d level=%d\n",n,c2_active,c2s.level);
  keys=0;tk(2);snap("/tmp/a3_c2_start.ppm");tk(30);snap("/tmp/a4_c2_after.ppm");
  // release test


 } else if(!strcmp(mode,"video")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin(); tk(2);
  typedef struct {C2STATE s; unsigned char*h; float sc;} BE;
  enum{BW=260,MAXT=1800};
  BE*cur=malloc(sizeof(BE)*BW),*nxt=malloc(sizeof(BE)*BW*6);
  static C2STATE c2s0; memcpy(&c2s0,&c2s,sizeof c2s0);
  int nc=1; memcpy(&cur[0].s,&c2s,sizeof(C2STATE)); cur[0].h=calloc(MAXT,1);
  static const unsigned char acts[6]={2,2|16,1,1|16,0,16};
  unsigned char*best=NULL;int bestn=-1;
  for(int t=0;t<MAXT&&!best;t++){
    int nn=0;
    for(int i=0;i<nc&&!best;i++)for(int a=0;a<6;a++){
      memcpy(&c2s,&cur[i].s,sizeof(C2STATE)); keys=acts[a]; Celeste_P8_update();
      C2OBJ*pl=&c2s.obj[c2s.player>=0?c2s.player:0];
      int done=(c2s.level!=1)||(c2s.player>=0&&pl->state==C2S_EXIT);
      if(done){best=malloc(MAXT);memcpy(best,cur[i].h,MAXT);best[t]=a;bestn=t+1;break;}
      if(c2s.player<0||pl->state==C2S_DEAD)continue;
      memcpy(&nxt[nn].s,&c2s,sizeof(C2STATE)); nxt[nn].h=NULL; nxt[nn].sc=pl->x - 0.1f*pl->y; 
      nxt[nn].h=(unsigned char*)(size_t)i; // parent index temporarily
      nxt[nn].sc+=0; ((unsigned char*)&nxt[nn].s)[0]=((unsigned char*)&nxt[nn].s)[0];
      // remember action in a side array
      static unsigned char act_of[BW*6]; act_of[nn]=a; nxt[nn].h=(unsigned char*)(size_t)(i*8+a);
      nn++;
    }
    if(best)break;
    // dedupe by position bucket, keep best scores
    static char seen[512*160*2]; memset(seen,0,sizeof seen);
    int idx[BW*6],ni=0;
    for(int k=0;k<nn;k++){ // selection sort on score (desc) lazily via qsort-like
      idx[ni++]=k; }
    // sort idx by score desc
    for(int x=0;x<ni;x++)for(int y=x+1;y<ni&&x<BW;y++) if(nxt[idx[y]].sc>nxt[idx[x]].sc){int tmp=idx[x];idx[x]=idx[y];idx[y]=tmp;}
    int keep=0; BE*nc_=malloc(sizeof(BE)*BW);
    for(int k=0;k<ni&&keep<BW;k++){
      BE*e=&nxt[idx[k]]; C2OBJ*pl=&e->s.obj[e->s.player]; int bx=(int)pl->x,by=(int)pl->y; if(bx<0)bx=0;if(bx>511)bx=511;if(by<0)by=0;if(by>159)by=159;
      int key=(bx*160+by)*2+(pl->grounded?1:0); if(seen[key])continue; seen[key]=1;
      size_t pa=(size_t)e->h; int pi=(int)(pa/8),ac=(int)(pa%8);
      memcpy(&nc_[keep].s,&e->s,sizeof(C2STATE)); nc_[keep].sc=e->sc;
      nc_[keep].h=malloc(MAXT); memcpy(nc_[keep].h,cur[pi].h,MAXT); nc_[keep].h[t]=ac; keep++;
    }
    for(int i=0;i<nc;i++)free(cur[i].h);
    memcpy(cur,nc_,sizeof(BE)*keep); free(nc_); nc=keep;
    if(t%100==0){C2OBJ*pl=&cur[0].s.obj[cur[0].s.player];printf("t=%d beam=%d best x=%.0f y=%.0f\n",t,nc,pl->x,pl->y);fflush(stdout);}
    if(nc==0){printf("beam died\n");return 1;}
  }
  if(!best){printf("no solution\n");return 1;}
  printf("solution: %d ticks\n",bestn);
  for(int rep=0;rep<2;rep++){memcpy(&c2s,&c2s0,sizeof c2s0);for(int t=0;t<bestn;t++){keys=acts[best[t]];tk(1); if(t==60||t==150||t==250)printf(" rep%d t=%d x=%.1f y=%.1f\n",rep,t,c2s.obj[c2s.player].x,c2s.obj[c2s.player].y);} printf(" rep%d end level=%d\n",rep,c2s.level);}
  // replay from the same start
  memcpy(&c2s,&c2s0,sizeof c2s0);
  system("rm -rf /tmp/vid; mkdir -p /tmp/vid"); int fn=0,after=0;
  for(int t=0;t<bestn+240;t++){ keys=t<bestn?acts[best[t]]:0; tk(1); static C2STATE sv; memcpy(&sv,&c2s,sizeof sv); char nm[64];sprintf(nm,"/tmp/vid/f%04d.ppm",fn++);snap(nm); memcpy(&c2s,&sv,sizeof sv); if(c2s.level>=2&&++after>60)break; }
  {C2OBJ*q=&c2s.obj[c2s.player>=0?c2s.player:0];printf("replay: %d frames level=%d px=%.0f py=%.0f state=%d wipe=%d\n",fn,c2s.level,q->x,q->y,q->state,q->wipe_timer);}

 } else if(!strcmp(mode,"pt")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  Celeste_P8_set_language(getenv("PTLANG")?1:0); c2_begin(); tk(40); snap("/tmp/p0_start.ppm");
  C2OBJ*pl=&c2s.obj[c2s.player]; printf("player %.0f,%.0f level %d cam %d,%d\n",pl->x,pl->y,c2s.level,c2s.cam_x,c2s.cam_y);
  pl->x=PT_LADY1_X-14; pl->y=PT_LADY1_Y; pl->sx=0; tk(10); snap("/tmp/p1_near.ppm");
  keys=4; tk(1); keys=0; tk(30); printf("step %d dlg %d\n",c2s.pt_step,c2s.pt_dlg); snap("/tmp/p2_dlg.ppm");
  keys=16; tk(1); keys=0; tk(60); snap("/tmp/p2b_dlg.ppm");
  for(int i=0;i<12&&c2s.pt_dlg;i++){keys=16;tk(1);keys=0;tk(50);} printf("after dlg1: step %d\n",c2s.pt_step);
  tk(20); snap("/tmp/p3_give.ppm"); tk(40); snap("/tmp/p3b_give.ppm"); tk(120); printf("step %d state %d\n",c2s.pt_step,pl->state);
  for(int i=0;i<10&&c2s.pt_dlg;i++){tk(60);{char nm_[40];sprintf(nm_,"/tmp/p4_dlg2_%d.ppm",i);snap(nm_);}keys=16;tk(1);keys=0;tk(30);} printf("lesson step %d\n",c2s.pt_step);
  tk(10); snap("/tmp/p5_lesson1.ppm"); c2s.pt_step=5; tk(2); snap("/tmp/p6_lesson2.ppm"); c2s.pt_step=6; tk(2); snap("/tmp/p7_lesson3.ppm");

 } else if(!strcmp(mode,"lessons")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin(); tk(30); c2s.pt_step=4; c2s.have_grapple=true; c2s.pt_hook=0;
  C2OBJ*pl=&c2s.obj[c2s.player];
  // lesson 1: hook the right wall 3 times
  for(int n=0;n<4;n++){ keys=2; tk(3); keys=2|32; tk(14); keys=0; tk(40); printf("n=%d hook=%d step=%d x=%.0f y=%.0f st=%d\n",n,c2s.pt_hook,c2s.pt_step,pl->x,pl->y,pl->state); }
  // lesson 2: hook then jump
  for(int n=0;n<4&&c2s.pt_step==5;n++){ pl->x=96;pl->y=544;pl->sx=pl->sy=0; tk(6); keys=2|32; tk(8); keys=2|32|16; tk(2); keys=0; tk(40); printf("jump n=%d jumps=%d step=%d x=%.0f y=%.0f\n",n,c2s.pt_jump,c2s.pt_step,pl->x,pl->y); }
  // lesson 3: hold on the wall
  snap("/tmp/l3_a.ppm");
  for(int n=0;n<2&&c2s.pt_step==6;n++){ pl->x=96;pl->y=544;pl->sx=pl->sy=0; tk(6); keys=2|32; tk(30); snap("/tmp/l3_b.ppm"); tk(60); printf("cling n=%d hold=%d step=%d st=%d x=%.0f y=%.0f\n",n,c2s.pt_hold,c2s.pt_step,pl->state,pl->x,pl->y); keys=0; tk(30);}
  tk(40); printf("gate open=%d step=%d\n",c2s.pt_gate_open,c2s.pt_step); snap("/tmp/l4_gate.ppm"); tk(60); snap("/tmp/l5_open.ppm");

 } else if(!strcmp(mode,"climb")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin(); tk(30); c2s.pt_step=8; c2s.pt_gate_open=true; c2s.have_grapple=true;
  static const unsigned char acts[]={0,2,1,16,2|16,1|16,32,2|32,1|32,16|32,2|16|32,1|16|32,4,2|4};
  unsigned char*sol=NULL; int n=beam_solve(acts,sizeof acts,1500,300,&sol);
  printf("climb solution: %d ticks\n",n);
  if(n>0){ for(int t=0;t<n;t++){keys=acts[sol[t]];tk(1);} C2OBJ*pl=&c2s.obj[c2s.player]; printf("end %.0f,%.0f gr=%d step=%d\n",pl->x,pl->y,pl->grounded,c2s.pt_step); }

 } else if(!strcmp(mode,"film")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin();
  FILE*ff=popen("ffmpeg -y -loglevel error -f rawvideo -pix_fmt rgb24 -s 228x128 -r 30 -i - -vf scale=912:512:flags=neighbor,format=yuv420p -c:v libx264 -crf 20 /mnt/user-data/outputs/prologo_celeste2.mp4","w");
  #define CAP() do{ static C2STATE sv_; memcpy(&sv_,&c2s,sizeof sv_); for(int i_=0;i_<VW*VH;i_++)fb[i_]=0; scr_x=scr_y=0;cam_ux=cam_uy=0;for(int i_=0;i_<16;i_++)palx[i_]=i_; Celeste_P8_draw(); for(int i_=0;i_<VW*VH;i_++)fwrite(bp[fb[i_]],1,3,ff); memcpy(&c2s,&sv_,sizeof sv_);}while(0)
  #define RUN(k,n) do{ for(int r_=0;r_<(n);r_++){ keys=(k); tk(1); CAP(); } }while(0)
  #define STILL(nm) do{ snap(nm); }while(0)
  C2OBJ*pl;
  RUN(0,45); pl=&c2s.obj[c2s.player];
  for(int i=0;i<150&&!pt_near_lady(pl);i++) RUN(2,1);
  RUN(0,12); STILL("/tmp/f1_talk.ppm"); RUN(4,2); RUN(0,10);
  for(int i=0;i<30&&c2s.pt_dlg;i++){ RUN(0,50); if(i==1)STILL("/tmp/f2_dlg.ppm"); RUN(16,2); RUN(0,4);}
  for(int i=0;i<500&&c2s.pt_step==2;i++) { RUN(0,1); if(i==60)STILL("/tmp/f3_give.ppm"); }
  for(int i=0;i<500&&c2s.pt_step<3;i++) RUN(0,1);
  for(int i=0;i<30&&c2s.pt_dlg;i++){ RUN(0,50); RUN(16,2); RUN(0,4);}
  printf("lessons start: step %d\n",c2s.pt_step);
  RUN(0,10);
  for(int n=0;n<8&&c2s.pt_step==4;n++){ for(int g=0;g<60&&pl->x>102;g++)RUN(1,1); RUN(2,3); RUN(2|32,14); RUN(0,30); }
  STILL("/tmp/f4_l2.ppm");
  for(int n=0;n<8&&c2s.pt_step==5;n++){ for(int g=0;g<60&&pl->x>102;g++)RUN(1,1); RUN(2,3); RUN(2|32,8); RUN(2|32|16,2); RUN(0,40); }
  for(int n=0;n<6&&c2s.pt_step==6;n++){ for(int g=0;g<60&&pl->x>102;g++)RUN(1,1); RUN(2,3); RUN(2|32,110); if(n==0)STILL("/tmp/f5_cling.ppm"); RUN(0,20); }
  for(int i=0;i<300&&c2s.pt_step<8;i++){ RUN(0,1); if(i==40)STILL("/tmp/f6_gate.ppm"); }
  for(int g=0;g<80&&pl->x>104;g++)RUN(1,1); RUN(0,15); printf("climb start: step %d x=%.0f y=%.0f\n",c2s.pt_step,pl->x,pl->y);
  static const unsigned char acts[]={0,2,1,16,2|16,1|16,32,2|32,1|32,16|32,2|16|32,1|16|32,4,2|4};
  unsigned char*sol=NULL; int n=beam_solve(acts,sizeof acts,1500,200,&sol); printf("climb: %d ticks\n",n);
  if(n<=0){pclose(ff);return 1;}
  for(int t=0;t<n;t++){ RUN(acts[sol[t]],1); if(t==n/3)STILL("/tmp/f7_climb.ppm"); }
  RUN(0,15); STILL("/tmp/f8_door.ppm"); RUN(4,2); RUN(0,60); STILL("/tmp/f9_inside.ppm");
  printf("inside=%d step=%d\n",c2s.pt_inside,c2s.pt_step);
  for(int i=0;i<200&&!pt_near_lady(pl);i++) RUN(2,1);
  RUN(0,10); RUN(4,2); RUN(0,10);
  for(int i=0;i<30&&c2s.pt_dlg;i++){ RUN(0,50); if(i==0)STILL("/tmp/f10_dlg3.ppm"); RUN(16,2); RUN(0,4);}
  for(int i=0;i<400&&c2s.pt_step<13;i++){ RUN(0,1); if(i==30)STILL("/tmp/f11_take.ppm"); }
  RUN(0,90); STILL("/tmp/f12_free.ppm");
  for(int i=0;i<300&&c2s.level==0;i++) RUN(2,1);
  RUN(0,70); STILL("/tmp/f13_lv1.ppm");
  printf("film done: level=%d\n",c2s.level);
  pclose(ff);
 } else if(!strcmp(mode,"jump")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin();tk(60);
  C2OBJ*pl=&c2s.obj[c2s.player];printf("start %.1f,%.1f state %d grounded %d\n",pl->x,pl->y,pl->state,pl->grounded);
  float miny=1e9;keys=2;tk(40);printf("after walk %.1f,%.1f\n",pl->x,pl->y);
  keys=2|16;for(int i=0;i<40;i++){tk(1);if(pl->y<miny)miny=pl->y; if(i%4==0)printf("i%d y=%.1f x=%.1f\n",i,pl->y,pl->x);if(i==22)keys=2;}
  printf("min y %.1f\n",miny);
 } else if(!strcmp(mode,"intro")){
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin();c2_goto_level(3);tk(20);snap("/tmp/i_en.ppm");Celeste_P8_set_language(1);c2_goto_level(8);tk(20);snap("/tmp/i_pt8.ppm");c2_goto_level(5);tk(20);snap("/tmp/i_pt5.ppm");
 } else {
  Celeste_P8_progress_t p;memset(&p,0,sizeof p);p.room_x=6;p.room_y=3;p.max_djump=1;Celeste_P8_load_progress(&p);tk(5);
  c2_begin();
  for(int lv=1;lv<=8;lv++){
   c2_goto_level(lv); tk(130); // past intro card
   snap((char[]){'/','t','m','p','/','l','v',(char)('0'+lv),'.','p','p','m',0});
   // wander: alternate keys
   for(int t=0;t<900;t++){ keys=((t/40)%2?2:1)|(((t/15)%3==0)?(1<<4):0)|(((t/50)%4==3)?(1<<5):0)|(((t/70)%5==0)?4:0); tk(1); if(t%300==299)Celeste_P8_draw(); }
   keys=0; printf("level %d ok: player=%d dead? deaths=%d cam=(%d,%d)\n",lv,c2s.player,deaths,c2s.cam_x,c2s.cam_y);
  }
  printf("sprites drawn %d, out-of-range sprites %d\n",sprdraws,badspr);
 }
 return 0;}
