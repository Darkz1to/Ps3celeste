// Headless preview of the HD renderer (not part of the game build): runs celeste.c, draws through hdgfx.inc.h.
//   python3 tools/hd_preview.py          (builds this and writes PNGs to /tmp/hdprev)
//   gcc -O1 -I. -o hd_preview tools/hd_preview.c celeste.c -lm
//   ./hd_preview gfx.raw 256 512 font.raw 256 170 out_prefix  rx,ry,ticks ...
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stddef.h>
#include "celeste.h"
#include "tilemap.h"
#include "hdgfx.inc.h"

#define VW 228
#define VH 128
#define VOX 50
#define SW (VW*HD_S)
#define SH (VH*HD_S)
static unsigned char *gfxs, *fonts; static int gw, gh, fw, fh;
static uint32_t fb[SW*SH], fin[SW*SH];
static hd_surf S = { fb, SW, SW, SH };
static int cam_x = 0, cam_y = 0;

static int tileflag(int t, int f) { return t < (int)sizeof tile_flags && (tile_flags[t] & (1<<f)) != 0; }

static int cb(CELESTE_P8_CALLBACK_TYPE call, ...) {
	va_list a; va_start(a, call);
	int ret = 0;
	switch (call) {
		case CELESTE_P8_SPR: { int s = va_arg(a,int), x = va_arg(a,int), y = va_arg(a,int); va_arg(a,int); va_arg(a,int);
			int fx = va_arg(a,int), fy = va_arg(a,int);
			if (s >= 0) hd_blit(&S, gfxs, gw, gh, 16*(s%16), 16*(s/16), 16, 16, (x-cam_x)*HD_S, (y-cam_y)*HD_S, fx, fy, 0); } break;
		case CELESTE_P8_BTN: ret = 0; break;
		case CELESTE_P8_PAL: { int p = va_arg(a,int), q = va_arg(a,int); hd_pal(p, q); } break;
		case CELESTE_P8_PAL_RESET: hd_pal_reset(); break;
		case CELESTE_P8_CIRCFILL: { int cx = va_arg(a,int) - cam_x, cy = va_arg(a,int) - cam_y, r = va_arg(a,int), c = va_arg(a,int);
			hd_ball(&S, cx, cy, r, c & 15); } break;
		case CELESTE_P8_PRINT: { const char* s = va_arg(a,const char*); int x = va_arg(a,int) - cam_x, y = va_arg(a,int) - cam_y, c = va_arg(a,int) % 16;
			for (; *s; s++, x += 4) { int ch = *s & 0x7f; hd_blit(&S, fonts, fw, fh, 16*(ch%16), 16*(ch/16), 16, 16, x*HD_S, y*HD_S, 0, 0, c); } } break;
		case CELESTE_P8_RECTFILL: { int x0 = va_arg(a,int) - cam_x, y0 = va_arg(a,int) - cam_y, x1 = va_arg(a,int) - cam_x, y1 = va_arg(a,int) - cam_y, c = va_arg(a,int);
			hd_fill(&S, x0*HD_S, y0*HD_S, (x1-x0+1)*HD_S, (y1-y0+1)*HD_S, hd_col(c, 8)); } break;
		case CELESTE_P8_LINE: { int x0 = va_arg(a,int) - cam_x, y0 = va_arg(a,int) - cam_y, x1 = va_arg(a,int) - cam_x, y1 = va_arg(a,int) - cam_y, c = va_arg(a,int);
			if (x0 == x1) hd_fill(&S, x0*HD_S, y0*HD_S, HD_S, (y1-y0)*HD_S, hd_col(c, 8));
			else if (y0 == y1) hd_fill(&S, x0*HD_S, y0*HD_S, (x1-x0)*HD_S, HD_S, hd_col(c, 8)); } break;
		case CELESTE_P8_MGET: { int x = va_arg(a,int), y = va_arg(a,int); ret = tilemap_data[x + y*128]; } break;
		case CELESTE_P8_CAMERA: break;
		case CELESTE_P8_FGET: { int t = va_arg(a,int), f = va_arg(a,int); ret = tileflag(t, f); } break;
		case CELESTE_P8_MAP: { int mx = va_arg(a,int), my = va_arg(a,int), tx = va_arg(a,int), ty = va_arg(a,int), mw = va_arg(a,int), mh = va_arg(a,int), mask = va_arg(a,int);
			for (int x = 0; x < mw; x++) for (int y = 0; y < mh; y++) {
				int t = tilemap_data[x+mx + (y+my)*128];
				if (mask == 0 || (mask == 4 && tile_flags[t] == 4) || tileflag(t, mask != 4 ? mask-1 : mask))
					hd_blit(&S, gfxs, gw, gh, 16*(t%16), 16*(t/16), 16, 16, (tx + x*8 - cam_x)*HD_S, (ty + y*8 - cam_y)*HD_S, 0, 0, 0);
			} } break;
		case CELESTE_P8_HD: {
			int op = va_arg(a,int), p1 = va_arg(a,int), p2 = va_arg(a,int), p3 = va_arg(a,int), p4 = va_arg(a,int), p5 = va_arg(a,int);
			switch (op) {
				case CELESTE_HD_QUERY: ret = 1; break;
				case CELESTE_HD_BACKDROP: hd_backdrop(&S, p1, p2, p3, p4); break;
				case CELESTE_HD_CLOUD: { int x = (p1-cam_x)*HD_S, y = (p2-cam_y)*HD_S, w = p3*HD_S, h = p4*HD_S + 6;
					if (p5 == 0) hd_puff(&S, x, y, w, h, 0x2b3b80, 0x5870c0, 64); else hd_puff(&S, x, y, w, h, 0xc8497a, 0xff9fc2, 58); } break;
				case CELESTE_HD_PARTICLE: { int x = (p1-cam_x)*HD_S, y = (p2-cam_y)*HD_S, n = (p3+1)*HD_S;
					hd_glow(&S, x+n/2, y+n/2, n*3, 0xa0b8ff, 60); hd_fill(&S, x, y, n, n, hd_col(p4, 12)); } break;
				case CELESTE_HD_SPARK: { int x = (p1-cam_x)*HD_S, y = (p2-cam_y)*HD_S, n = (p3/5)*HD_S + HD_S;
					hd_glow(&S, x, y, n*4, 0xff77a8, 200); hd_fill(&S, x-n/2, y-n/2, n, n, hd_col(p4, 12)); } break;
				case CELESTE_HD_GLOW: { static const uint32_t gc[6] = { 0xffc896, 0xff3c6e, 0xffc828, 0x50c8ff, 0xffffff, 0x3cff78 };
					hd_glow(&S, (p1-cam_x)*HD_S+1, (p2-cam_y)*HD_S+1, p3*HD_S, gc[p4 % 6], p5); } break;
			}
		} break;
		default: break;
	}
	va_end(a);
	return ret;
}

static unsigned char* readraw(const char* p, int n) { unsigned char* b = malloc(n); FILE* f = fopen(p, "rb"); if (!f || fread(b, 1, n, f) != (size_t)n) { fprintf(stderr, "cannot read %s\n", p); exit(2); } fclose(f); return b; }

int main(int argc, char** argv) {
	if (argc < 9) return 1;
	gw = atoi(argv[2]); gh = atoi(argv[3]); fw = atoi(argv[5]); fh = atoi(argv[6]);
	gfxs = readraw(argv[1], gw*gh); fonts = readraw(argv[4], fw*fh);
	hd_init();
	Celeste_P8_set_call_func(cb);
	Celeste_P8_set_rndseed(12345);
	Celeste_P8_set_wide_pad(VOX);
	Celeste_P8_set_menu_mode(0);
	Celeste_P8_set_tutorial_enabled(0);
	Celeste_P8_init();
	for (int i = 8; i < argc; i++) {
		int rx, ry, ticks;
		if (sscanf(argv[i], "%d,%d,%d", &rx, &ry, &ticks) != 3) continue;
		Celeste_P8_progress_t p; memset(&p, 0, sizeof p); p.room_x = rx; p.room_y = ry; p.max_djump = 1;
		if (Celeste_P8_load_progress(&p) != 0) { fprintf(stderr, "bad room %d,%d\n", rx, ry); continue; }
		for (int t = 0; t < ticks; t++) Celeste_P8_update();
		cam_x = -VOX; cam_y = 0;
		hd_pal_reset();
		memset(fb, 0, sizeof fb);
		Celeste_P8_draw();
		hd_vignette(fin, fb, SW, SH, SW, 120);
		char name[512]; snprintf(name, sizeof name, "%s_%d_%d.ppm", argv[7], rx, ry);
		FILE* f = fopen(name, "wb"); fprintf(f, "P6\n%d %d\n255\n", SW, SH);
		for (int k = 0; k < SW*SH; k++) { unsigned char c[3] = { fin[k] >> 16, fin[k] >> 8, fin[k] }; fwrite(c, 1, 3, f); }
		fclose(f);
	}
	return 0;
}
