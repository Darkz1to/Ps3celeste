# colour ramps shared by the atlas generator (must match HD_RAMP in hdgfx.h, which is
# generated from this file by make_hd_atlas.py)
import numpy as np
# (dark, mid, light) per PICO-8 palette index; 8 shades are interpolated: 0..4 dark->mid, 4..7 mid->light
BASE = {
 0:((4,6,14),(8,10,24),(16,20,40)),
 1:((8,12,30),(22,34,74),(46,64,116)),
 2:((50,16,50),(110,40,90),(160,70,120)),
 3:((8,44,40),(22,104,74),(80,172,104)),
 4:((58,32,30),(128,72,52),(190,122,82)),
 6:((104,114,148),(176,188,214),(226,233,247)),
 7:((120,150,204),(214,230,248),(255,255,255)),
 8:((130,16,36),(226,52,48),(255,132,96)),
 9:((150,70,10),(250,160,20),(255,212,96)),
 10:((190,140,10),(255,230,60),(255,250,170)),
 11:((10,110,40),(40,210,80),(150,255,150)),
 12:((16,84,196),(48,168,255),(176,232,255)),
 13:((58,54,98),(131,118,156),(192,182,216)),
 14:((190,60,110),(255,119,168),(255,192,216)),
 15:((188,108,92),(255,204,170),(255,236,216)),
}
# rock (5) is a mossy stone: explicit 8 shades
ROCK=[(7,13,19),(11,22,27),(16,32,34),(22,42,40),(30,56,44),(48,82,54),(80,120,68),(114,158,88)]
def ramp(i):
    if i==5: return [tuple(c) for c in ROCK]
    d,m,l=[np.array(c,float) for c in BASE[i]]
    out=[]
    for s in range(8):
        if s<=4: c=d+(m-d)*(s/4)
        else: c=m+(l-m)*((s-4)/3)
        out.append(tuple(int(round(v)) for v in c))
    return out
RAMPS=[ramp(i) for i in range(16)]
