// tutorial.inc.c -- included by celeste.c
//
// A short tutorial level that plays before level 1 when a new game starts (solo and co-op).
// It is its own 16:9 map (28x16 tiles, grass theme, see tools/gen_tutorial_map.py) that does not
// use the 16x16 rooms of the original map. Everything is drawn in "room" coordinates like the rest
// of the game: tile column 0 is at x = TUT_X0 (-48), so the 228 px wide view is filled.
//
// Course (left to right on the bottom, then right to left on the strip above):
//   spawn -> jump (mound, pit) -> dash (gap) -> wall grab (stone pillar) -> balloon (wide gap)
//   -> strawberry -> [co-op: revive a bubble, fusion] -> portal to level 1
// A banner at the top explains what to do; its text follows the player(s) (the one that is
// furthest behind, so nobody misses a lesson).

// ---- text -----------------------------------------------------------------------------------
// markers inside the strings: [j] jump  [d] dash  [g] grab  [m] merge  [p] d-pad
enum {
	TP_WELCOME, TP_JUMP, TP_DASH, TP_WALL, TP_BALLOON, TP_BERRY, TP_EXIT_SOLO,
	TP_REV_PRE, TP_REV_BUBBLE, TP_REV_DONE, TP_FUSE_PRE, TP_FUSE_DONE, TP_EXIT_COOP, TP_WELCOME_COOP,
	TP_COUNT
};
//         title            line 1                                            line 2
static const char* const tut_txt[TP_COUNT][2][3] = {
	[TP_WELCOME] = {
		{ "welcome to celeste!", "this is a short tutorial. move with [p].", "walk right to begin. skip: pause menu." },
		{ "bem-vindo ao celeste!", "este e um tutorial rapido. ande com [p].", "va para a direita. pular: menu de pausa." } },
	[TP_WELCOME_COOP] = {
		{ "welcome, you two!", "this tutorial is for 2 players. move with [p].", "walk right to begin. skip: pause menu." },
		{ "bem-vindos, voces dois!", "tutorial para 2 jogadores. andem com [p].", "vao para a direita. pular: menu de pausa." } },
	[TP_JUMP] = {
		{ "jump", "press [j] to jump over blocks and small gaps.", "you can still jump just after leaving a ledge." },
		{ "pulo", "aperte [j] para pular blocos e buracos pequenos.", "da para pular logo depois de sair da borda." } },
	[TP_DASH] = {
		{ "dash", "press [d] to dash where you point [p].", "one dash per jump: land to refill it." },
		{ "dash", "aperte [d] para dar um dash na direcao do [p].", "um dash por vez: pise no chao para recarregar." } },
	[TP_WALL] = {
		{ "wall grab", "hold [g] on a wall to grab it. up/down climbs.", "stamina runs out (you blink red). [j] = wall jump." },
		{ "agarrar na parede", "segure [g] na parede. cima/baixo escala.", "a forca acaba (pisca vermelho). [j] = pulo de parede." } },
	[TP_BALLOON] = {
		{ "balloons", "touch a balloon in mid-air to refill your dash.", "it comes back after a few seconds. use it to cross." },
		{ "baloes", "toque num balao no ar para recarregar o dash.", "ele volta em alguns segundos. use para atravessar." } },
	[TP_BERRY] = {
		{ "strawberries", "strawberries are optional, but fun to collect!", "they refill your dash. winged ones flee if you dash." },
		{ "morangos", "morangos sao opcionais, mas e divertido pegar!", "eles recarregam o dash. os alados fogem do dash." } },
	[TP_EXIT_SOLO] = {
		{ "ready!", "that is all. enter the portal to start the climb.", "good luck!" },
		{ "pronto!", "e so isso! entre no portal para comecar a subida.", "boa sorte!" } },
	[TP_REV_PRE] = {
		{ "co-op: bubbles", "if one of you dies, that player turns into a bubble.", "stay close... one of you is about to pop!" },
		{ "coop: bolhas", "se um de voces morrer, vira uma bolha.", "fiquem perto... um de voces vai estourar!" } },
	[TP_REV_BUBBLE] = {
		{ "player %d is a bubble!", "float with [p]. partner: dash [d] into it!", "reviving works like this in every level." },
		{ "jogador %d virou bolha!", "flutue com [p]. parceiro: dash [d] nela!", "reviver funciona assim em todas as fases." } },
	[TP_REV_DONE] = {
		{ "revived!", "nice teamwork! the vines opened. go left.", "both of your dashes are refilled." },
		{ "reviveu!", "bom trabalho! os cipos abriram. va a esquerda.", "o dash dos dois foi recarregado." } },
	[TP_FUSE_PRE] = {
		{ "fusion", "both hold [m] to charge the bar and fuse.", "fused: 2 dashes each and rgb hair for 10 s." },
		{ "fusao", "os dois seguram [m] para carregar e se fundir.", "fundidos: 2 dashes cada e cabelo rgb por 10 s." } },
	[TP_FUSE_DONE] = {
		{ "fused!", "double dash for both. the vines opened.", "use it on hard spots, then keep going left." },
		{ "fundidos!", "dash duplo para os dois. os cipos abriram.", "use em lugares dificeis e siga a esquerda." } },
	[TP_EXIT_COOP] = {
		{ "ready!", "both: enter the portal to start the climb.", "good luck!" },
		{ "prontos!", "os dois: entrem no portal para comecar.", "boa sorte!" } },
};

// ---- state (part of the saved game state, see LISTGVARS) -------------------------------------
static int tut_t = 0;               // ticks since the tutorial began
static int tut_cp = 0;              // checkpoint (where the players respawn)
static int tut_prog[2];             // furthest stage reached by each player
static int tut_stage = 0;           // stage shown (the lowest of the living players)
static int tut_rev = 0;             // co-op revive lesson: 0 waiting, 1 bubble out, 2 done
static int tut_rev_timer = 0;
static int tut_victim = 0;
static int tut_fuse = 0;            // co-op fusion lesson: 1 = they fused once
static int tut_exit_t = 0;          // > 0: the portal is taking the players away
static int tut_page = -1;           // page shown by the banner
static int tut_type_t = 0;          // typewriter clock of the banner
static int tut_flash = 0;           // banner border flash after a page change
static char tut_grid[TUT_H][TUT_W];

// frontend settings (not part of the game state)
static int tut_pad_icons = 0;       // 1: draw the PlayStation symbols, 0: draw key caps
static char tut_keys[5][8] = { "Z", "X", "D", "T", "ARROWS" };   // jump, dash, grab, merge, d-pad

// ---- map ---------------------------------------------------------------------------------------
static int tut_fdiv8(int v) { return v >= 0 ? v / 8 : -((-v + 7) / 8); }

static bool tut_cell_solid(int c, int r) {
	if (c < 0 || c >= TUT_W) return true;      // the side walls go on forever
	if (r < 0) return true;
	if (r >= TUT_H) return false;              // the pits: falling out of the screen kills
	return tut_grid[r][c] != '.';
}
//terrain only (the vines count as air for the autotiling, so the grass under them stays visible)
static bool tut_cell_terrain(int c, int r) {
	if (c < 0 || c >= TUT_W || r < 0 || r >= TUT_H) return true;
	return tut_grid[r][c] == 'G' || tut_grid[r][c] == 'S';
}

static bool tut_flag_at(int x, int y, int w, int h, int flag) {
	if (flag != 0) return false;               // no ice, no other tile flags
	const int c0 = tut_fdiv8(x - TUT_X0), c1 = tut_fdiv8(x + w - 1 - TUT_X0);
	const int r0 = tut_fdiv8(y), r1 = tut_fdiv8(y + h - 1);
	for (int c = c0; c <= c1; c++)
		for (int r = r0; r <= r1; r++)
			if (tut_cell_solid(c, r)) return true;
	return false;
}

// where the players respawn: column, row of the sprite's top left tile
static const struct { int col, row; } tut_cp_pos[] = {
	{ 3, 13 },                  // 0 start
	{ 20, 13 },                 // 1 after the gap
	{ 25, TUT_T2_ROW - 1 },     // 2 top of the stone steps
	{ 14, TUT_T2_ROW - 1 },     // 3 after the balloon gap
	{ 10, TUT_T2_ROW - 1 },     // 4 revive done (co-op)
	{ 6, TUT_T2_ROW - 1 },      // 5 fusion done (co-op)
};
#define TUT_CP_N 6

#define TUT_BALLOON_X  (TUT_X0 + 19*8 + 4)   // between the two sides of the wide gap
#define TUT_T2_Y       (TUT_T2_ROW*8)   // y of the upper strip's surface
#define TUT_BALLOON_Y  (TUT_T2_Y - 12)
#define TUT_BERRY_X    (TUT_X0 + 13*8)
#define TUT_BERRY_Y    (TUT_T2_Y - 22)
#define TUT_PORTAL_X   (TUT_X0 + 2*8)         // centre of the portal
#define TUT_GATE_A     9
#define TUT_GATE_B     5
#define TUT_RUNE_A_X   (TUT_X0 + 11*8 + 4)    // revive pad
#define TUT_RUNE_B_X   (TUT_X0 + 7*8 + 4)     // fusion pad

static void tut_open_gate(int col) {
	for (int r = 1; r < TUT_T2_ROW; r++) {
		if (tut_grid[r][col] != '#') continue;
		tut_grid[r][col] = '.';
		if (coop) coop_burst(TUT_X0 + col*8 + 4, r*8 + 4, 1, (r % 2) ? 11 : 3, 1.5f);
	}
	P8sfx(51);
	shake = 5;
}

static void tut_load(void) {
	for (int r = 0; r < TUT_H; r++)
		for (int c = 0; c < TUT_W; c++) {
			char ch = tut_map_rows[r][c];
			if (ch == '#' && !coop) ch = '.';          // the vines are only for the co-op lessons
			tut_grid[r][c] = ch;
		}
	if (tut_rev == 1) tut_rev = 0;                      // both died while the bubble was out: again
	tut_rev_timer = 0;
	tut_exit_t = 0;
	if (coop) {
		if (tut_rev >= 2) tut_open_gate(TUT_GATE_A);
		if (tut_fuse >= 1) tut_open_gate(TUT_GATE_B);
	}
	shake = 0;
	int cp = tut_cp < 0 ? 0 : tut_cp >= TUT_CP_N ? TUT_CP_N - 1 : tut_cp;
	init_object(OBJ_PLAYER_SPAWN, TUT_X0 + tut_cp_pos[cp].col*8, tut_cp_pos[cp].row*8);
#ifdef CELESTE_HARNESS
	extern int celeste_h_noballoon;
	if (!celeste_h_noballoon)
#endif
	init_object(OBJ_BALLOON, TUT_BALLOON_X, TUT_BALLOON_Y);
	init_object(OBJ_FRUIT, TUT_BERRY_X, TUT_BERRY_Y);
	if (coop) coop_spawn_second();
	tut_page = -1;
	tut_type_t = 0;
}

static void tut_begin(void) {
	tut_active = true;
	tut_t = 0; tut_cp = 0; tut_stage = 0;
	tut_prog[0] = tut_prog[1] = 0;
	tut_rev = 0; tut_fuse = 0; tut_victim = 0;
	load_room(0, 0);
}

//leaves the tutorial: level 1 starts with a clean score, like a new game
static void tut_finish(void) {
	tut_active = false;
	deaths = 0;
	frames = 0; seconds = 0; minutes = 0;
	music_timer = 0;
	has_dashed = false;
	will_restart = false; delay_restart = 0;
	freeze = 0; shake = 0;
	pause_player = false;
	coop_clear();
	for (int i = 0; i < 17; i++) { clouds[i].x = P8rnd(128); }
	load_room(0, 0);
}

// ---- logic ------------------------------------------------------------------------------------
//how far along the course a player is; only goes up (see tut_update)
static int tut_stage_of(const OBJ* o) {
	const int cx = tut_fdiv8((int)o->x + 4 - TUT_X0);
	if ((int)o->y > TUT_T2_Y + 6) {         // bottom strip (or climbing the steps)
		if (cx < 5) return 0;
		if (cx < 13) return 1;
		if (cx < 20) return 2;
		return 3;
	}
	if (cx >= 16) return 4;
	if (cx >= 13) return 5;
	if (!coop) return 6;
	if (cx >= 10) return 6;
	if (cx >= 6) return 7;
	return 8;
}

static int tut_current_page(void) {
	switch (tut_stage) {
		case 0: return coop ? TP_WELCOME_COOP : TP_WELCOME;
		case 1: return TP_JUMP;
		case 2: return TP_DASH;
		case 3: return TP_WALL;
		case 4: return TP_BALLOON;
		case 5: return TP_BERRY;
		case 6:
			if (!coop) return TP_EXIT_SOLO;
			return tut_rev == 0 ? TP_REV_PRE : tut_rev == 1 ? TP_REV_BUBBLE : TP_REV_DONE;
		case 7: return tut_fuse ? TP_FUSE_DONE : TP_FUSE_PRE;
		default: return TP_EXIT_COOP;
	}
}

static void tut_update(void) {
	if (!tut_active) return;
	tut_t++;
	if (tut_flash > 0) tut_flash--;

	OBJ* pl[2] = { coop_find(0), coop_find(1) };
	const int n_players = coop ? 2 : 1;
	int living = 0, low = 99;
	for (int i = 0; i < n_players; i++) {
		OBJ* p = pl[i];
		if (!p || p->bubble) continue;
		const int s = tut_stage_of(p);
		if (s > tut_prog[i]) tut_prog[i] = s;
		living++;
		if (tut_prog[i] < low) low = tut_prog[i];
	}
	if (living > 0) tut_stage = low;

	//checkpoints
	int cp = tut_cp;
	if (tut_stage >= 3 && cp < 1) cp = 1;
	if (tut_stage >= 4 && cp < 2) cp = 2;
	if (tut_stage >= 5 && cp < 3) cp = 3;
	if (coop && tut_rev >= 2 && cp < 4) cp = 4;
	if (coop && tut_fuse >= 1 && cp < 5) cp = 5;
	tut_cp = cp;

	if (coop) {
		//1) revive: once both stand near the first pad, one of them pops
		if (tut_rev == 0 && living == 2 && tut_stage == 6) {
			if (++tut_rev_timer >= 70) {
				tut_victim = (int)P8rnd(2);
				if (tut_victim > 1) tut_victim = 1;
				OBJ* v = pl[tut_victim];
				if (v && coop_try_bubble(v)) tut_rev = 1;
				else tut_rev_timer = 40;
			}
		} else if (tut_rev == 0) {
			tut_rev_timer = 0;
		}
		if (tut_rev == 1 && pl[0] && pl[1] && !pl[0]->bubble && !pl[1]->bubble) {
			tut_rev = 2;
			tut_open_gate(TUT_GATE_A);
		}
		//2) fusion
		if (tut_rev >= 2 && !tut_fuse && fuse_timer > 0) {
			tut_fuse = 1;
			tut_open_gate(TUT_GATE_B);
		}
	}

	//3) the portal: everybody that is alive has to be there
	if (tut_exit_t > 0) {
		if (++tut_exit_t >= 50) tut_finish();
		return;
	}
	if (living == n_players && (coop ? (tut_rev >= 2 && tut_fuse >= 1) : tut_stage >= 6)) {
		bool all = true;
		for (int i = 0; i < n_players; i++) {
			OBJ* p = pl[i];
			if (!p) { all = false; break; }
			const float dx = p->x + 4 - TUT_PORTAL_X, dy = p->y + 4 - (TUT_T2_Y - 12);
			if (dx < -13 || dx > 13 || dy < -15 || dy > 15) all = false;
		}
		if (all) {
			tut_exit_t = 1;
			P8sfx(55);
			sfx_timer = 30;
			shake = 6;
		}
	}
}

// ---- drawing ----------------------------------------------------------------------------------
static int tut_hash(int c, int r) {
	unsigned h = (unsigned)(c * 73856093) ^ (unsigned)(r * 19349663);
	h ^= h >> 13; h *= 0x5bd1e995u; h ^= h >> 15;
	return (int)(h & 0x7fff);
}

//sprite for the terrain cell, picked by which of its 4 neighbours are terrain
static int tut_tile_for(int c, int r) {
	const char ch = (c < 0 || c >= TUT_W || r < 0 || r >= TUT_H) ? 'G' : tut_grid[r][c];
	if (ch == '#') {
		if (r == 1) return 202;                                 // top of the curtain
		if (r + 1 < TUT_H && tut_grid[r + 1][c] != '#') return 203;
		return 200 + (r & 1);
	}
	const int mask = (tut_cell_terrain(c, r - 1) ? 1 : 0) | (tut_cell_terrain(c + 1, r) ? 2 : 0)
	               | (tut_cell_terrain(c, r + 1) ? 4 : 0) | (tut_cell_terrain(c - 1, r) ? 8 : 0);
	const int h = tut_hash(c, r) % 6;
	if (ch == 'S') {
		if (mask == 15 && h > 0) return 164 + (h - 1) % 4;
		if (mask == 14 && h > 0) return 172 + (h - 1) % 4;
		return 144 + mask;
	}
	if (mask == 15 && h > 0) return 160 + (h - 1) % 4;
	if (mask == 14 && h > 0) return 168 + (h - 1) % 4;
	return 128 + mask;
}

static void tut_hill(int cx, int base, int w, int h, int col) {
	for (int dy = 0; dy < h; dy += 2) {
		const float t = (float)dy / (float)h;
		const int hw = (int)((float)w * 0.5f * sqrtf(1.0f - t * t));
		P8rectfill(cx - hw, base - dy - 1, cx + hw, base - dy, col);
	}
}

static void tut_cloud(float x, int y, int w, int big) {
	const int xi = (int)x;
	P8rectfill(xi + 3, y + 5, xi + w - 4, y + 5, 6);              // belly
	P8rectfill(xi + 1, y + 2, xi + w - 2, y + 4, 7);
	P8rectfill(xi + 4, y, xi + w - 6, y + 1, 7);                   // top
	if (big) P8rectfill(xi + w/4, y - 2, xi + w/2 + 2, y - 1, 7);   // bump
	P8rectfill(xi, y + 3, xi, y + 4, 7);
}

static void tut_sky(void) {
	const int x0 = -wide_pad - 8, x1 = 128 + wide_pad + 8;
	P8rectfill(x0, -8, x1, 136, 12);
	// haze towards the horizon: thin light bands that get thicker
	for (int k = 0; k < 7; k++) {
		const int y = 58 + k * 10;
		P8rectfill(x0, y, x1, y + (k + 1) / 3, 7);
	}
	// sun
	P8rectfill(138, 34, 149, 45, 10);
	P8rectfill(136, 36, 151, 43, 10);
	P8rectfill(140, 32, 147, 47, 10);
	P8rectfill(141, 36, 146, 43, 7);
	// clouds drift to the right
	const float t = (float)tut_t;
	static const struct { int x, y, w, big; float spd; } cl[] = {
		{ 20, 30, 34, 1, 0.12f }, { 110, 52, 28, 0, 0.18f }, { 190, 24, 40, 1, 0.09f }, { 70, 72, 26, 0, 0.15f },
	};
	for (int i = 0; i < 4; i++) {
		float x = fmodf((float)cl[i].x + t * cl[i].spd, 300.0f) - 62.0f;
		tut_cloud(x, cl[i].y, cl[i].w, cl[i].big);
	}
	// distant mountains and rolling hills
	tut_hill(-30, 112, 70, 42, 13);
	tut_hill(30, 112, 90, 56, 13);
	tut_hill(120, 112, 100, 46, 13);
	tut_hill(185, 112, 80, 34, 13);
	tut_hill(-10, 120, 80, 30, 3);
	tut_hill(70, 120, 90, 22, 3);
	tut_hill(150, 120, 100, 28, 3);
}

// ---- banner text ------------------------------------------------------------------------------
static const int tut_disc_x0[7] = { 2, 1, 0, 0, 0, 1, 2 };
static const int tut_disc_x1[7] = { 4, 5, 6, 6, 6, 5, 4 };

static void tut_disc(int x, int y, int sym) {          // PlayStation style button: dark disc + colored symbol
	for (int r = 0; r < 7; r++) P8rectfill(x + tut_disc_x0[r], y + r, x + tut_disc_x1[r], y + r, 5);
	const int sx = x + 1, sy = y + 1;
	switch (sym) {
		case 0:   // cross
			P8rectfill(sx, sy, sx, sy, 12); P8rectfill(sx + 4, sy, sx + 4, sy, 12);
			P8rectfill(sx + 1, sy + 1, sx + 1, sy + 1, 12); P8rectfill(sx + 3, sy + 1, sx + 3, sy + 1, 12);
			P8rectfill(sx + 2, sy + 2, sx + 2, sy + 2, 12);
			P8rectfill(sx + 1, sy + 3, sx + 1, sy + 3, 12); P8rectfill(sx + 3, sy + 3, sx + 3, sy + 3, 12);
			P8rectfill(sx, sy + 4, sx, sy + 4, 12); P8rectfill(sx + 4, sy + 4, sx + 4, sy + 4, 12);
			break;
		case 1:   // circle
			P8rectfill(sx + 1, sy, sx + 3, sy, 8); P8rectfill(sx + 1, sy + 4, sx + 3, sy + 4, 8);
			P8rectfill(sx, sy + 1, sx, sy + 3, 8); P8rectfill(sx + 4, sy + 1, sx + 4, sy + 3, 8);
			break;
		case 2:   // square
			P8rectfill(sx, sy, sx + 4, sy, 14); P8rectfill(sx, sy + 4, sx + 4, sy + 4, 14);
			P8rectfill(sx, sy + 1, sx, sy + 3, 14); P8rectfill(sx + 4, sy + 1, sx + 4, sy + 3, 14);
			break;
		case 3:   // triangle
			P8rectfill(sx + 2, sy, sx + 2, sy, 11);
			P8rectfill(sx + 1, sy + 1, sx + 1, sy + 1, 11); P8rectfill(sx + 3, sy + 1, sx + 3, sy + 1, 11);
			P8rectfill(sx, sy + 2, sx, sy + 2, 11); P8rectfill(sx + 4, sy + 2, sx + 4, sy + 2, 11);
			P8rectfill(sx, sy + 3, sx + 4, sy + 3, 11);
			break;
	}
}

static int tut_keycap(int x, int y, const char* label, bool draw) {
	const int w = (int)strlen(label) * 4 + 3;
	if (draw) {
		P8rectfill(x, y, x + w - 1, y + 6, 5);
		P8rectfill(x + 1, y + 1, x + w - 2, y + 5, 6);
		P8print(label, x + 2, y + 1, 0);
	}
	return w;
}

//draws (or measures) a marker; returns its width
static int tut_marker(char k, int x, int y, bool draw) {
	switch (k) {
		case 'j': if (tut_pad_icons) { if (draw) tut_disc(x, y, 0); return 7; } return tut_keycap(x, y, tut_keys[0], draw);
		case 'd': if (tut_pad_icons) { if (draw) { tut_disc(x, y, 2); tut_disc(x + 8, y, 1); } return 15; }
		          return tut_keycap(x, y, tut_keys[1], draw);
		case 'g': return tut_keycap(x, y, tut_pad_icons ? "L1/R1" : tut_keys[2], draw);
		case 'm': if (tut_pad_icons) { if (draw) tut_disc(x, y, 3); return 7; } return tut_keycap(x, y, tut_keys[3], draw);
		case 'p':
			if (tut_pad_icons) {
				if (draw) {
					P8rectfill(x, y + 2, x + 6, y + 4, 6); P8rectfill(x + 2, y, x + 4, y + 6, 6);
					P8rectfill(x + 3, y + 3, x + 3, y + 3, 5);
				}
				return 7;
			}
			return tut_keycap(x, y, tut_keys[4], draw);
	}
	return 0;
}

//prints a line; `*budget` is the number of characters that may still appear (typewriter)
static void tut_print(int x, int y, int col, const char* s, int* budget) {
	char one[2] = { 0, 0 };
	while (*s && *budget > 0) {
		if (s[0] == '[' && s[1] && s[2] == ']') {
			x += tut_marker(s[1], x, y - 1, true) + 1;
			s += 3;
		} else {
			one[0] = *s++;
			P8print(one, x, y, col);
			x += 4;
		}
		(*budget)--;
	}
}

static int tut_len(const char* s) {            // characters, markers count as one
	int n = 0;
	while (*s) { if (s[0] == '[' && s[1] && s[2] == ']') s += 3; else s++; n++; }
	return n;
}

static void tut_banner(void) {
	const int pg = tut_current_page();
	if (pg != tut_page) {
		if (tut_page >= 0) { tut_flash = 14; P8sfx(35); }
		tut_page = pg;
		tut_type_t = 0;
	} else tut_type_t++;

	const int L = lang_pt ? 1 : 0;
	char title[48];
	snprintf(title, sizeof title, tut_txt[pg][L][0], tut_victim + 1);
	const char* l1 = tut_txt[pg][L][1];
	const char* l2 = tut_txt[pg][L][2];

	const int x0 = -wide_pad + 4, x1 = 127 + wide_pad - 4, y0 = 2, y1 = 27;
	P8rectfill(x0 + 1, y1 + 1, x1 + 1, y1 + 2, 0);                      // drop shadow
	P8rectfill(x0, y0, x1, y1, tut_flash > 0 && (tut_flash / 2) % 2 ? 10 : 7);
	P8rectfill(x0 + 1, y0 + 1, x1 - 1, y1 - 1, 1);
	P8rectfill(x0 + 2, y0 + 2, x1 - 2, y0 + 2, 13);                     // inner highlight
	P8rectfill(x0 + 2, y0 + 8, x1 - 2, y0 + 8, 5);                      // under the title

	int budget = tut_type_t * 5 / 2;
	if (tut_type_t > 0 && (tut_type_t % 3) == 0 && budget < tut_len(title) + tut_len(l1) + tut_len(l2) && sfx_timer <= 0) P8sfx(35);
	const int total = budget;
	(void)total;
	tut_print(x0 + 6, y0 + 3, 10, title, &budget);
	tut_print(x0 + 6, y0 + 11, 7, l1, &budget);
	tut_print(x0 + 6, y0 + 18, 7, l2, &budget);

	// progress pips
	const int npg = coop ? 9 : 7;
	for (int i = 0; i < npg; i++) {
		const int px = x1 - 5 - (npg - 1 - i) * 5;
		P8rectfill(px, y0 + 3, px + 2, y0 + 5, i == tut_stage ? 10 : (i < tut_stage ? 11 : 5));
	}
}

// ---- scenery: pads, portal ---------------------------------------------------------------------
static void tut_pad(int cx, int kind) {        // kind 0: revive (bubble), 1: fusion (triangle)
	const int y = TUT_T2_Y - 1;
	const bool on = (tut_t / 6) % 2;
	P8rectfill(cx - 11, y - 1, cx + 11, y, 6);
	P8rectfill(cx - 9, y - 2, cx + 9, y - 2, on ? 7 : 6);
	P8rectfill(cx - 11, y, cx - 11, y, 13); P8rectfill(cx + 11, y, cx + 11, y, 13);
	const int bob = ((tut_t / 8) % 2);
	const int sy = TUT_T2_Y - 18 + bob;
	if (kind == 0) {
		P8circfill(cx, sy + 4, 3, 12);
		P8circfill(cx, sy + 4, 2, 1);
		P8rectfill(cx - 2, sy + 2, cx - 1, sy + 2, 7);
	} else {
		const int c = on ? 11 : 3;
		P8rectfill(cx, sy, cx, sy, c);
		P8rectfill(cx - 1, sy + 1, cx + 1, sy + 1, c);
		P8rectfill(cx - 2, sy + 2, cx + 2, sy + 2, c);
		P8rectfill(cx - 3, sy + 3, cx + 3, sy + 3, c);
		P8rectfill(cx - 4, sy + 4, cx + 4, sy + 4, c);
	}
}

static void tut_portal(void) {
	const int cx = TUT_PORTAL_X, base = TUT_T2_Y;
	// swirl: nested rings that pulse towards the centre
	const int phase = tut_t / 4;
	P8rectfill(cx - 5, base - 20, cx + 4, base - 1, 1);
	for (int i = 0; i < 4; i++) {
		static const int cols[3] = { 12, 7, 13 };
		P8rectfill(cx - 5 + i, base - 20 + i, cx + 4 - i, base - 1, cols[(phase + 4 - i) % 3]);
	}
	P8rectfill(cx - 1, base - 16, cx, base - 3, (phase % 2) ? 7 : 12);
	// stone frame
	P8rectfill(cx - 8, base - 22, cx - 6, base - 1, 6);
	P8rectfill(cx + 5, base - 22, cx + 7, base - 1, 6);
	P8rectfill(cx - 8, base - 22, cx - 8, base - 1, 7);
	P8rectfill(cx + 7, base - 22, cx + 7, base - 1, 13);
	P8rectfill(cx - 9, base - 25, cx + 8, base - 23, 6);
	P8rectfill(cx - 9, base - 25, cx + 8, base - 25, 7);
	P8rectfill(cx - 9, base - 23, cx + 8, base - 23, 13);
	P8rectfill(cx - 10, base - 1, cx + 9, base, 13);
	// moss on the frame
	P8rectfill(cx - 9, base - 26, cx - 5, base - 26, 11);
	P8rectfill(cx + 3, base - 26, cx + 8, base - 26, 3);
	// sparkles rising
	for (int i = 0; i < 3; i++) {
		const int t = (tut_t * 2 + i * 23) % 40;
		P8rectfill(cx - 3 + i * 3, base - 4 - t / 2, cx - 3 + i * 3, base - 4 - t / 2, (t / 4) % 2 ? 7 : 12);
	}
}

static void tut_draw(void) {
	tut_sky();

	//decoration behind the terrain
	for (int i = 0; i < TUT_DECOR_N; i++)
		P8spr(tut_decor[i][2], TUT_X0 + tut_decor[i][0]*8, tut_decor[i][1]*8, 1, 1, false, false);

	if (coop) {
		tut_pad(TUT_RUNE_A_X, 0);
		tut_pad(TUT_RUNE_B_X, 1);
	}
	tut_portal();

	//the pits are deep and dark
	for (int r = 14; r < TUT_H; r++)
		for (int c = 0; c < TUT_W; c++)
			if (tut_grid[r][c] == '.') {
				P8rectfill(TUT_X0 + c*8, r*8, TUT_X0 + c*8 + 7, r*8 + 7, 1);
				P8rectfill(TUT_X0 + c*8, r*8 + 6, TUT_X0 + c*8 + 7, r*8 + 7, 0);
			}

	//terrain, the two outer columns fill the 2 px that stick out of the 224 px map
	for (int r = 0; r < TUT_H; r++) {
		for (int c = -1; c <= TUT_W; c++) {
			const int cell_solid = (c < 0 || c >= TUT_W) ? 1 : (tut_grid[r][c] != '.');
			if (!cell_solid) continue;
			P8spr(tut_tile_for(c, r), TUT_X0 + c*8, r*8, 1, 1, false, false);
		}
	}

	//objects
	for (int i = 0; i < MAX_OBJECTS; i++) {
		OBJ* o = &objects[i];
		redo_draw:;
		short this_id = o->id;
		if (o->active && o->type != OBJ_PLATFORM) draw_object(o);
		if (this_id != o->id) goto redo_draw;
	}
	coop_draw_world();

	//pollen and petals
	for (int i = 0; i <= 24; i++) {
		PARTICLE* p = &particles[i];
		p->x += p->spd * 0.5f;
		p->y += P8sin(p->off) * 0.6f;
		p->off += P8min(0.05, p->spd/32);
		P8rectfill(p->x, p->y, p->x + p->s, p->y + p->s, (i % 3 == 0) ? 14 : (i % 3 == 1) ? 10 : 7);
		if (p->x > 128 + 4 + wide_pad) { p->x = -4 - wide_pad; p->y = P8rnd(110) + 10; }
	}

	for (int i = 0; i <= 7; i++) {
		PARTICLE* p = &dead_particles[i];
		if (p->active) {
			p->x += p->spd2.x; p->y += p->spd2.y;
			p->t -= 1;
			if (p->t <= 0) p->active = false;
			P8rectfill(p->x-p->t/5, p->y-p->t/5, p->x+p->t/5, p->y+p->t/5, 14+P8modulo(p->t,2));
		}
	}

	tut_banner();
	coop_draw_hud();

	//the portal takes the players away
	if (tut_exit_t > 0) {
		const int w = tut_exit_t * 7;
		const int cx = TUT_PORTAL_X;
		P8rectfill(cx - w, -4, cx + w, 132, 7);
	}
}

#ifdef CELESTE_HARNESS
int celeste_h_noballoon = 0;
// test accessors, only built into tools/harness.c
int Celeste_H_player(int pid, float* v) {
	OBJ* p = coop_find(pid);
	if (!p) return 0;
	v[0] = p->x; v[1] = p->y; v[2] = p->spd.x; v[3] = p->spd.y; v[4] = (float)p->djump;
	v[5] = p->bubble; v[6] = (float)p->dash_time; v[7] = p->grabbing; v[8] = p->stamina;
	return 1;
}
void Celeste_H_tp(int pid, float x, float y) { OBJ* p = coop_find(pid); if (p) { p->x = x; p->y = y; p->spd.x = p->spd.y = 0; } }
void Celeste_H_tut(int* st) {
	st[0] = tut_active; st[1] = tut_stage; st[2] = deaths; st[3] = tut_rev; st[4] = tut_fuse; st[5] = tut_exit_t;
	st[6] = tut_cp; st[7] = fuse_timer; st[8] = tut_victim;
}
#endif
#ifdef CELESTE_HARNESS
//audit: for room index lvl (0..30) report spawn target of both players and whether each has ground
int Celeste_H_room(int lvl, float* o) {
	tut_active = false;
	load_room(lvl % 8, lvl / 8);
	int n = 0;
	for (int i = 0; i < MAX_OBJECTS; i++) if (objects[i].active && objects[i].type == OBJ_PLAYER_SPAWN && n < 2) {
		o[n*3] = objects[i].target.x; o[n*3+1] = objects[i].target.y;
		o[n*3+2] = solid_at((int)(objects[i].target.x+1), (int)(objects[i].target.y+8), 6, 1) ? 1 : 0;
		n++;
	}
	return n;
}
#endif
