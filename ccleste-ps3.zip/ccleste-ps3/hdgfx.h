// HD renderer for ccleste: sprites from an HD atlas (data/gfx_hd.bin), shaded circles for the
// hair and a parallax night background drawn in full colour. No SDL dependency: it draws into
// a plain 32-bit pixel buffer, so it can also be tested on a PC (see tools/).
#ifndef HDGFX_H_
#define HDGFX_H_
#include <stdint.h>

// map_rgb: converts r,g,b (0..255) to the surface's pixel format
void hd_init(int scale, uint32_t (*map_rgb)(int r, int g, int b));
int  hd_load_atlas(const char* path);          // 0 = ok (tile size must be 8*scale)
int  hd_ready(void);
void hd_target(uint32_t* px, int w, int h, int pitch_words);

void hd_pal(int a, int b);                     // pal(a,b)
void hd_pal_reset(void);
void hd_dim(int on);                           // darkens everything drawn from now on
uint32_t hd_color(int idx);                    // flat colour of a palette index (mid shade)
void hd_base_rgb(int idx, int* r, int* g, int* b);

void hd_tile(int tile, int dx, int dy, int flipx, int flipy);   // dx,dy in screen pixels
void hd_rect(int x0, int y0, int x1, int y1, int idx);          // inclusive, screen pixels
void hd_circle(int cx, int cy, int r_game, int idx);            // cx,cy screen px, r in game px
// parallax background. rx,ry = room, view_w/h in screen px. mode: 0 normal
void hd_bg(int rx, int ry, int frames, int view_w, int view_h);
#endif
