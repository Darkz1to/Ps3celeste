// Title menu (play / config / credits) for ccleste.
// Included by sdl12main.c. Draws only through pico8emu() callbacks so it uses the
// same 128x128 PICO-8 screen and palette as the game.
//
// The frontend must provide (before including this file):
//   pico8emu(), Celeste_P8_update/draw(), menu_apply_audio(), menu_play_sfx(),
//   menu_cfg_path(), `buttons_state` and the `enable_screenshake` flag.

#include <math.h>
#include <string.h>
#include <stdio.h>

enum { MENU_MAIN, MENU_CONFIG, MENU_CREDITS, MENU_GAME };

static int menu_state = MENU_MAIN;
static int menu_sel = 0;          // selected row in the current screen
static int menu_t = 0;            // frame counter (animations)
static int menu_start_pending = 0;
static int menu_hold_l = 0, menu_hold_r = 0;

// settings (saved to disk)
static int cfg_music = 10;        // 0..10
static int cfg_sound = 10;        // 0..10

// ---- edit these to change the credits text (max 31 chars per line) ----
static const struct { const char* text; int col; } menu_credits[] = {
	{ "celeste classic",       14 },
	{ "matt thorson",           7 },
	{ "noel berry",             7 },
	{ "",                       0 },
	{ "c port (ccleste)",      14 },
	{ "lemon",                  7 },
	{ "",                       0 },
	{ "sounds: gba port",      14 },
	{ "jeffrulz",               7 },
	{ "",                       0 },
	{ "ps3 port",              14 },
	{ "thanks for playing!",    7 },
};

#if defined(PLATFORM_PS3)
#define MENU_HINT_MAIN   "x: ok"
#define MENU_HINT_SUB    "x: ok   o: back"
#elif defined(_3DS)
#define MENU_HINT_MAIN   "a: ok"
#define MENU_HINT_SUB    "a: ok   b: back"
#else
#define MENU_HINT_MAIN   "z: ok"
#define MENU_HINT_SUB    "z: ok   x: back"
#endif

static const unsigned char btn_left = 1<<0, btn_right = 1<<1, btn_up = 1<<2, btn_down = 1<<3;
static const unsigned char btn_ok = 1<<4, btn_back = 1<<5;

// ---------------------------------------------------------------- drawing helpers
static void m_rect(int x0, int y0, int x1, int y1, int c) { pico8emu(CELESTE_P8_RECTFILL, x0, y0, x1, y1, c); }
static void m_text(const char* s, int x, int y, int c) { pico8emu(CELESTE_P8_PRINT, s, x, y, c); }
static void m_text_c(const char* s, int y, int c) { m_text(s, 64 - (int)strlen(s)*2, y, c); }
static void m_text_shadow_c(const char* s, int y, int c, int sc) {
	m_text_c(s, y + 1, sc);
	m_text_c(s, y, c);
}
static void m_spr(int s, int x, int y, int flipx) { pico8emu(CELESTE_P8_SPR, s, x, y, 1, 1, flipx, 0); }

// snow / stars, same feel as the title screen particles
#define MENU_FLAKES 28
static struct { float x, y, spd, off; int c; } flakes[MENU_FLAKES];
static int flakes_ready = 0;
static unsigned menu_rng = 12345;
static float menu_rnd(void) { menu_rng = menu_rng*1103515245u + 12345u; return ((menu_rng>>16) & 0x7fff) / 32768.0f; }

static void menu_flakes_update_draw(void) {
	if (!flakes_ready) {
		flakes_ready = 1;
		for (int i = 0; i < MENU_FLAKES; i++) {
			flakes[i].x = menu_rnd()*128; flakes[i].y = menu_rnd()*128;
			flakes[i].spd = 0.3f + menu_rnd()*1.2f; flakes[i].off = menu_rnd();
			flakes[i].c = (i % 5 == 0) ? 7 : (i % 3 == 0) ? 6 : 13;
		}
	}
	for (int i = 0; i < MENU_FLAKES; i++) {
		flakes[i].x += flakes[i].spd;
		flakes[i].y += sinf(flakes[i].off*6.2832f) * 0.4f;
		flakes[i].off += 0.02f;
		if (flakes[i].x > 132) { flakes[i].x = -4; flakes[i].y = menu_rnd()*128; }
		int x = (int)flakes[i].x, y = (int)flakes[i].y;
		int big = flakes[i].spd > 1.1f;
		m_rect(x, y, x + big, y + big, flakes[i].c);
	}
}

static void menu_mountains(void) {
	for (int x = 0; x < 128; x++) {
		// far range
		int h = 20 + (int)(9*sinf(x*0.07f + 0.5f) + 5*sinf(x*0.19f + 2.0f));
		int top = 128 - h;
		m_rect(x, top, x, 127, 1);
		if (h > 27) m_rect(x, top, x, top + 1, 13);     // snow cap
		else if (h > 24) m_rect(x, top, x, top, 13);
		// near ridge
		int h2 = 8 + (int)(5*sinf(x*0.11f + 3.0f) + 3*sinf(x*0.29f));
		m_rect(x, 128 - h2, x, 127, 0);
		m_rect(x, 128 - h2, x, 128 - h2, 5);
	}
}

static void menu_cursor(int x, int y) {
	// bobbing strawberry
	int bob = (int)floorf(sinf(menu_t * 0.18f) * 1.5f + 0.5f);
	m_spr(26, x, y - 2 + bob, 0);
}

static void menu_header(const char* title) {
	m_text_shadow_c(title, 9, 14, 2);
	int w = (int)strlen(title)*4;
	m_rect(64 - w/2 - 14, 12, 64 - w/2 - 6, 12, 13);
	m_rect(64 + w/2 + 6,  12, 64 + w/2 + 14, 12, 13);
}

// ---------------------------------------------------------------- config persistence
static void menu_save_cfg(void) {
	char path[700];
	if (!menu_cfg_path(path, sizeof path)) return;
	FILE* f = fopen(path, "w");
	if (!f) return;
	fprintf(f, "%d %d %d\n", cfg_music, cfg_sound, enable_screenshake ? 1 : 0);
	fclose(f);
}

static void menu_load_cfg(void) {
	char path[700];
	if (!menu_cfg_path(path, sizeof path)) return;
	FILE* f = fopen(path, "r");
	if (!f) return;
	int m, s, k;
	if (fscanf(f, "%d %d %d", &m, &s, &k) == 3) {
		cfg_music = m < 0 ? 0 : m > 10 ? 10 : m;
		cfg_sound = s < 0 ? 0 : s > 10 ? 10 : s;
		enable_screenshake = k != 0;
	}
	fclose(f);
}

// ---------------------------------------------------------------- public API
static int menu_active(void) { return menu_state != MENU_GAME; }

static void menu_init(int skip) {
	menu_load_cfg();
	menu_apply_audio();
	menu_state = skip ? MENU_GAME : MENU_MAIN;
	menu_sel = 0; menu_t = 0; menu_start_pending = 0;
	Celeste_P8_set_menu_mode(!skip);
}

// back to the main menu (used after a reset)
static void menu_enter_main(void) {
	menu_state = MENU_MAIN; menu_sel = 0; menu_t = 0; menu_start_pending = 0;
	Celeste_P8_set_menu_mode(1);
}

// returns 1 exactly once after "play" was chosen: the frontend injects a jump press
// so the game runs its own start flash and loads the first room
static int menu_take_start(void) {
	int r = menu_start_pending;
	menu_start_pending = 0;
	return r;
}

static int menu_repeat(int held, int* counter) {
	if (!held) { *counter = 0; return 0; }
	(*counter)++;
	return *counter == 1 || (*counter > 14 && (*counter % 3) == 0);
}

static void menu_move(int* sel, int n, int dir) {
	*sel = (*sel + dir + n) % n;
	menu_play_sfx(13);
}

// pressed = buttons that went down this frame, held = buttons currently down
static void menu_frame(Uint16 pressed, Uint16 held) {
	menu_t++;
	const int up = (pressed & btn_up) != 0, down = (pressed & btn_down) != 0;
	const int ok = (pressed & btn_ok) != 0, back = (pressed & btn_back) != 0;
	const int left = menu_repeat((held & btn_left) != 0, &menu_hold_l);
	const int right = menu_repeat((held & btn_right) != 0, &menu_hold_r);

	pico8emu(CELESTE_P8_CAMERA, 0, 0);
	pico8emu(CELESTE_P8_PAL_RESET);

	if (menu_state == MENU_MAIN) {
		static const char* items[3] = { "play", "config", "credits" };
		if (up)   menu_move(&menu_sel, 3, -1);
		if (down) menu_move(&menu_sel, 3, +1);
		if (ok) {
			if (menu_sel == 0) {
				menu_state = MENU_GAME;
				menu_start_pending = 1;
				return;     // the game takes over from the next call
			}
			menu_state = menu_sel == 1 ? MENU_CONFIG : MENU_CREDITS;
			menu_sel = 0; menu_t = 0;
			menu_play_sfx(35);
			return;
		}

		// the real title room (logo + snow), with buttons hidden from the game
		{
			Uint16 real = buttons_state;
			buttons_state = 0;
			Celeste_P8_update();
			Celeste_P8_draw();
			buttons_state = real;
		}
		pico8emu(CELESTE_P8_PAL_RESET);

		for (int i = 0; i < 3; i++) {
			int y = 76 + i*12, sel = i == menu_sel;
			int w = (int)strlen(items[i])*4;
			m_text_c(items[i], y, sel ? 7 : 13);
			if (sel) {
				menu_cursor(64 - w/2 - 12, y);
				m_rect(64 - w/2, y + 7, 64 + w/2 - 2, y + 7, (menu_t/4 % 2) ? 14 : 8);
			}
		}
		m_text_c("matt thorson / noel berry", 119, 5);
		(void)MENU_HINT_MAIN;
	} else if (menu_state == MENU_CONFIG) {
		// rows: 0 music, 1 sound, 2 screenshake, 3 back
		if (up)   menu_move(&menu_sel, 4, -1);
		if (down) menu_move(&menu_sel, 4, +1);
		int d = right ? 1 : left ? -1 : 0;
		if (d && menu_sel == 0) { int v = cfg_music + d; if (v >= 0 && v <= 10) { cfg_music = v; menu_apply_audio(); menu_play_sfx(13); } }
		if (d && menu_sel == 1) { int v = cfg_sound + d; if (v >= 0 && v <= 10) { cfg_sound = v; menu_apply_audio(); menu_play_sfx(13); } }
		if (menu_sel == 2 && ((pressed & (btn_left|btn_right|btn_ok)) != 0)) {
			enable_screenshake = !enable_screenshake;
			menu_play_sfx(13);
		}
		if (back || (ok && menu_sel == 3)) {
			menu_save_cfg();
			menu_state = MENU_MAIN; menu_sel = 1; menu_t = 0;
			menu_play_sfx(35);
			return;
		}

		m_rect(0, 0, 127, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header("config");

		static const char* labels[4] = { "music", "sound", "shake", "back" };
		for (int i = 0; i < 4; i++) {
			int y = 32 + i*14, sel = i == menu_sel;
			int col = sel ? 7 : 13;
			if (i == 3) { m_text_c(labels[i], y + 4, col); if (sel) menu_cursor(64 - 10 - 12, y + 4); continue; }
			m_text(labels[i], 22, y, col);
			if (sel) menu_cursor(8, y);
			if (i < 2) {
				int v = i == 0 ? cfg_music : cfg_sound;
				for (int k = 0; k < 10; k++)
					m_rect(60 + k*5, y + 1, 63 + k*5, y + 5, k < v ? (sel ? 12 : 13) : 1);
			} else {
				m_text(enable_screenshake ? "on" : "off", 60, y, sel ? 10 : 13);
			}
			if (sel) {
				m_text("<", 54, y, 10);
				m_text(">", i < 2 ? 111 : 60 + (enable_screenshake ? 12 : 16), y, 10);
			}
		}
		m_text_c(MENU_HINT_SUB, 118, 6);
	} else if (menu_state == MENU_CREDITS) {
		if (back || ok) {
			menu_state = MENU_MAIN; menu_sel = 2; menu_t = 0;
			menu_play_sfx(35);
			return;
		}
		m_rect(0, 0, 127, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header("credits");

		const int n = (int)(sizeof menu_credits / sizeof *menu_credits);
		for (int i = 0; i < n; i++) {
			if (!*menu_credits[i].text) continue;
			m_text_c(menu_credits[i].text, 23 + i*6, menu_credits[i].col);
		}
		// Madeline waiting at the bottom, strawberry next to her
		m_spr(1, 56, 112, 0);
		m_spr(26, 68, 112 + (int)floorf(sinf(menu_t*0.18f) * 1.5f + 0.5f), 0);
		(void)MENU_HINT_SUB;
	}
}
