// Title menu (play -> solo / coop, contents -> trophies + customize, config, credits) and the pause menu
// (continue, config, trophies, quit) for ccleste.
// Included by sdl12main.c. Draws only through pico8emu() callbacks so it uses the
// same 128x128 PICO-8 screen and palette as the game.
//
// The frontend must provide (before including this file):
//   pico8emu(), Celeste_P8_update/draw(), menu_apply_audio(), menu_play_sfx(),
//   menu_cfg_path(), autosave_sync(), coop_pad2_present(), `buttons_state` and the
//   `enable_screenshake` flag,
// and savedata.inc.c must be included before this file.

#include <math.h>
#include <string.h>
#include <stdio.h>

enum { MENU_MAIN, MENU_CONFIG, MENU_CREDITS, MENU_MODE, MENU_GAME, MENU_PAUSE, MENU_CONTENT, MENU_TROPHIES, MENU_CUSTOM };

static int menu_state = MENU_MAIN;
static int menu_sel = 0;          // selected row in the current screen
static int menu_t = 0;            // frame counter (animations)
static int menu_start_pending = 0;
static int menu_hold_l = 0, menu_hold_r = 0, menu_hold_u = 0, menu_hold_d = 0;
static int menu_from_pause = 0;   // 1 while the pause menu (or a screen opened from it) is up
static int menu_quit_pending = 0; // "quit" chosen in the pause menu: the frontend goes back to the title
static int menu_block = 0;        // ticks during which ok / back are ignored (right after pausing)
static int menu_resume_hold = 0;  // set when the game resumes: jump / dash are ignored until they are released
static int tr_sel = 0, tr_top = 0, tr_detail = 0;   // trophy list state

// settings (saved to disk)
static int cfg_music = 10;        // 0..10
static int cfg_sound = 10;        // 0..10

// ---- language ----
enum { LANG_EN = 0, LANG_PT = 1 };
static int cfg_lang = LANG_EN;

enum { S_PLAY, S_CONTINUE, S_NEWGAME, S_CONFIG, S_CREDITS, S_MUSIC, S_SOUND, S_SHAKE, S_LANG,
       S_BACK, S_ON, S_OFF, S_LANGNAME, S_MODE, S_SOLO, S_COOP, S_ONEP, S_TWOP, S_NEEDPAD,
       S_CONTENTS, S_TROPHIES, S_PAUSED, S_QUIT,
       S_CUSTOMIZE, S_CU_SUB, S_CU_WHO, S_CU_HAIR, S_CU_DRESS, S_CU_SKIN, S_CU_HAT, S_CU_HATCOL, S_CU_SCARF,
       S_CU_CAPE, S_CU_EXTRA, S_COUNT };
// the pico-8 font has no accents, so the portuguese texts are written without them
static const char* const menu_str[2][S_COUNT] = {
	{ "play", "continue", "new game", "config", "credits", "music", "sound", "shake", "language",
	  "back", "on", "off", "english",
	  "game mode", "solo", "coop", "1 player", "2 players", "connect a 2nd controller",
	  "contents", "trophies", "paused", "quit",
	  "customize", "look and accessories", "player", "hair", "outfit", "skin", "hat", "hat color", "scarf",
	  "cape", "extra" },
	{ "jogar", "continuar", "novo jogo", "configuracoes", "creditos", "musica", "som", "tremor", "idioma",
	  "voltar", "ligado", "desligado", "portugues",
	  "modo de jogo", "solo", "coop", "1 jogador", "2 jogadores", "conecte o 2o controle",
	  "conteudos", "trofeus", "pausado", "sair",
	  "customizar", "visual e acessorios", "boneco", "cabelo", "roupa", "pele", "chapeu", "cor chap.", "cachecol",
	  "capa", "extra" },
};
#define TR(i) (menu_str[cfg_lang][(i)])

// ---- edit these to change the credits text (max 31 chars per line) ----
static const struct { const char* en; const char* pt; int col; } menu_credits[] = {
	{ "main creator",          "criador principal",      14 },
	{ "darkz1to",              "darkz1to",               10 },
	{ "",                      "",                        0 },
	{ "celeste classic",       "celeste classic",        14 },
	{ "matt thorson",          "matt thorson",            7 },
	{ "noel berry",            "noel berry",              7 },
	{ "",                      "",                        0 },
	{ "c port (ccleste)",      "port em c (ccleste)",    14 },
	{ "lemon",                 "lemon",                   7 },
	{ "sounds: gba port",      "sons: port gba",         14 },
	{ "jeffrulz",              "jeffrulz",                7 },
	{ "",                      "",                        0 },
	{ "thanks for playing!",   "obrigado por jogar!",     7 },
};

#if defined(PLATFORM_PS3)
#define MENU_KEY_OK   "x"
#define MENU_KEY_BACK "o"
#elif defined(_3DS)
#define MENU_KEY_OK   "a"
#define MENU_KEY_BACK "b"
#else
#define MENU_KEY_OK   "z"
#define MENU_KEY_BACK "x"
#endif

static const unsigned char btn_left = 1<<0, btn_right = 1<<1, btn_up = 1<<2, btn_down = 1<<3;
static const unsigned char btn_ok = 1<<4, btn_back = 1<<5;

// ---------------------------------------------------------------- drawing helpers
static void m_rect(int x0, int y0, int x1, int y1, int c) { pico8emu(CELESTE_P8_RECTFILL, x0, y0, x1, y1, c); }
static void m_text(const char* s, int x, int y, int c) { pico8emu(CELESTE_P8_PRINT, s, x, y, c); }
static void m_text_c(const char* s, int y, int c) { m_text(s, 64 - (int)strlen(s)*2, y, c); }
static void m_text_shadow_c(const char* s, int y, int c, int sc) {
	m_text_c(s, y + 1, sc);
	m_text_c(s, y, c);
}
static void m_spr(int s, int x, int y, int flipx) { pico8emu(CELESTE_P8_SPR, s, x, y, 1, 1, flipx, 0); }

// snow / stars, same feel as the title screen particles
#define MENU_FLAKES 28
static struct { float x, y, spd, off; int c; } flakes[MENU_FLAKES];
static int flakes_ready = 0;
static unsigned menu_rng = 12345;
static float menu_rnd(void) { menu_rng = menu_rng*1103515245u + 12345u; return ((menu_rng>>16) & 0x7fff) / 32768.0f; }

static void menu_flakes_update_draw(void) {
	if (!flakes_ready) {
		flakes_ready = 1;
		for (int i = 0; i < MENU_FLAKES; i++) {
			flakes[i].x = menu_rnd()*(128 + 2*VIEW_OX) - VIEW_OX; flakes[i].y = menu_rnd()*128;
			flakes[i].spd = 0.3f + menu_rnd()*1.2f; flakes[i].off = menu_rnd();
			flakes[i].c = (i % 5 == 0) ? 7 : (i % 3 == 0) ? 6 : 13;
		}
	}
	for (int i = 0; i < MENU_FLAKES; i++) {
		flakes[i].x += flakes[i].spd;
		flakes[i].y += sinf(flakes[i].off*6.2832f) * 0.4f;
		flakes[i].off += 0.02f;
		if (flakes[i].x > 132 + VIEW_OX) { flakes[i].x = -4 - VIEW_OX; flakes[i].y = menu_rnd()*128; }
		int x = (int)flakes[i].x, y = (int)flakes[i].y;
		int big = flakes[i].spd > 1.1f;
		m_rect(x, y, x + big, y + big, flakes[i].c);
	}
}

static void menu_mountains(void) {
	for (int x = -VIEW_OX; x < 128 + VIEW_OX; x++) {
		// far range
		int h = 20 + (int)(9*sinf(x*0.07f + 0.5f) + 5*sinf(x*0.19f + 2.0f));
		int top = 128 - h;
		m_rect(x, top, x, 127, 1);
		if (h > 27) m_rect(x, top, x, top + 1, 13);     // snow cap
		else if (h > 24) m_rect(x, top, x, top, 13);
		// near ridge
		int h2 = 8 + (int)(5*sinf(x*0.11f + 3.0f) + 3*sinf(x*0.29f));
		m_rect(x, 128 - h2, x, 127, 0);
		m_rect(x, 128 - h2, x, 128 - h2, 5);
	}
}

static void menu_cursor(int x, int y) {
	// bobbing strawberry
	int bob = (int)floorf(sinf(menu_t * 0.18f) * 1.5f + 0.5f);
	m_spr(26, x, y - 2 + bob, 0);
}

static void menu_header(const char* title) {
	m_text_shadow_c(title, 9, 14, 2);
	int w = (int)strlen(title)*4;
	m_rect(64 - w/2 - 14, 12, 64 - w/2 - 6, 12, 13);
	m_rect(64 + w/2 + 6,  12, 64 + w/2 + 14, 12, 13);
}

// ---------------------------------------------------------------- config persistence
static void menu_save_cfg(void) {
	char path[700];
	if (!menu_cfg_path(path, sizeof path)) return;
	FILE* f = fopen(path, "w");
	if (!f) return;
	fprintf(f, "%d %d %d %d\n", cfg_music, cfg_sound, enable_screenshake ? 1 : 0, cfg_lang);
	// customization: one line per character (solo, co-op 1, co-op 2)
	for (int sl = 0; sl < CELESTE_STYLE_SLOTS; sl++) {
		Celeste_P8_style_t st; Celeste_P8_get_style(sl, &st);
		for (int k = 0; k < CELESTE_STYLE_FIELDS; k++) fprintf(f, "%d ", (int)st.v[k]);
		fprintf(f, "\n");
	}
	fclose(f);
}

static void menu_load_cfg(void) {
	char path[700];
	if (!menu_cfg_path(path, sizeof path)) return;
	FILE* f = fopen(path, "r");
	if (!f) return;
	int m, s, k, l = 0;
	int n = fscanf(f, "%d %d %d %d", &m, &s, &k, &l);
	if (n >= 3) {   // the language is optional: old cfg files only have 3 numbers
		cfg_music = m < 0 ? 0 : m > 10 ? 10 : m;
		cfg_sound = s < 0 ? 0 : s > 10 ? 10 : s;
		enable_screenshake = k != 0;
		cfg_lang = (n >= 4 && l == LANG_PT) ? LANG_PT : LANG_EN;
		// the look of the characters (optional: older cfg files stop here)
		for (int sl = 0; sl < CELESTE_STYLE_SLOTS; sl++) {
			Celeste_P8_style_t st; memset(&st, 0, sizeof st);
			int good = 1;
			for (int k = 0; k < CELESTE_STYLE_FIELDS && good; k++) {
				int x;
				if (fscanf(f, "%d", &x) != 1) { good = 0; break; }
				st.v[k] = (x < 0 || x >= Celeste_P8_style_count(k)) ? 0 : (unsigned char)x;
			}
			if (!good) break;
			Celeste_P8_set_style(sl, &st);
		}
	}
	fclose(f);
}

// ---------------------------------------------------------------- public API
static int menu_active(void) { return menu_state != MENU_GAME; }

static void menu_apply_lang(void) { Celeste_P8_set_language(cfg_lang == LANG_PT); }

static void menu_init(int skip) {
	menu_load_cfg();
	menu_apply_lang();
	menu_apply_audio();
	menu_state = skip ? MENU_GAME : MENU_MAIN;
	menu_sel = 0; menu_t = 0; menu_start_pending = 0;
	Celeste_P8_set_menu_mode(!skip);
}

// back to the main menu (used after a reset)
static void menu_enter_main(void) {
	menu_state = MENU_MAIN; menu_sel = 0; menu_t = 0; menu_start_pending = 0;
	menu_from_pause = 0; menu_block = 0;
	Celeste_P8_set_menu_mode(1);
}

// returns 1 exactly once after "play" was chosen: the frontend injects a jump press
// so the game runs its own start flash and loads the first room
static int menu_take_start(void) {
	int r = menu_start_pending;
	menu_start_pending = 0;
	return r;
}

static int menu_repeat(int held, int* counter) {
	if (!held) { *counter = 0; return 0; }
	(*counter)++;
	return *counter == 1 || (*counter > 14 && (*counter % 3) == 0);
}

static void menu_move(int* sel, int n, int dir) {
	*sel = (*sel + dir + n) % n;
	menu_play_sfx(13);
}

// main menu entries: "continue" only shows up when there is a save
enum { MI_CONTINUE, MI_PLAY, MI_CONTENT, MI_CONFIG, MI_CREDITS };
static int menu_main_items(int* ids) {
	int n = 0;
	if (savedata_has) ids[n++] = MI_CONTINUE;
	ids[n++] = MI_PLAY; ids[n++] = MI_CONTENT; ids[n++] = MI_CONFIG; ids[n++] = MI_CREDITS;
	return n;
}
static int menu_main_index(int id) {
	int ids[5], n = menu_main_items(ids);
	for (int i = 0; i < n; i++) if (ids[i] == id) return i;
	return 0;
}

static const char* menu_hint_sub(void) {
	static char buf[40];
	snprintf(buf, sizeof buf, "%s: ok   %s: %s", MENU_KEY_OK, MENU_KEY_BACK, TR(S_BACK));
	return buf;
}

#include "trophies.inc.c"

// ---------------------------------------------------------------- pause menu
// The frontend freezes the game, remembers the last picture (menu_snapshot_screen) and the menu draws
// on top of a darkened copy of it (menu_draw_pause_bg). Screens opened from the pause menu (config,
// trophies) go back to it. "start" closes everything (see mainLoop).
static void menu_snapshot_screen(void);   // sdl12main.c: remember the picture on screen, darkened
static void menu_draw_pause_bg(void);     // sdl12main.c: put that picture back

static int menu_in_pause(void) { return menu_state != MENU_GAME && menu_from_pause; }

static void menu_pause_open(void) {
	menu_snapshot_screen();
	menu_state = MENU_PAUSE; menu_from_pause = 1;
	menu_sel = 0; menu_t = 0; menu_block = 6;
	tr_detail = 0;
	menu_play_sfx(35);
}

// back to the game
static void menu_pause_close(void) {
	menu_save_cfg();
	menu_state = MENU_GAME; menu_from_pause = 0; menu_sel = 0;
	menu_resume_hold = 1;   // the button that chose "continue" must not jump / dash
	if (paused) { Mix_Resume(-1); music_resume(); paused = 0; }
}

// 1 (once) after "quit" was chosen
static int menu_take_quit(void) {
	const int r = menu_quit_pending;
	menu_quit_pending = 0;
	return r;
}

// background of the sub screens: the paused game (dark) or the title scenery
static void menu_backdrop(void) {
	if (menu_from_pause) { menu_draw_pause_bg(); return; }
	m_rect(-VIEW_OX, 0, 127 + VIEW_OX, 127, 0);
	menu_flakes_update_draw();
	menu_mountains();
}

static void menu_leave_sub(int from_state) {   // "back" in config / trophies / contents
	menu_t = 0;
	menu_play_sfx(35);
	if (from_state == MENU_CONFIG) {
		menu_save_cfg();
		if (menu_from_pause) { menu_state = MENU_PAUSE; menu_sel = 1; }
		else { menu_state = MENU_MAIN; menu_sel = menu_main_index(MI_CONFIG); }
	} else if (from_state == MENU_TROPHIES) {
		tr_detail = 0;
		if (menu_from_pause) { menu_state = MENU_PAUSE; menu_sel = 2; }
		else { menu_state = MENU_CONTENT; menu_sel = 0; }
	} else if (from_state == MENU_CUSTOM) {
		menu_save_cfg();
		menu_state = MENU_CONTENT; menu_sel = 1;
	} else if (from_state == MENU_CONTENT) {
		menu_state = MENU_MAIN; menu_sel = menu_main_index(MI_CONTENT);
	}
}

static void menu_open_trophies(void) {
	menu_state = MENU_TROPHIES;
	tr_sel = 0; tr_top = 0; tr_detail = 0;
	menu_hold_u = menu_hold_d = 0;
	menu_t = 0;
	menu_play_sfx(35);
}

// pressed = buttons that went down this frame, held = buttons currently down
static void menu_frame(Uint16 pressed, Uint16 held) {
	menu_t++;
	const int up = (pressed & btn_up) != 0, down = (pressed & btn_down) != 0;
	if (menu_block > 0) { menu_block--; pressed &= ~(btn_ok | btn_back); }   // the press that opened the pause menu
	const int ok = (pressed & btn_ok) != 0, back = (pressed & btn_back) != 0;
	const int left = menu_repeat((held & btn_left) != 0, &menu_hold_l);
	const int right = menu_repeat((held & btn_right) != 0, &menu_hold_r);

	pico8emu(CELESTE_P8_CAMERA, 0, 0);
	pico8emu(CELESTE_P8_PAL_RESET);

	if (menu_state == MENU_MAIN) {
		int ids[5];
		const int n = menu_main_items(ids);
		static int last_n = 0;
		// the save is looked up in the background: when "continue" appears, keep the same
		// entry selected (or select "continue" if the cursor was on the first one)
		if (last_n && n > last_n && menu_sel > 0) menu_sel += n - last_n;
		last_n = n;
		if (menu_sel >= n) menu_sel = n - 1;

		if (up)   menu_move(&menu_sel, n, -1);
		if (down) menu_move(&menu_sel, n, +1);
		if (ok) {
			const int id = ids[menu_sel];
			if (id == MI_CONTINUE) {
				if (savedata_try_continue() == 0) {
					menu_state = MENU_GAME;
					Celeste_P8_set_menu_mode(0);
					autosave_sync();
					menu_play_sfx(35);
					return;     // the game takes over from the next call
				}
				menu_play_sfx(13);  // invalid save: the entry disappears
				return;
			}
			if (id == MI_PLAY) {
				menu_state = MENU_MODE;   // solo / coop
				menu_sel = 0; menu_t = 0;
				menu_play_sfx(35);
				return;
			}
			menu_state = id == MI_CONFIG ? MENU_CONFIG : id == MI_CONTENT ? MENU_CONTENT : MENU_CREDITS;
			menu_sel = 0; menu_t = 0;
			menu_play_sfx(35);
			return;
		}

		// the real title room (logo + snow), with buttons hidden from the game
		{
			Uint16 real = buttons_state;
			buttons_state = 0;
			Celeste_P8_update();
			Celeste_P8_draw();
			buttons_state = real;
		}
		pico8emu(CELESTE_P8_PAL_RESET);

		const int gap = n >= 5 ? 10 : 12, y0 = n >= 5 ? 62 : n == 4 ? 68 : 76;
		for (int i = 0; i < n; i++) {
			const int y = y0 + i*gap, sel = i == menu_sel;
			// with a save present, "play" starts a new game
			const char* label = ids[i] == MI_CONTINUE ? TR(S_CONTINUE)
				: ids[i] == MI_PLAY ? TR(savedata_has ? S_NEWGAME : S_PLAY)
				: ids[i] == MI_CONTENT ? TR(S_CONTENTS)
				: ids[i] == MI_CONFIG ? TR(S_CONFIG) : TR(S_CREDITS);
			const int w = (int)strlen(label)*4;
			m_text_c(label, y, sel ? 7 : 13);
			if (sel) {
				menu_cursor(64 - w/2 - 12, y);
				m_rect(64 - w/2, y + 7, 64 + w/2 - 2, y + 7, (menu_t/4 % 2) ? 14 : 8);
			}
		}
	} else if (menu_state == MENU_MODE) {
		// two cards: 0 = solo, 1 = coop
		int d = (pressed & btn_right) ? 1 : (pressed & btn_left) ? -1 : (up || down) ? 1 : 0;
		if (d) menu_move(&menu_sel, 2, d);
		if (back) {
			menu_state = MENU_MAIN; menu_sel = menu_main_index(MI_PLAY); menu_t = 0;
			menu_play_sfx(35);
			return;
		}
		if (ok) {
			Celeste_P8_set_coop(menu_sel == 1);
			menu_state = MENU_GAME;
			menu_start_pending = 1;
			return;     // the game takes over from the next call
		}

		m_rect(-VIEW_OX, 0, 127 + VIEW_OX, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header(TR(S_MODE));

		for (int i = 0; i < 2; i++) {
			const int x0 = i ? 68 : 12, x1 = x0 + 47, y0 = 28, y1 = 84, cx = (x0 + x1)/2;
			const int sel = i == menu_sel;
			m_rect(x0, y0, x1, y1, sel ? ((menu_t/5 % 2) ? 14 : 7) : 5);   // blinking border when selected
			m_rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, sel ? 1 : 0);
			const int hop = sel ? ((menu_t/6) % 2) : 0;
			const int frame = sel ? 1 + (menu_t/4) % 4 : 1;                   // runs when selected
			if (i == 0) {
				Celeste_P8_draw_preview(0, cx - 4, y0 + 14 - hop, 1, 0, frame, menu_t, sel);
			} else {
				Celeste_P8_draw_preview(1, cx - 16, y0 + 14 - hop, 1, 0, frame, menu_t, sel);   // player 1
				Celeste_P8_draw_preview(2, cx + 8, y0 + 14 - hop, 1, 1, frame, menu_t, sel);    // player 2
				if (sel) {                                 // little rgb link between them
					static const int rgb[3] = {8, 11, 12};
					for (int k = 0; k < 4; k++)
						m_rect(cx - 6 + k*4, y0 + 19, cx - 5 + k*4, y0 + 20, rgb[(menu_t/3 + k) % 3]);
				}
			}
			const char* name = i ? TR(S_COOP) : TR(S_SOLO);
			const char* sub  = i ? TR(S_TWOP) : TR(S_ONEP);
			m_text(name, cx - (int)strlen(name)*2, y0 + 34, sel ? 7 : 13);
			m_text(sub,  cx - (int)strlen(sub)*2,  y0 + 44, sel ? 6 : 5);
		}
		if (menu_sel == 1 && !coop_pad2_present() && (menu_t/10 % 2) == 0)
			m_text_c(TR(S_NEEDPAD), 90, 8);
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_CONFIG) {
		// rows: 0 music, 1 sound, 2 screenshake, 3 language, 4 back
		enum { ROWS = 5 };
		if (up)   menu_move(&menu_sel, ROWS, -1);
		if (down) menu_move(&menu_sel, ROWS, +1);
		int d = right ? 1 : left ? -1 : 0;
		if (d && menu_sel == 0) { int v = cfg_music + d; if (v >= 0 && v <= 10) { cfg_music = v; menu_apply_audio(); menu_play_sfx(13); } }
		if (d && menu_sel == 1) { int v = cfg_sound + d; if (v >= 0 && v <= 10) { cfg_sound = v; menu_apply_audio(); menu_play_sfx(13); } }
		if (menu_sel == 2 && ((pressed & (btn_left|btn_right|btn_ok)) != 0)) {
			enable_screenshake = !enable_screenshake;
			menu_play_sfx(13);
		}
		if (menu_sel == 3 && ((pressed & (btn_left|btn_right|btn_ok)) != 0)) {
			cfg_lang = cfg_lang == LANG_EN ? LANG_PT : LANG_EN;
			menu_apply_lang();
			menu_save_cfg();
			menu_play_sfx(13);
		}
		if (back || (ok && menu_sel == 4)) {
			menu_leave_sub(MENU_CONFIG);
			return;
		}

		menu_backdrop();
		if (menu_from_pause) m_panel(4, 3, 123, 114);   // readable over the paused game
		menu_header(TR(S_CONFIG));

		const char* labels[ROWS] = { TR(S_MUSIC), TR(S_SOUND), TR(S_SHAKE), TR(S_LANG), TR(S_BACK) };
		for (int i = 0; i < ROWS; i++) {
			const int y = 28 + i*12, sel = i == menu_sel;
			const int col = sel ? 7 : 13;
			if (i == ROWS - 1) {
				const int w = (int)strlen(labels[i])*4;
				m_text_c(labels[i], y + 4, col);
				if (sel) menu_cursor(64 - w/2 - 12, y + 4);
				continue;
			}
			m_text(labels[i], 22, y, col);
			if (sel) menu_cursor(8, y);
			if (i < 2) {
				int v = i == 0 ? cfg_music : cfg_sound;
				for (int k = 0; k < 10; k++)
					m_rect(60 + k*5, y + 1, 63 + k*5, y + 5, k < v ? (sel ? 12 : 13) : 1);
			} else {
				const char* val = i == 2 ? (enable_screenshake ? TR(S_ON) : TR(S_OFF)) : TR(S_LANGNAME);
				// only the word "portugues" is green (the green of the Brazilian flag)
				m_text(val, 60, y, (i == 3 && cfg_lang == LANG_PT) ? 11 : (sel ? 10 : 13));
				if (sel) m_text(">", 60 + (int)strlen(val)*4 + 2, y, 10);
			}
			if (sel) {
				m_text("<", 54, y, 10);
				if (i < 2) m_text(">", 111, y, 10);
			}
		}
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_CONTENT) {
		// rows: 0 trophies, 1 customize, 2 back
		enum { ROWS = 3 };
		if (up)   menu_move(&menu_sel, ROWS, -1);
		if (down) menu_move(&menu_sel, ROWS, +1);
		if (back || (ok && menu_sel == 2)) {
			menu_leave_sub(MENU_CONTENT);
			return;
		}
		if (ok && menu_sel == 0) {
			menu_open_trophies();
			return;
		}
		if (ok && menu_sel == 1) {
			menu_state = MENU_CUSTOM; menu_sel = 0; menu_t = 0;
			menu_hold_l = menu_hold_r = 0;
			menu_play_sfx(35);
			return;
		}

		menu_backdrop();
		menu_header(TR(S_CONTENTS));
		{
			const int y = 28, sel = menu_sel == 0;
			char val[16];
			snprintf(val, sizeof val, "%d/%d", trophy_count(), TROPHY_TOTAL);
			m_text(TR(S_TROPHIES), 22, y, sel ? 7 : 13);
			m_text(val, 72, y, trophy_count() == TROPHY_TOTAL ? 10 : (sel ? 10 : 13));
			if (sel) { menu_cursor(8, y); m_text(">", 72 + (int)strlen(val)*4 + 2, y, 10); }
			m_text(cfg_lang == LANG_PT ? "conquistas do modo co-op" : "co-op achievements", 22, y + 9, 5);
		}
		{
			const int y = 50, sel = menu_sel == 1;
			m_text(TR(S_CUSTOMIZE), 22, y, sel ? 7 : 13);
			if (sel) { menu_cursor(8, y); m_text(">", 22 + (int)strlen(TR(S_CUSTOMIZE))*4 + 2, y, 10); }
			m_text(TR(S_CU_SUB), 22, y + 9, 5);
		}
		{
			const int y = 74, sel = menu_sel == 2, w = (int)strlen(TR(S_BACK))*4;
			m_text_c(TR(S_BACK), y + 4, sel ? 7 : 13);
			if (sel) menu_cursor(64 - w/2 - 12, y + 4);
		}
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_CUSTOM) {
		// rows: 0 character, 1 hair, 2 outfit, 3 skin, 4 hat, 5 hat color, 6 scarf, 7 cape, 8 extra, 9 back
		enum { ROWS = 10, FIRST_FIELD = 1 };
		static const int row_field[ROWS] = { -1, CELESTE_STYLE_HAIR, CELESTE_STYLE_DRESS, CELESTE_STYLE_SKIN,
			CELESTE_STYLE_HAT, CELESTE_STYLE_HATCOL, CELESTE_STYLE_SCARF, CELESTE_STYLE_CAPE, CELESTE_STYLE_EXTRA, -1 };
		const char* labels[ROWS] = { TR(S_CU_WHO), TR(S_CU_HAIR), TR(S_CU_DRESS), TR(S_CU_SKIN), TR(S_CU_HAT),
			TR(S_CU_HATCOL), TR(S_CU_SCARF), TR(S_CU_CAPE), TR(S_CU_EXTRA), TR(S_BACK) };
		static int cu_slot = 0;
		static const char* const slot_names[3] = { NULL, "coop 1", "coop 2" };

		if (up)   menu_move(&menu_sel, ROWS, -1);
		if (down) menu_move(&menu_sel, ROWS, +1);
		if (back || (ok && menu_sel == ROWS - 1)) {
			menu_leave_sub(MENU_CUSTOM);
			return;
		}
		int d = right ? 1 : left ? -1 : (ok ? 1 : 0);
		if (d && menu_sel == 0) {
			cu_slot = (cu_slot + d + CELESTE_STYLE_SLOTS) % CELESTE_STYLE_SLOTS;
			menu_play_sfx(13);
		} else if (d && menu_sel < ROWS - 1) {
			const int f = row_field[menu_sel];
			Celeste_P8_style_t st; Celeste_P8_get_style(cu_slot, &st);
			const int n = Celeste_P8_style_count(f);
			st.v[f] = (unsigned char)((st.v[f] + d + n) % n);
			Celeste_P8_set_style(cu_slot, &st);
			menu_play_sfx(13);
		}

		menu_backdrop();
		menu_header(TR(S_CUSTOMIZE));
		m_panel(2, 16, 126, 112);

		Celeste_P8_style_t cur; Celeste_P8_get_style(cu_slot, &cur);
		for (int i = 0; i < ROWS; i++) {
			const int y = i == ROWS - 1 ? 101 : 21 + i*9, sel = i == menu_sel;
			if (i == ROWS - 1) {
				m_text(labels[i], 13, y, sel ? 7 : 13);
				if (sel) menu_cursor(4, y);
				continue;
			}
			m_text(labels[i], 13, y, sel ? 7 : 13);
			if (sel) menu_cursor(4, y);
			const char* val = i == 0 ? (cu_slot == 0 ? TR(S_SOLO) : slot_names[cu_slot])
			                         : Celeste_P8_style_name(row_field[i], cur.v[row_field[i]]);
			m_text(val, 55, y, sel ? 10 : 13);
			if (sel) {
				m_text("<", 50, y, 10);
				m_text(">", 55 + (int)strlen(val)*4 + 1, y, 10);
			}
		}

		// preview: the selected character runs for a while, then stands still
		{
			const int running = (menu_t / 50) % 2;
			const int frame = running ? 1 + (menu_t/4) % 4 : 1;
			m_rect(94, 20, 124, 62, 1);
			m_rect(94, 58, 124, 62, 5);
			Celeste_P8_draw_preview(cu_slot, 103, 36, 2, 0, frame, menu_t, running);
			const char* nm = cu_slot == 0 ? TR(S_SOLO) : slot_names[cu_slot];
			m_text(nm, 109 - (int)strlen(nm)*2, 66, cu_slot == 2 ? 12 : 14);
			// the three characters side by side
			for (int k = 0; k < CELESTE_STYLE_SLOTS; k++) {
				const int px = 97 + k*10;
				Celeste_P8_draw_preview(k, px, 76, 1, 0, 1, menu_t, 0);
				if (k == cu_slot) m_rect(px, 86, px + 7, 86, (menu_t/5 % 2) ? 14 : 7);
			}
		}
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_PAUSE) {
		// rows: 0 continue, 1 config, 2 trophies, 3 quit
		enum { ROWS = 4 };
		if (up)   menu_move(&menu_sel, ROWS, -1);
		if (down) menu_move(&menu_sel, ROWS, +1);
		if (back || (ok && menu_sel == 0)) {
			menu_pause_close();
			return;
		}
		if (ok && menu_sel == 1) {
			menu_state = MENU_CONFIG; menu_sel = 0; menu_t = 0;
			menu_play_sfx(35);
			return;
		}
		if (ok && menu_sel == 2) {
			menu_open_trophies();
			return;
		}
		if (ok && menu_sel == 3) {          // quit to the title (the progress is saved automatically)
			menu_quit_pending = 1; menu_from_pause = 0; menu_sel = 0; menu_t = 0;
			menu_play_sfx(35);
			return;
		}

		menu_draw_pause_bg();
		const int px0 = 22, px1 = 105, py0 = 24, py1 = 104;
		m_panel(px0, py0, px1, py1);
		{
			const char* t = TR(S_PAUSED);
			const int w = (int)strlen(t)*4;
			m_text_shadow_c(t, py0 + 7, 14, 2);
			m_rect(64 - w/2 - 14, py0 + 10, 64 - w/2 - 6, py0 + 10, 13);
			m_rect(64 + w/2 + 6,  py0 + 10, 64 + w/2 + 14, py0 + 10, 13);
		}
		const char* labels[ROWS] = { TR(S_CONTINUE), TR(S_CONFIG), TR(S_TROPHIES), TR(S_QUIT) };
		for (int i = 0; i < ROWS; i++) {
			const int y = py0 + 21 + i*14, sel = i == menu_sel;
			const int w = (int)strlen(labels[i])*4;
			m_text_c(labels[i], y, sel ? 7 : 13);
			if (sel) {
				menu_cursor(64 - w/2 - 12, y);
				m_rect(64 - w/2, y + 7, 64 + w/2 - 2, y + 7, (menu_t/4 % 2) ? 14 : 8);
			}
		}
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_TROPHIES) {
		const int tup   = menu_repeat((held & btn_up) != 0, &menu_hold_u);
		const int tdown = menu_repeat((held & btn_down) != 0, &menu_hold_d);
		if (tr_detail) {
			if (ok || back) { tr_detail = 0; menu_play_sfx(35); }
		} else {
			if (tup)   menu_move(&tr_sel, TR_COUNT, -1);
			if (tdown) menu_move(&tr_sel, TR_COUNT, +1);
			if (back) { menu_leave_sub(MENU_TROPHIES); return; }
			if (ok) { tr_detail = 1; menu_play_sfx(13); }
		}
		tr_top = trophy_fix_top(tr_sel, tr_top);

		menu_backdrop();
		trophy_draw_list(tr_sel, tr_top, tr_detail, menu_from_pause);
	} else if (menu_state == MENU_CREDITS) {
		if (back || ok) {
			menu_state = MENU_MAIN; menu_sel = menu_main_index(MI_CREDITS); menu_t = 0;
			menu_play_sfx(35);
			return;
		}
		m_rect(-VIEW_OX, 0, 127 + VIEW_OX, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header(TR(S_CREDITS));

		const int n = (int)(sizeof menu_credits / sizeof *menu_credits);
		for (int i = 0; i < n; i++) {
			const char* t = cfg_lang == LANG_PT ? menu_credits[i].pt : menu_credits[i].en;
			if (!*t) continue;
			m_text_c(t, 21 + i*6, menu_credits[i].col);
		}
		// Madeline waiting at the bottom, strawberry next to her
		m_spr(1, 56, 112, 0);
		m_spr(26, 68, 112 + (int)floorf(sinf(menu_t*0.18f) * 1.5f + 0.5f), 0);
	}
}
