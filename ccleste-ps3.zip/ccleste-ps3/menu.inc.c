// Title menu (play -> solo / coop, config, credits) for ccleste.
// Included by sdl12main.c. Draws only through pico8emu() callbacks so it uses the
// same 128x128 PICO-8 screen and palette as the game.
//
// The frontend must provide (before including this file):
//   pico8emu(), Celeste_P8_update/draw(), menu_apply_audio(), menu_play_sfx(),
//   menu_cfg_path(), autosave_sync(), coop_pad2_present(), `buttons_state` and the
//   `enable_screenshake` flag,
// and savedata.inc.c must be included before this file.

#include <math.h>
#include <string.h>
#include <stdio.h>

enum { MENU_MAIN, MENU_CONFIG, MENU_CREDITS, MENU_MODE, MENU_CONTENT, MENU_CUSTOMIZE, MENU_GAME };

static int menu_state = MENU_MAIN;
static int menu_sel = 0;          // selected row in the current screen
static int menu_t = 0;            // frame counter (animations)
static int menu_start_pending = 0;
static int menu_hold_l = 0, menu_hold_r = 0;

// settings (saved to disk)
static int cfg_music = 10;        // 0..10
static int cfg_sound = 10;        // 0..10

// solo character look (Contents > Customize), saved with the other settings
#define SKIN_COUNT 3
static int cfg_skin = 0;          // 0..SKIN_COUNT-1
static int cfg_hair = 0;          // 0 = the skin's own hair, 1..8 = custom colour (hair_opts)
static int cfg_outfit = 0;        // 0 = the skin's own dress, 1..8 = custom colour (outfit_opts)

// ---- language ----
enum { LANG_EN = 0, LANG_PT = 1 };
static int cfg_lang = LANG_EN;

enum { S_PLAY, S_CONTINUE, S_NEWGAME, S_CONFIG, S_CREDITS, S_MUSIC, S_SOUND, S_SHAKE, S_LANG,
       S_BACK, S_ON, S_OFF, S_LANGNAME, S_MODE, S_SOLO, S_COOP, S_ONEP, S_TWOP, S_NEEDPAD,
       S_CONTENT, S_CUSTOMIZE, S_SKIN, S_HAIR, S_OUTFIT, S_DEFAULT, S_SKIN0, S_SKIN1, S_SKIN2, S_COUNT };
// the pico-8 font has no accents, so the portuguese texts are written without them
static const char* const menu_str[2][S_COUNT] = {
	{ "play", "continue", "new game", "config", "credits", "music", "sound", "shake", "language",
	  "back", "on", "off", "english",
	  "game mode", "solo", "coop", "1 player", "2 players", "connect a 2nd controller",
	  "contents", "customize", "skin", "hair", "outfit", "default", "madeline", "badeline", "golden" },
	{ "jogar", "continuar", "novo jogo", "configuracoes", "creditos", "musica", "som", "tremor", "idioma",
	  "voltar", "ligado", "desligado", "portugues",
	  "modo de jogo", "solo", "coop", "1 jogador", "2 jogadores", "conecte o 2o controle",
	  "conteudos", "customize", "skin", "cabelo", "roupa", "padrao", "madeline", "badeline", "golden" },
};
#define TR(i) (menu_str[cfg_lang][(i)])

// ---- edit these to change the credits text (max 31 chars per line) ----
static const struct { const char* en; const char* pt; int col; } menu_credits[] = {
	{ "main creator",          "criador principal",      14 },
	{ "darkz1to",              "darkz1to",               10 },
	{ "",                      "",                        0 },
	{ "celeste classic",       "celeste classic",        14 },
	{ "matt thorson",          "matt thorson",            7 },
	{ "noel berry",            "noel berry",              7 },
	{ "",                      "",                        0 },
	{ "c port (ccleste)",      "port em c (ccleste)",    14 },
	{ "lemon",                 "lemon",                   7 },
	{ "sounds: gba port",      "sons: port gba",         14 },
	{ "jeffrulz",              "jeffrulz",                7 },
	{ "",                      "",                        0 },
	{ "thanks for playing!",   "obrigado por jogar!",     7 },
};

#if defined(PLATFORM_PS3)
#define MENU_KEY_OK   "x"
#define MENU_KEY_BACK "o"
#elif defined(_3DS)
#define MENU_KEY_OK   "a"
#define MENU_KEY_BACK "b"
#else
#define MENU_KEY_OK   "z"
#define MENU_KEY_BACK "x"
#endif

static const unsigned char btn_left = 1<<0, btn_right = 1<<1, btn_up = 1<<2, btn_down = 1<<3;
static const unsigned char btn_ok = 1<<4, btn_back = 1<<5;

// ---------------------------------------------------------------- drawing helpers
static void m_rect(int x0, int y0, int x1, int y1, int c) { pico8emu(CELESTE_P8_RECTFILL, x0, y0, x1, y1, c); }
static void m_text(const char* s, int x, int y, int c) { pico8emu(CELESTE_P8_PRINT, s, x, y, c); }
static void m_text_c(const char* s, int y, int c) { m_text(s, 64 - (int)strlen(s)*2, y, c); }
static void m_text_shadow_c(const char* s, int y, int c, int sc) {
	m_text_c(s, y + 1, sc);
	m_text_c(s, y, c);
}
static void m_spr(int s, int x, int y, int flipx) { pico8emu(CELESTE_P8_SPR, s, x, y, 1, 1, flipx, 0); }

// snow / stars, same feel as the title screen particles
#define MENU_FLAKES 28
static struct { float x, y, spd, off; int c; } flakes[MENU_FLAKES];
static int flakes_ready = 0;
static unsigned menu_rng = 12345;
static float menu_rnd(void) { menu_rng = menu_rng*1103515245u + 12345u; return ((menu_rng>>16) & 0x7fff) / 32768.0f; }

static void menu_flakes_update_draw(void) {
	if (!flakes_ready) {
		flakes_ready = 1;
		for (int i = 0; i < MENU_FLAKES; i++) {
			flakes[i].x = menu_rnd()*(128 + 2*VIEW_OX) - VIEW_OX; flakes[i].y = menu_rnd()*128;
			flakes[i].spd = 0.3f + menu_rnd()*1.2f; flakes[i].off = menu_rnd();
			flakes[i].c = (i % 5 == 0) ? 7 : (i % 3 == 0) ? 6 : 13;
		}
	}
	for (int i = 0; i < MENU_FLAKES; i++) {
		flakes[i].x += flakes[i].spd;
		flakes[i].y += sinf(flakes[i].off*6.2832f) * 0.4f;
		flakes[i].off += 0.02f;
		if (flakes[i].x > 132 + VIEW_OX) { flakes[i].x = -4 - VIEW_OX; flakes[i].y = menu_rnd()*128; }
		int x = (int)flakes[i].x, y = (int)flakes[i].y;
		int big = flakes[i].spd > 1.1f;
		m_rect(x, y, x + big, y + big, flakes[i].c);
	}
}

static void menu_mountains(void) {
	for (int x = -VIEW_OX; x < 128 + VIEW_OX; x++) {
		// far range
		int h = 20 + (int)(9*sinf(x*0.07f + 0.5f) + 5*sinf(x*0.19f + 2.0f));
		int top = 128 - h;
		m_rect(x, top, x, 127, 1);
		if (h > 27) m_rect(x, top, x, top + 1, 13);     // snow cap
		else if (h > 24) m_rect(x, top, x, top, 13);
		// near ridge
		int h2 = 8 + (int)(5*sinf(x*0.11f + 3.0f) + 3*sinf(x*0.29f));
		m_rect(x, 128 - h2, x, 127, 0);
		m_rect(x, 128 - h2, x, 128 - h2, 5);
	}
}

static void menu_cursor(int x, int y) {
	// bobbing strawberry
	int bob = (int)floorf(sinf(menu_t * 0.18f) * 1.5f + 0.5f);
	m_spr(26, x, y - 2 + bob, 0);
}

static void menu_header(const char* title) {
	m_text_shadow_c(title, 9, 14, 2);
	int w = (int)strlen(title)*4;
	m_rect(64 - w/2 - 14, 12, 64 - w/2 - 6, 12, 13);
	m_rect(64 + w/2 + 6,  12, 64 + w/2 + 14, 12, 13);
}

// ---------------------------------------------------------------- solo skins
// pico-8 palette indices. hair = dash ready, spent = no dash, shirt = dress.
// Madeline's sprite uses index 8 for the hair and 3 for the dress.
static const struct { int name, hair, spent, shirt; } skins[SKIN_COUNT] = {
	{ S_SKIN0,  8, 12,  3 },   // original colours
	{ S_SKIN1, 13,  5,  2 },   // lavender hair, purple dress
	{ S_SKIN2, 10,  4,  9 },   // yellow hair, orange dress
};
static const int hair_opts[8]   = { 8, 14, 9, 10, 11, 12, 13, 7 };
static const int outfit_opts[8] = { 3, 8, 12, 2, 9, 10, 14, 13 };
// darker colour used for the hair when the dash is spent (custom hair colours)
static const int hair_dark[16]  = { 0, 1, 2, 3, 4, 5, 5, 6, 2, 4, 9, 3, 1, 5, 2, 4 };

// final colours of a skin (the overrides only apply to the skin that is selected)
static void skin_colors(int skin, int use_custom, int* hair, int* spent, int* shirt) {
	*hair = skins[skin].hair; *spent = skins[skin].spent; *shirt = skins[skin].shirt;
	if (use_custom && cfg_hair > 0)   { *hair = hair_opts[cfg_hair - 1]; *spent = hair_dark[*hair]; }
	if (use_custom && cfg_outfit > 0) { *shirt = outfit_opts[cfg_outfit - 1]; }
}

// hand the look to the game (solo only, the game ignores it in co-op)
static void menu_apply_style(void) {
	int h, s, d;
	skin_colors(cfg_skin, 1, &h, &s, &d);
	Celeste_P8_set_player_style(h, s, d);
}

// Madeline with the given colours; the hair is a short wobbling chain like the real one
static void m_madeline(int x, int y, int frame, int flip, int hair, int shirt) {
	pico8emu(CELESTE_P8_PAL, 8, hair);
	pico8emu(CELESTE_P8_PAL, 3, shirt);
	for (int i = 0; i < 5; i++) {
		const int dx = flip ? 6 + i*2 : 2 - i*2;
		const int dy = 3 + i/2 + (i ? ((menu_t/5 + i) % 2) : 0);
		pico8emu(CELESTE_P8_CIRCFILL, x + dx, y + dy, i < 2 ? 2 : 1, 8);
	}
	m_spr(frame, x, y, flip);
	pico8emu(CELESTE_P8_PAL_RESET);
}

// ---------------------------------------------------------------- config persistence
static void menu_save_cfg(void) {
	char path[700];
	if (!menu_cfg_path(path, sizeof path)) return;
	FILE* f = fopen(path, "w");
	if (!f) return;
	fprintf(f, "%d %d %d %d %d %d %d\n", cfg_music, cfg_sound, enable_screenshake ? 1 : 0, cfg_lang,
	        cfg_skin, cfg_hair, cfg_outfit);
	fclose(f);
}

static void menu_load_cfg(void) {
	char path[700];
	if (!menu_cfg_path(path, sizeof path)) return;
	FILE* f = fopen(path, "r");
	if (!f) return;
	int m, s, k, l = 0, sk = 0, ha = 0, ou = 0;
	int n = fscanf(f, "%d %d %d %d %d %d %d", &m, &s, &k, &l, &sk, &ha, &ou);
	if (n >= 3) {   // the language is optional: old cfg files only have 3 numbers
		cfg_music = m < 0 ? 0 : m > 10 ? 10 : m;
		cfg_sound = s < 0 ? 0 : s > 10 ? 10 : s;
		enable_screenshake = k != 0;
		cfg_lang = (n >= 4 && l == LANG_PT) ? LANG_PT : LANG_EN;
		if (n >= 7) {   // look of the character: old cfg files don't have it
			cfg_skin   = sk >= 0 && sk < SKIN_COUNT ? sk : 0;
			cfg_hair   = ha >= 0 && ha <= 8 ? ha : 0;
			cfg_outfit = ou >= 0 && ou <= 8 ? ou : 0;
		}
	}
	fclose(f);
}

// ---------------------------------------------------------------- public API
static int menu_active(void) { return menu_state != MENU_GAME; }

static void menu_apply_lang(void) { Celeste_P8_set_language(cfg_lang == LANG_PT); }

static void menu_init(int skip) {
	menu_load_cfg();
	menu_apply_lang();
	menu_apply_audio();
	menu_apply_style();
	menu_state = skip ? MENU_GAME : MENU_MAIN;
	menu_sel = 0; menu_t = 0; menu_start_pending = 0;
	Celeste_P8_set_menu_mode(!skip);
}

// back to the main menu (used after a reset)
static void menu_enter_main(void) {
	menu_state = MENU_MAIN; menu_sel = 0; menu_t = 0; menu_start_pending = 0;
	Celeste_P8_set_menu_mode(1);
}

// returns 1 exactly once after "play" was chosen: the frontend injects a jump press
// so the game runs its own start flash and loads the first room
static int menu_take_start(void) {
	int r = menu_start_pending;
	menu_start_pending = 0;
	return r;
}

static int menu_repeat(int held, int* counter) {
	if (!held) { *counter = 0; return 0; }
	(*counter)++;
	return *counter == 1 || (*counter > 14 && (*counter % 3) == 0);
}

static void menu_move(int* sel, int n, int dir) {
	*sel = (*sel + dir + n) % n;
	menu_play_sfx(13);
}

// main menu entries: "continue" only shows up when there is a save
enum { MI_CONTINUE, MI_PLAY, MI_CONTENT, MI_CONFIG, MI_CREDITS };
static int menu_main_items(int* ids) {
	int n = 0;
	if (savedata_has) ids[n++] = MI_CONTINUE;
	ids[n++] = MI_PLAY; ids[n++] = MI_CONTENT; ids[n++] = MI_CONFIG; ids[n++] = MI_CREDITS;
	return n;
}
static int menu_main_index(int id) {
	int ids[5], n = menu_main_items(ids);
	for (int i = 0; i < n; i++) if (ids[i] == id) return i;
	return 0;
}

static const char* menu_hint_sub(void) {
	static char buf[40];
	snprintf(buf, sizeof buf, "%s: ok   %s: %s", MENU_KEY_OK, MENU_KEY_BACK, TR(S_BACK));
	return buf;
}

// pressed = buttons that went down this frame, held = buttons currently down
static void menu_frame(Uint16 pressed, Uint16 held) {
	menu_t++;
	const int up = (pressed & btn_up) != 0, down = (pressed & btn_down) != 0;
	const int ok = (pressed & btn_ok) != 0, back = (pressed & btn_back) != 0;
	const int left = menu_repeat((held & btn_left) != 0, &menu_hold_l);
	const int right = menu_repeat((held & btn_right) != 0, &menu_hold_r);

	pico8emu(CELESTE_P8_CAMERA, 0, 0);
	pico8emu(CELESTE_P8_PAL_RESET);

	if (menu_state == MENU_MAIN) {
		int ids[5];
		const int n = menu_main_items(ids);
		static int last_n = 0;
		// the save is looked up in the background: when "continue" appears, keep the same
		// entry selected (or select "continue" if the cursor was on the first one)
		if (last_n && n > last_n && menu_sel > 0) menu_sel += n - last_n;
		last_n = n;
		if (menu_sel >= n) menu_sel = n - 1;

		if (up)   menu_move(&menu_sel, n, -1);
		if (down) menu_move(&menu_sel, n, +1);
		if (ok) {
			const int id = ids[menu_sel];
			if (id == MI_CONTINUE) {
				if (savedata_try_continue() == 0) {
					menu_state = MENU_GAME;
					Celeste_P8_set_menu_mode(0);
					autosave_sync();
					menu_play_sfx(35);
					return;     // the game takes over from the next call
				}
				menu_play_sfx(13);  // invalid save: the entry disappears
				return;
			}
			if (id == MI_PLAY) {
				menu_state = MENU_MODE;   // solo / coop
				menu_sel = 0; menu_t = 0;
				menu_play_sfx(35);
				return;
			}
			menu_state = id == MI_CONTENT ? MENU_CONTENT : id == MI_CONFIG ? MENU_CONFIG : MENU_CREDITS;
			menu_sel = 0; menu_t = 0;
			menu_play_sfx(35);
			return;
		}

		// the real title room (logo + snow), with buttons hidden from the game
		{
			Uint16 real = buttons_state;
			buttons_state = 0;
			Celeste_P8_update();
			Celeste_P8_draw();
			buttons_state = real;
		}
		pico8emu(CELESTE_P8_PAL_RESET);

		const int step = n >= 5 ? 10 : 12;
		const int y0 = n >= 5 ? 66 : n == 4 ? 68 : 76;
		for (int i = 0; i < n; i++) {
			const int y = y0 + i*step, sel = i == menu_sel;
			// with a save present, "play" starts a new game
			const char* label = ids[i] == MI_CONTINUE ? TR(S_CONTINUE)
				: ids[i] == MI_PLAY ? TR(savedata_has ? S_NEWGAME : S_PLAY)
				: ids[i] == MI_CONTENT ? TR(S_CONTENT)
				: ids[i] == MI_CONFIG ? TR(S_CONFIG) : TR(S_CREDITS);
			const int w = (int)strlen(label)*4;
			m_text_c(label, y, sel ? 7 : 13);
			if (sel) {
				menu_cursor(64 - w/2 - 12, y);
				m_rect(64 - w/2, y + 7, 64 + w/2 - 2, y + 7, (menu_t/4 % 2) ? 14 : 8);
			}
		}
	} else if (menu_state == MENU_MODE) {
		// two cards: 0 = solo, 1 = coop
		int d = (pressed & btn_right) ? 1 : (pressed & btn_left) ? -1 : (up || down) ? 1 : 0;
		if (d) menu_move(&menu_sel, 2, d);
		if (back) {
			menu_state = MENU_MAIN; menu_sel = menu_main_index(MI_PLAY); menu_t = 0;
			menu_play_sfx(35);
			return;
		}
		if (ok) {
			Celeste_P8_set_coop(menu_sel == 1);
			menu_state = MENU_GAME;
			menu_start_pending = 1;
			return;     // the game takes over from the next call
		}

		m_rect(-VIEW_OX, 0, 127 + VIEW_OX, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header(TR(S_MODE));

		for (int i = 0; i < 2; i++) {
			const int x0 = i ? 68 : 12, x1 = x0 + 47, y0 = 28, y1 = 84, cx = (x0 + x1)/2;
			const int sel = i == menu_sel;
			m_rect(x0, y0, x1, y1, sel ? ((menu_t/5 % 2) ? 14 : 7) : 5);   // blinking border when selected
			m_rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, sel ? 1 : 0);
			const int hop = sel ? ((menu_t/6) % 2) : 0;
			const int frame = sel ? 1 + (menu_t/4) % 4 : 1;                   // runs when selected
			if (i == 0) {
				m_spr(frame, cx - 4, y0 + 14 - hop, 0);
			} else {
				pico8emu(CELESTE_P8_PAL, 8, 14);           // player 1: pink hair
				m_spr(frame, cx - 16, y0 + 14 - hop, 0);
				pico8emu(CELESTE_P8_PAL_RESET);
				pico8emu(CELESTE_P8_PAL, 8, 12);           // player 2: blue hair
				m_spr(frame, cx + 8, y0 + 14 - hop, 1);
				pico8emu(CELESTE_P8_PAL_RESET);
				if (sel) {                                 // little rgb link between them
					static const int rgb[3] = {8, 11, 12};
					for (int k = 0; k < 4; k++)
						m_rect(cx - 6 + k*4, y0 + 19, cx - 5 + k*4, y0 + 20, rgb[(menu_t/3 + k) % 3]);
				}
			}
			const char* name = i ? TR(S_COOP) : TR(S_SOLO);
			const char* sub  = i ? TR(S_TWOP) : TR(S_ONEP);
			m_text(name, cx - (int)strlen(name)*2, y0 + 34, sel ? 7 : 13);
			m_text(sub,  cx - (int)strlen(sub)*2,  y0 + 44, sel ? 6 : 5);
		}
		if (menu_sel == 1 && !coop_pad2_present() && (menu_t/10 % 2) == 0)
			m_text_c(TR(S_NEEDPAD), 90, 8);
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_CONTENT) {
		// "contents": 0 customize, 1 back
		enum { CROWS = 2 };
		if (up)   menu_move(&menu_sel, CROWS, -1);
		if (down) menu_move(&menu_sel, CROWS, +1);
		if (back || (ok && menu_sel == 1)) {
			menu_state = MENU_MAIN; menu_sel = menu_main_index(MI_CONTENT); menu_t = 0;
			menu_play_sfx(35);
			return;
		}
		if (ok && menu_sel == 0) {
			menu_state = MENU_CUSTOMIZE; menu_sel = 0; menu_t = 0;
			menu_play_sfx(35);
			return;
		}

		m_rect(-VIEW_OX, 0, 127 + VIEW_OX, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header(TR(S_CONTENT));

		const char* labels[CROWS] = { TR(S_CUSTOMIZE), TR(S_BACK) };
		for (int i = 0; i < CROWS; i++) {
			const int y = 40 + i*14, sel = i == menu_sel;
			const int w = (int)strlen(labels[i])*4;
			m_text_c(labels[i], y, sel ? 7 : 13);
			if (sel) {
				menu_cursor(64 - w/2 - 12, y);
				m_rect(64 - w/2, y + 7, 64 + w/2 - 2, y + 7, (menu_t/4 % 2) ? 14 : 8);
			}
		}
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_CUSTOMIZE) {
		// rows: 0 skin, 1 hair, 2 outfit, 3 back
		enum { KROWS = 4 };
		if (up)   menu_move(&menu_sel, KROWS, -1);
		if (down) menu_move(&menu_sel, KROWS, +1);
		const int d = right ? 1 : left ? -1 : 0;
		if (d && menu_sel == 0) {          // another skin: the colour overrides start over
			cfg_skin = (cfg_skin + d + SKIN_COUNT) % SKIN_COUNT;
			cfg_hair = cfg_outfit = 0;
			menu_apply_style(); menu_play_sfx(13);
		}
		if (d && menu_sel == 1) { cfg_hair   = (cfg_hair   + d + 9) % 9; menu_apply_style(); menu_play_sfx(13); }
		if (d && menu_sel == 2) { cfg_outfit = (cfg_outfit + d + 9) % 9; menu_apply_style(); menu_play_sfx(13); }
		if (back || (ok && menu_sel == 3)) {
			menu_save_cfg();
			menu_state = MENU_CONTENT; menu_sel = 0; menu_t = 0;
			menu_play_sfx(35);
			return;
		}

		m_rect(-VIEW_OX, 0, 127 + VIEW_OX, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header(TR(S_CUSTOMIZE));

		// one card per skin; the selected one runs and shows the colour overrides
		for (int i = 0; i < SKIN_COUNT; i++) {
			const int x0 = 9 + i*40, x1 = x0 + 36, y0 = 19, y1 = 57, cx = (x0 + x1)/2;
			const int sel = i == cfg_skin;
			int h, s, c;
			skin_colors(i, sel, &h, &s, &c);
			m_rect(x0, y0, x1, y1, sel ? ((menu_t/5 % 2) ? 14 : 7) : 5);
			m_rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, sel ? 1 : 0);
			m_madeline(cx - 4, y0 + 12 - (sel ? (menu_t/6) % 2 : 0), sel ? 1 + (menu_t/4) % 4 : 1, 0, h, c);
			const char* name = TR(skins[i].name);
			m_text(name, cx - (int)strlen(name)*2, y0 + 28, sel ? 7 : 13);
		}

		int h, s, c;
		skin_colors(cfg_skin, 1, &h, &s, &c);
		const char* labels[KROWS] = { TR(S_SKIN), TR(S_HAIR), TR(S_OUTFIT), TR(S_BACK) };
		for (int i = 0; i < KROWS; i++) {
			const int y = 66 + i*11, sel = i == menu_sel, col = sel ? 7 : 13;
			if (i == KROWS - 1) {
				const int w = (int)strlen(labels[i])*4;
				m_text_c(labels[i], y + 4, col);
				if (sel) menu_cursor(64 - w/2 - 12, y + 4);
				continue;
			}
			m_text(labels[i], 22, y, col);
			if (sel) menu_cursor(8, y);
			if (i == 0) {
				m_text(TR(skins[cfg_skin].name), 66, y, sel ? 10 : 13);
			} else {
				const int custom = i == 1 ? cfg_hair : cfg_outfit;
				m_rect(66, y, 77, y + 5, 7);                           // swatch with a white frame
				m_rect(67, y + 1, 76, y + 4, i == 1 ? h : c);
				if (!custom) m_text(TR(S_DEFAULT), 82, y, sel ? 10 : 6);
			}
			if (sel) {
				m_text("<", 60, y, 10);
				const int custom = i == 1 ? cfg_hair : cfg_outfit;
				m_text(">", i == 0 ? 66 + (int)strlen(TR(skins[cfg_skin].name))*4 + 2
				         : custom ? 80 : 82 + (int)strlen(TR(S_DEFAULT))*4 + 2, y, 10);
			}
		}
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_CONFIG) {
		// rows: 0 music, 1 sound, 2 screenshake, 3 language, 4 back
		enum { ROWS = 5 };
		if (up)   menu_move(&menu_sel, ROWS, -1);
		if (down) menu_move(&menu_sel, ROWS, +1);
		int d = right ? 1 : left ? -1 : 0;
		if (d && menu_sel == 0) { int v = cfg_music + d; if (v >= 0 && v <= 10) { cfg_music = v; menu_apply_audio(); menu_play_sfx(13); } }
		if (d && menu_sel == 1) { int v = cfg_sound + d; if (v >= 0 && v <= 10) { cfg_sound = v; menu_apply_audio(); menu_play_sfx(13); } }
		if (menu_sel == 2 && ((pressed & (btn_left|btn_right|btn_ok)) != 0)) {
			enable_screenshake = !enable_screenshake;
			menu_play_sfx(13);
		}
		if (menu_sel == 3 && ((pressed & (btn_left|btn_right|btn_ok)) != 0)) {
			cfg_lang = cfg_lang == LANG_EN ? LANG_PT : LANG_EN;
			menu_apply_lang();
			menu_save_cfg();
			menu_play_sfx(13);
		}
		if (back || (ok && menu_sel == 4)) {
			menu_save_cfg();
			menu_state = MENU_MAIN; menu_sel = menu_main_index(MI_CONFIG); menu_t = 0;
			menu_play_sfx(35);
			return;
		}

		m_rect(-VIEW_OX, 0, 127 + VIEW_OX, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header(TR(S_CONFIG));

		const char* labels[ROWS] = { TR(S_MUSIC), TR(S_SOUND), TR(S_SHAKE), TR(S_LANG), TR(S_BACK) };
		for (int i = 0; i < ROWS; i++) {
			const int y = 28 + i*12, sel = i == menu_sel;
			const int col = sel ? 7 : 13;
			if (i == ROWS - 1) {
				const int w = (int)strlen(labels[i])*4;
				m_text_c(labels[i], y + 4, col);
				if (sel) menu_cursor(64 - w/2 - 12, y + 4);
				continue;
			}
			m_text(labels[i], 22, y, col);
			if (sel) menu_cursor(8, y);
			if (i < 2) {
				int v = i == 0 ? cfg_music : cfg_sound;
				for (int k = 0; k < 10; k++)
					m_rect(60 + k*5, y + 1, 63 + k*5, y + 5, k < v ? (sel ? 12 : 13) : 1);
			} else {
				const char* val = i == 2 ? (enable_screenshake ? TR(S_ON) : TR(S_OFF)) : TR(S_LANGNAME);
				// only the word "portugues" is green (the green of the Brazilian flag)
				m_text(val, 60, y, (i == 3 && cfg_lang == LANG_PT) ? 11 : (sel ? 10 : 13));
				if (sel) m_text(">", 60 + (int)strlen(val)*4 + 2, y, 10);
			}
			if (sel) {
				m_text("<", 54, y, 10);
				if (i < 2) m_text(">", 111, y, 10);
			}
		}
		m_text_c(menu_hint_sub(), 118, 6);
	} else if (menu_state == MENU_CREDITS) {
		if (back || ok) {
			menu_state = MENU_MAIN; menu_sel = menu_main_index(MI_CREDITS); menu_t = 0;
			menu_play_sfx(35);
			return;
		}
		m_rect(-VIEW_OX, 0, 127 + VIEW_OX, 127, 0);
		menu_flakes_update_draw();
		menu_mountains();
		menu_header(TR(S_CREDITS));

		const int n = (int)(sizeof menu_credits / sizeof *menu_credits);
		for (int i = 0; i < n; i++) {
			const char* t = cfg_lang == LANG_PT ? menu_credits[i].pt : menu_credits[i].en;
			if (!*t) continue;
			m_text_c(t, 21 + i*6, menu_credits[i].col);
		}
		// Madeline waiting at the bottom, strawberry next to her
		m_spr(1, 56, 112, 0);
		m_spr(26, 68, 112 + (int)floorf(sinf(menu_t*0.18f) * 1.5f + 0.5f), 0);
	}
}
